﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using Form = System.Windows.Forms.Form;

namespace Family_Fixer
{
    public partial class Form_Showfam : Form
    {

        //Parameters for viewing revit family elements
        private UIDocument _uiDoc;
        private Element[] _element_array;
        private int intCounter = 0;


        //Family as a rectangle params
        private int RectWidth = 50;
        private int RectHeight = 50;
        private int RectPosX, RectPosY;   // Position.
        private int RectVelocity_X, RectVelocity_Y; // Velocity.




        public Form_Showfam(UIDocument uiDoc, List<Element> element_List)
        {
            //InitializeComponent is a method automatically written for you by the Form Designer when you create/change your forms
            InitializeComponent();

            //Autodesk.Revit.UI.UIDocument - provides access to UI-level interfaces for the document, such as the contents of the selection
            _uiDoc = uiDoc;

            //Our selection of Elements or Family instances, that we want to view
            _element_array = element_List.ToArray();

            //Add the element name to the form control's title
            this.Text = element_List.FirstOrDefault().Name;
        }







        /// <summary>
        /// Button to move the family instance selector forward one instance in view
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Find_Family_Click(object sender, EventArgs e)
        {
            label_Count.Text = intCounter.ToString();

            //go to next found family
            if (intCounter > -1 && intCounter < _element_array.Count())
            {
                btn_Find_Nxt_Family.BackColor = System.Drawing.Color.LightGreen;
                iterateFoundElems();
                intCounter++;

                ///EXERCISE_0
                addSomeData(intCounter);
            }
            else
            {
                btn_Find_Nxt_Family.BackColor = System.Drawing.Color.Red;

            }

            //for the graphics to begin
            //this.timer_family.Enabled = true;
        }



        /// <summary>
        /// Button to move the family instance selector back one family in view
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Find_Previous_Family_Click(object sender, EventArgs e)
        {
            label_Count.Text = intCounter.ToString();

            //go to next found family
            if (intCounter > 0 && intCounter < _element_array.Count() + 1)
            {
                intCounter--;
                iterateFoundElems();
                btn_Find_Previous_Family.BackColor = System.Drawing.Color.LightGreen;

                ///EXERCISE_0
                addSomeData(intCounter);
            }
            else
            {
                btn_Find_Previous_Family.BackColor = System.Drawing.Color.Red;
            }

            //this.timer_family.Enabled = false;
        }




        private void iterateFoundElems()
        {
            //dont exceed array limits
            if (intCounter > -1 && intCounter < _element_array.Count())
            {
                //Highlight and show element
                _uiDoc.Selection.SetElementIds(new[] { _element_array[intCounter].Id });
                _uiDoc.ShowElements(_element_array[intCounter].Id);
            }
        }



        private void addSomeData(int intCounter)
        {
            Document _doc = _uiDoc.Document;
            //string strLevel = "null";

            //check that within bounds of array
            if (intCounter < _element_array.Length)
            {
                ///
                ///EXERCISE_0
                ///TASK_0.1
                ///Add Revit Family Parameters to the Text Box of the Form, Form_ShowFam
                //element_List.FirstOrDefault().get_Parameter(BuiltInParameter.ALL_MODEL_FAMILY_NAME).AsString();
                //_element_array[intCounter].Pinned.ToString();
                //_element_array[intCounter].Name
                //_doc.GetElement(_element_array[intCounter].LevelId).Name.ToString()
                //_element_array[intCounter].IsHidden(_uiDoc.ActiveView).ToString();

                /*
                //you will need this if you are searching for levels..because some families...
                if (null != _doc.GetElement(_element_array[intCounter].LevelId))
                {
                    strLevel = _doc.GetElement(_element_array[intCounter].LevelId).Name;
                }
                */

                ///
                ///EXERCISE_0
                ///TASK_0.2
                ///Add Parameters here for task
                rchTxtBx_EXERCISE_0.Text += "\n" + intCounter.ToString() + ", " + "to add another parameter value use a plus then the value";
   

         //Optional Graphics exercise Draw families bounding box side relative dimensions as a rectangle
        //RectWidth = (int)(_element_array[intCounter].get_BoundingBox(null).Max.X - (int)_element_array[intCounter].get_BoundingBox(null).Min.X) * 10 ;
        //RectHeight = (int)(_element_array[intCounter].get_BoundingBox(null).Max.Z - (int)_element_array[intCounter].get_BoundingBox(null).Min.Z) * 10 ;
            }
        }







        /// <summary>
        /// Optional Graphics exercise
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void form_viewfam_Load(object sender, EventArgs e)
        {
            int picbxWidth = picBx_Cube.Size.Width;
            int picbxHeight = picBx_Cube.Size.Height;

            // Pick a random start position and velocity.
            Random rnd = new Random();
            RectVelocity_X = rnd.Next(1, 20);
            RectVelocity_Y = rnd.Next(1, 20);
            RectPosX = rnd.Next(0, picbxWidth - RectWidth);
            RectPosY = rnd.Next(0, picbxHeight - RectHeight);

            // Use double buffering to reduce flicker.
            this.SetStyle( ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.DoubleBuffer, true);
            this.UpdateStyles();
        }

        //Update the Rectangle position
        private void timer_family_Tick(object sender, EventArgs e)
        {
            RectPosX += RectVelocity_X;
            if (RectPosX < 0)
            {
                RectVelocity_X = -RectVelocity_X;
            }
            else if (RectPosX + RectWidth > picBx_Cube.Size.Width)
            {
                RectVelocity_X = -RectVelocity_X;
            }

            RectPosY += RectVelocity_Y;
            if (RectPosY < 0)
            {
                RectVelocity_Y = -RectVelocity_Y;
            }
            else if (RectPosY + RectHeight > picBx_Cube.Size.Height)
            {
                RectVelocity_Y = -RectVelocity_Y;
            }

            Refresh();
        }

        // Draw the family as a rectangle
        private void picBx_Cube_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.Clear(BackColor);
            e.Graphics.FillRectangle(Brushes.Blue, RectPosX, RectPosY, RectWidth, RectHeight);
            e.Graphics.DrawRectangle(Pens.Black, RectPosX, RectPosY, RectWidth, RectHeight);
        }







    }//end class
}//end ns
