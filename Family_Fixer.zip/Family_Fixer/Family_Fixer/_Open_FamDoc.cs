﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System.IO;

namespace Family_Fixer
{
    public static class _Open_FamDoc
    {
        public static void openToView(UIApplication _uiApp, Document _doc, Family _family)
        {
            const string dumpsterPath = @"c:\temp\";

            if (!_family.IsInPlace)
            {
                //If family isnt in-place safe to attempt to get famDoc
                Document famDoc = _doc.EditFamily(_family);

                if (famDoc != null)
                {
                    if (File.Exists(famDoc.PathName))
                    {
                        //if family already exists in family library path then can extract path
                        famDoc = _uiApp.OpenAndActivateDocument(famDoc.PathName).Document;
                        changeToA3DView(_uiApp, famDoc);
                    }
                    else
                    {
                        //Overwrite if command used twice
                        SaveAsOptions saveAsOpt = new SaveAsOptions();
                        saveAsOpt.OverwriteExistingFile = true;
                        //Create a path for family if it doesn't yet exist in a temp folder
                        famDoc.SaveAs(Path.Combine(dumpsterPath, _family.Name + ".rfa"), saveAsOpt);
                        //Attempt to open family again
                        famDoc = _uiApp.OpenAndActivateDocument( Path.Combine(dumpsterPath, _family.Name + ".rfa") ).Document;
                        changeToA3DView(_uiApp, famDoc);
                    }

                }
                else
                { TaskDialog.Show("no famdoc", "No famdoc was found"); }
            }
            else
            { TaskDialog.Show("Gordian-not", "You just cannot open an in-place family"); }


        }//end method


        private static void changeToA3DView(UIApplication _uiApp, Document _famDoc)
        {
            View3D view3d = null;

            if (_famDoc.IsFamilyDocument)
            {
                //create a 3d view if not found
                if (View_Operations.find3DView(_famDoc) == null)
                {
                    view3d = View_Operations.createView(_famDoc);
                    //set this as the active view
                    _uiApp.ActiveUIDocument.ActiveView = view3d;

                }
                else
                {
                    view3d = View_Operations.find3DView(_famDoc);
                    //set this as the active view
                    _uiApp.ActiveUIDocument.ActiveView = view3d;
                }
            }
        }//end threedee method


    }//end class
}//end ns
