﻿namespace Family_Fixer
{
    partial class Form_Showfam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Showfam));
            this.btn_Find_Nxt_Family = new System.Windows.Forms.Button();
            this.btn_Find_Previous_Family = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label_Count = new System.Windows.Forms.Label();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.rchTxtBx_EXERCISE_0 = new System.Windows.Forms.RichTextBox();
            this.picBx_Cube = new System.Windows.Forms.PictureBox();
            this.timer_family = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBx_Cube)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Find_Nxt_Family
            // 
            this.btn_Find_Nxt_Family.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Find_Nxt_Family.Location = new System.Drawing.Point(0, 0);
            this.btn_Find_Nxt_Family.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Find_Nxt_Family.Name = "btn_Find_Nxt_Family";
            this.btn_Find_Nxt_Family.Size = new System.Drawing.Size(193, 42);
            this.btn_Find_Nxt_Family.TabIndex = 0;
            this.btn_Find_Nxt_Family.Text = "Find Next Family";
            this.btn_Find_Nxt_Family.UseVisualStyleBackColor = true;
            this.btn_Find_Nxt_Family.Click += new System.EventHandler(this.btn_Find_Family_Click);
            // 
            // btn_Find_Previous_Family
            // 
            this.btn_Find_Previous_Family.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Find_Previous_Family.Location = new System.Drawing.Point(0, 0);
            this.btn_Find_Previous_Family.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Find_Previous_Family.Name = "btn_Find_Previous_Family";
            this.btn_Find_Previous_Family.Size = new System.Drawing.Size(178, 42);
            this.btn_Find_Previous_Family.TabIndex = 1;
            this.btn_Find_Previous_Family.Text = "Find Previous Family";
            this.btn_Find_Previous_Family.UseVisualStyleBackColor = true;
            this.btn_Find_Previous_Family.Click += new System.EventHandler(this.btn_Find_Previous_Family_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.btn_Find_Previous_Family);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.btn_Find_Nxt_Family);
            this.splitContainer1.Size = new System.Drawing.Size(376, 42);
            this.splitContainer1.SplitterDistance = 178;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 2;
            // 
            // label_Count
            // 
            this.label_Count.AutoSize = true;
            this.label_Count.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_Count.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Count.Location = new System.Drawing.Point(0, 0);
            this.label_Count.Name = "label_Count";
            this.label_Count.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.label_Count.Size = new System.Drawing.Size(60, 34);
            this.label_Count.TabIndex = 3;
            this.label_Count.Text = "Count";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.label_Count);
            this.splitContainer2.Size = new System.Drawing.Size(451, 42);
            this.splitContainer2.SplitterDistance = 376;
            this.splitContainer2.SplitterWidth = 5;
            this.splitContainer2.TabIndex = 4;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.splitContainer4);
            this.splitContainer3.Size = new System.Drawing.Size(451, 295);
            this.splitContainer3.SplitterDistance = 42;
            this.splitContainer3.TabIndex = 5;
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.rchTxtBx_EXERCISE_0);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.picBx_Cube);
            this.splitContainer4.Size = new System.Drawing.Size(451, 249);
            this.splitContainer4.SplitterDistance = 217;
            this.splitContainer4.TabIndex = 2;
            // 
            // rchTxtBx_EXERCISE_0
            // 
            this.rchTxtBx_EXERCISE_0.BackColor = System.Drawing.SystemColors.ControlLight;
            this.rchTxtBx_EXERCISE_0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rchTxtBx_EXERCISE_0.Location = new System.Drawing.Point(0, 0);
            this.rchTxtBx_EXERCISE_0.Name = "rchTxtBx_EXERCISE_0";
            this.rchTxtBx_EXERCISE_0.ReadOnly = true;
            this.rchTxtBx_EXERCISE_0.Size = new System.Drawing.Size(217, 249);
            this.rchTxtBx_EXERCISE_0.TabIndex = 0;
            this.rchTxtBx_EXERCISE_0.Text = "";
            // 
            // picBx_Cube
            // 
            this.picBx_Cube.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picBx_Cube.Location = new System.Drawing.Point(0, 0);
            this.picBx_Cube.Name = "picBx_Cube";
            this.picBx_Cube.Size = new System.Drawing.Size(230, 249);
            this.picBx_Cube.TabIndex = 1;
            this.picBx_Cube.TabStop = false;
            this.picBx_Cube.Paint += new System.Windows.Forms.PaintEventHandler(this.picBx_Cube_Paint);
            // 
            // timer_family
            // 
            this.timer_family.Tick += new System.EventHandler(this.timer_family_Tick);
            // 
            // Form_Showfam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 295);
            this.Controls.Add(this.splitContainer3);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form_Showfam";
            this.Text = "Find A Family";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.form_viewfam_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBx_Cube)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Find_Nxt_Family;
        private System.Windows.Forms.Button btn_Find_Previous_Family;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label_Count;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.RichTextBox rchTxtBx_EXERCISE_0;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.PictureBox picBx_Cube;
        private System.Windows.Forms.Timer timer_family;
    }
}