﻿using Autodesk.Revit.DB;
using System;

namespace Family_Fixer
{
    /// <summary>
    /// Add user who created Family and Date
    /// </summary>
    static class Fam_Version
    {
        //
        public static string AutoFillDate()
        {
            string format = "yyyy:MM";
            return DateTime.Now.ToString(format);
        }


        public static string AutoFillSender()
        {
            return System.Security.Principal.WindowsIdentity.GetCurrent().Name;
        }


        public static string AutoFill_RVTUserName(Document doc)
        {
            return doc.Application.Username;
        }

        /// <summary>
        /// EXERCISE_6 - Change the version parameter to match another company standard
        /// TASK_6.1 - Change the name and date strings to suit your companies format,
        /// add the users complete login name, change the date to include the day. We can change the substring value to
        /// .Substring(0, 8) if we wanted the first 8 initials, what is the danger in this?
        /// we can change format to include days, any guesses to how :dd?
        /// </summary>
        /// <param name="doc"></param>
        /// <returns></returns>
        public static string getVersion(Document doc)
        {
            string strVersion = AutoFill_RVTUserName(doc).ToUpperInvariant() + "." + AutoFillDate();
            if (strVersion != null)
            { return strVersion; }
            else
            { return "null"; }
        }

        }//Class to get personal and machine details from windows and revit doc

}
