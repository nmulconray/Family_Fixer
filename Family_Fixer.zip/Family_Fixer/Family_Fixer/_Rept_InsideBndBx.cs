﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using ComboBox = System.Windows.Forms.ComboBox;

namespace Family_Fixer
{
    static class _Rept_InsideBndBx
    {
        public static string checkInstance(UIDocument _uiDoc, Document _doc, UIApplication _uiApp, Family _family, ComboBox cmbBx_ViewFamilyInstance)
        {  
            //ratio params
            int intFilterCount = 0;
            int intFamInstCount = 0;
            //bounding box filter params
            BoundingBoxXYZ BB = null;
            BoundingBoxIsInsideFilter BBfilter = null;
            List<FamilyInstance> famInst_list = new List<FamilyInstance>();
            List<FamilyInstance> famInst_list_inside_rm = new List<FamilyInstance>();

            famInst_list = familyInstanceFromFamilyList(_doc, _family);

            foreach (FamilyInstance famInst in familyInstanceFromFamilyList(_doc, _family))
            {
                //tally all family instances
                intFamInstCount++;

                    foreach (Room room in placedRoomsList(_doc))
                    {

                    try
                    {//catch room errors

                        //Bounding box
                        BB = room.get_BoundingBox(null);
                        //Outline
                        Outline myOutLn = new Outline(new XYZ(BB.Min.X, BB.Min.Y, BB.Min.Z), new XYZ(BB.Max.X, BB.Max.Y, BB.Max.Z));
                        //Filter from outline
                        BBfilter = new BoundingBoxIsInsideFilter(myOutLn);

                        if (BBfilter.PassesFilter(famInst))
                        {
                            //break out of rm list iteration when rm found
                            intFilterCount++;
                            famInst_list_inside_rm.Add(famInst);

                            break;
                        }

                    }
                    catch (Exception ex)
                    {
                        TaskDialog.Show("Room error", room.Name + ex.Message);
                    }


                }

            }


            ///
            ///Show families where their bounding box is not completely inside a room
            ///
            if (famInst_list.Count > 0 && cmbBx_ViewFamilyInstance.Text == Show_ReptdFamInst.SHOW_FAMILYINSTANCE_OUTSIDE_RM)
            {
                famInst_list.RemoveAll(item => famInst_list_inside_rm.Contains(item));
                _Find_FamInst.showView(_uiDoc, _doc, _uiApp, famInst_list);
            }

            //Return the ratio
            return intFilterCount.ToString() + "/" + intFamInstCount.ToString();

        }



        private static List<FamilyInstance> familyInstanceFromFamilyList(Document _doc, Family _family)
        {
            //family instance list
            List<FamilyInstance> fi_list = new List<FamilyInstance>();


            String ruleValStr = _family.Name;
            BuiltInParameter testParam = BuiltInParameter.ALL_MODEL_FAMILY_NAME;
            ParameterValueProvider pvp = new ParameterValueProvider(new ElementId((int)testParam));
            FilterStringRuleEvaluator fnrvStr = new FilterStringEquals();
            FilterStringRule paramFr = new FilterStringRule(pvp, fnrvStr, ruleValStr, false);
            ElementParameterFilter epf = new ElementParameterFilter(paramFr);



            foreach
            (
            FamilyInstance _familyinstance in new FilteredElementCollector(_doc)
            .OfClass(typeof(FamilyInstance))
            .WherePasses(epf)
            .WhereElementIsNotElementType()
            .Cast<FamilyInstance>()
            //.Where(f => f.Symbol.FamilyName == _family.Name)
            )
            {
                fi_list.Add(_familyinstance);
            }

            return fi_list;
        }



        private static List<Room> placedRoomsList(Document _doc)
        {
            List<Room> spatialObjects_list = new List<Room>();
            List<Room> rm_list = new List<Room>();

            //Ugly and fast filter, to reduce post processing
            double ruleValDb = 0;
            BuiltInParameter testParam = BuiltInParameter.ROOM_AREA;
            ParameterValueProvider pvp = new ParameterValueProvider(new ElementId((int)testParam));
            FilterNumericGreater fnrv = new FilterNumericGreater();
            FilterDoubleRule paramFr = new FilterDoubleRule(pvp, fnrv, ruleValDb, double.Epsilon);
            ElementParameterFilter epf = new ElementParameterFilter(paramFr);


            FilteredElementCollector collection_spat =
            new FilteredElementCollector(_doc)
            .OfClass(typeof(SpatialElement)).WherePasses(epf);




            //Filtered element collector to find all rooms
            foreach (SpatialElement spElem in collection_spat)
            {
                Room room = spElem as Room;

                if (null != room)
                {
                    spatialObjects_list.Add(room);
                }
            }





            //Collector to find rooms meeting criteria
            //Bounded rooms area >0 
            //Placed rooms area > 0 & room.location not null
            foreach
                    (
                    Room rm_element in spatialObjects_list
                    .Cast<Room>()
                    //.Where(r => r.Area > 0)
                    .Where(r => r.Location != null)
                    )
                    {
                        rm_list.Add(rm_element);
                    }
            return rm_list;
        }












    }//end class
}//end ns
