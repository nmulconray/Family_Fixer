﻿using Autodesk.Revit.DB;
using System.Collections.Generic;
using System.Linq;

namespace Family_Fixer
{
    class _Filt_Category
    {
        /// <summary>
        /// EXERCISE_2 - Control which families are visible in the Add-ins GUI, by filtering by their category
        /// TASK_2.1 - Your Company is only concerned with particular Family Categories
        /// and considers the<Electrical Equipment> Category shouldn’t be scheduled.Using
        /// the two forward slashes<//> Comment out the line containing category_list.Add("Electrical Equipment");
        /// </summary>
        /// <param name="family"></param>
        /// <returns></returns>
        public static bool LoadableCategoryList(Family family)
        {
            //family category
            string strfamilyCategory = family.FamilyCategory.Name;


            //Family Categories list
            List<string> category_list = new List<string>();

            category_list.Add("Casework");
            //category_list.Add("Communication Devices");
            //category_list.Add("Doors");
            //category_list.Add("Detail Items");
            category_list.Add("Electrical Equipment");
            //category_list.Add("Electrical Fixtures");
            //category_list.Add("Fire Alarm Devices");
            category_list.Add("Furniture");
            category_list.Add("Furniture Systems");
            category_list.Add("Generic Models");
            //category_list.Add("Lighting Fixtures");
            category_list.Add("Plumbing Fixtures");
            //category_list.Add("Mechanical");
            //category_list.Add("Mechanical Equipment");
            //category_list.Add("Nurse Call Devices");
            //category_list.Add("Security Devices");
            //category_list.Add("Site");
            category_list.Add("Specialty Equipment");
            //category_list.Add("Windows");


            if (category_list.Any(str => str.Contains(strfamilyCategory)))
            { return true; }
            else
            { return false; }
        }
    }
}
