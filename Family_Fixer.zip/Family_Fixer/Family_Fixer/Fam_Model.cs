﻿using Autodesk.Revit.DB;
using System.Collections.Generic;
using System.Drawing;

namespace Family_Fixer
{
    public class Fam_Model
    {
        public string id { get; set; }
        public string unique_id { get; set; }
        public bool fam_qa { get; set; }
        internal bool rm_point_on;
        internal string family_instance_owned_by_rm;
        internal string family_instance_is_inside_rm;
        internal bool filter_from_schedule;
        public Image imgThumb { get; set; }
        public Image img { get; set; }
        public Family fam { get; set; }
        public string ownerCat { get; set; }
        public List<string> category_list { get; set; }
        public List<string> functType_list { get; set; }
        public List<string> subType_list { get; set; }
        public List<string> manufacturer_list { get; set; }
        public List<string> descriptor_list { get; set; }
        public List<FamilyTypeObj> famType_obj { get; set; }
        public List<groupTypeObj> groupType_obj { get; set; }
        //EXERCISE_FINAL
        //TASK_FINAL.4 - In the Family_Model, change scheduleCodeType_list to param_1_list
        public List<string> scheduleCodeType_list { get; set; }
        public List<QSIDTypeObj> QSIDType_obj { get; set; }
        public List<string> descriptionType_list { get; set; }
    }




    public class groupTypeObj
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
    public static class groupType_ObjHelper
    {
        public static List<groupTypeObj> group_list = new List<groupTypeObj>
            {
                new groupTypeObj {Code = "X", Name = "X.Use Group Filter Equals X, To Remove From FFE Schedules"},
                new groupTypeObj {Code = "1", Name = "1.Builder to supply item and builder to install item"},
                new groupTypeObj {Code = "2", Name = "2.Client to supply item and builder to install item"},
                new groupTypeObj {Code = "3", Name = "3.Client to supply item and client to install item"},
                new groupTypeObj {Code = "4", Name = "4.Future allowance for item"},
            };
        public static List<groupTypeObj> GetObj()
        {
            return group_list;
        }    //return list of objects
    }




    public class FamilyTypeObj
    {
        public ElementType famType { get; set; }
        public string Name { get; set; }
    }





    public class QSIDTypeObj
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
        public static class QSID_ObjHelper
        {
            public static List<QSIDTypeObj> qsid_list = new List<QSIDTypeObj>
            {
                new QSIDTypeObj {Code = "NULL", Name = "NULL"},
                new QSIDTypeObj {Code = "01SB", Name = "01SB-SUBSTRUCTURE"},
                new QSIDTypeObj {Code = "02CL", Name = "02CL-COLUMNS"},
                new QSIDTypeObj {Code = "03UF", Name = "03UF-UPPER FLOORS"},
                new QSIDTypeObj {Code = "04SC", Name = "04SC-STAIRCASES"},
                new QSIDTypeObj {Code = "05RF", Name = "05RF-ROOF"},
                new QSIDTypeObj {Code = "06EW", Name = "EXTERNAL WALLS"},
                new QSIDTypeObj {Code = "07WW", Name = "07WW-WINDOWS"},
                new QSIDTypeObj {Code = "08ED", Name = "08ED-EXTERNAL DOORS"},
                new QSIDTypeObj {Code = "09NW", Name = "09NW-INTERNAL WALLS"},
                new QSIDTypeObj {Code = "10NS", Name = "10NS-INTERNAL SCREENS AND BORROWED LIGHTS"},
                new QSIDTypeObj {Code = "11ND", Name = "11ND-INTERNAL DOORS"},
                new QSIDTypeObj {Code = "12WF", Name = "12WF-WALL FINISHES"},
                new QSIDTypeObj {Code = "13FF", Name = "13FF-FLOOR FINISHES"},
                new QSIDTypeObj {Code = "14CF", Name = "14CF-CEILING FINISHES"},
                new QSIDTypeObj {Code = "15FT", Name = "15FT-FITMENTS"},
                new QSIDTypeObj {Code = "16SE", Name = "16SE-SPECIAL EQUIPMENT"},
                new QSIDTypeObj {Code = "17SF", Name = "17SF-SANITARY FIXTURES"},
                new QSIDTypeObj {Code = "18PD", Name = "18PD-SANITARY PLUMBING"},
                new QSIDTypeObj {Code = "19WS", Name = "19WS-WATER SUPPLY"},
                new QSIDTypeObj {Code = "20GS", Name = "20GS-GAS SERVICE"},
                new QSIDTypeObj {Code = "21SH", Name = "21SH-SPACE HEATING"},
                new QSIDTypeObj {Code = "22VE", Name = "22VE-VENTILATION"},
                new QSIDTypeObj {Code = "23EC", Name = "23EC-EVAPORATIVE COOLING"},
                new QSIDTypeObj {Code = "24AC", Name = "24AC-AIR CONDITIONING"},
                new QSIDTypeObj {Code = "25FP", Name = "25FP-FIRE PROTECTION"},
                new QSIDTypeObj {Code = "26LP", Name = "26LP-LIGHT AND POWER"},
                new QSIDTypeObj {Code = "27CM", Name = "27CM-COMMUNICATIONS"},
                new QSIDTypeObj {Code = "28TS", Name = "28TS-TRANSPORTATION SYSTEMS"},
                new QSIDTypeObj {Code = "29SS", Name = "29SS-SPECIAL SERVICES"},
                new QSIDTypeObj {Code = "00PR", Name = "00PR-PROPORTION OF PRELIMINARIES"},
                new QSIDTypeObj {Code = "27CM", Name = "27CM-COMMUNICATIONS"},
                new QSIDTypeObj {Code = "30CE", Name = "30CE-CENTRALISED ENERGY SYSTEMS"},
                new QSIDTypeObj {Code = "31AR", Name = "31AR-ALTERATIONS AND ADDITIONS"},
                new QSIDTypeObj {Code = "32XP", Name = "32XP-SITE PREPARATION"},
                new QSIDTypeObj {Code = "33XR", Name = "33XR-ROADS + FOOTPATHS AND PAVED AREAS"},
                new QSIDTypeObj {Code = "34XN", Name = "34XN-BOUNDARY WALLS + FENCING AND GATES"},
                new QSIDTypeObj {Code = "35XB", Name = "35XB-OUTBUILDINGS AND COVERED WAYS"},
                new QSIDTypeObj {Code = "36XL", Name = "36XL-LANDSCAPING AND IMPROVEMENTS"},
                new QSIDTypeObj {Code = "37XK", Name = "37XK-EXTERNAL STORMWATER DRAINAGE"},
                new QSIDTypeObj {Code = "38XD", Name = "38XD-EXTERNAL SEWER DRAINAGE"},
                new QSIDTypeObj {Code = "34XN", Name = "34XN-BOUNDARY WALLS + FENCING AND GATES"},
                new QSIDTypeObj {Code = "39XW", Name = "39XW-EXTERNAL WATER SUPPLY"},
                new QSIDTypeObj {Code = "40XG", Name = "40XG-EXTERNAL GAS"},
                new QSIDTypeObj {Code = "41XF", Name = "41XF-EXTERNAL FIRE PROTECTION"},
                new QSIDTypeObj {Code = "42XE", Name = "42XE-EXTERNAL ELECTRIC LIGHT AND POWER"},
                new QSIDTypeObj {Code = "43XC", Name = "43XC-EXTERNAL COMMS"},
                new QSIDTypeObj {Code = "44XS", Name = "44XS-EXTERNAL SPECIAL SERVICES"},
                new QSIDTypeObj {Code = "45XX", Name = "45XX-EXTERNAL ALTERATIONS AND RENOVATIONS"},
                new QSIDTypeObj {Code = "OOPR", Name = "PROPORTION OF PRELIMINARIES"},
                new QSIDTypeObj {Code = "46YY", Name = "46YY-SPECIAL PROVISIONS"},

            };

            public static List<QSIDTypeObj> GetObj()
            {
                return qsid_list;
            }    //return list of objects       
        }

}//end ns
