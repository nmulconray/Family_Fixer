﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Family_Fixer
{
    static class _Rept_FamDoc
    {
        //Try to get famDoc Params
        public static bool famDocToSpec(
            UIApplication _uiApp,
            Family _family
            )
            {
            bool boolFamDocSpec = false;

            try
                {
                    //Get Current project doc
                    Document _doc = _uiApp.ActiveUIDocument.Document;
                    //open and edit family from project
                    Document famdoc = _doc.EditFamily(_family);
                    Family OwnerFamily = famdoc.OwnerFamily;

                        if (famdoc != null)
                        {
                            if (controlsExist(famdoc) && twoOriginsExist(famdoc))
                            {
                                boolFamDocSpec = true;
                            }
                        }

                return boolFamDocSpec;

                }//end try
                catch (Exception ex)
                {
                    TaskDialog.Show("FamDoc rept error", "FamDoc Rept error\n" + ex.Message);
                    return false;
                }

            }//end mthd



        //Family Doc - Controls(blue flip arrows) - at least one exists 
        private static bool controlsExist(Document famdoc)
        {
            bool boolControlsExist = false;

            List<Control> arrowControls = new FilteredElementCollector(famdoc)
            .OfClass(typeof(Control))
            .Cast<Control>()
            .ToList();

                if (arrowControls.Count > 0)
                {
                    foreach (Control ac in arrowControls)
                    {
                        if (arrowControls.Count > 0)
                        {
                            XYZ acOrigin = ac.Origin;
                        }
                    }//end loop

                    return boolControlsExist = true;
                }

            return boolControlsExist;
        }






        //Family Doc - Reference Plane Origins - two exists 
        private static bool twoOriginsExist(Document famdoc)
        {
            bool boolHasTwoOrigins = false;
            int intCount = 0;
            int intRefPlaneTotal = 0;

            //Get a list of reference planes in the Family document
            List<ReferencePlane> rPlanes = new FilteredElementCollector(famdoc)
            .OfClass(typeof(ReferencePlane))
            .Cast<ReferencePlane>()
            .ToList();

            intRefPlaneTotal = rPlanes.Count;

                    foreach (ReferencePlane rp in rPlanes)
                    {
                        Parameter param = rp.get_Parameter(BuiltInParameter.DATUM_PLANE_DEFINES_ORIGIN);
                        if (param != null)
                        {
                            if (param.AsInteger() == 1)
                            {
                                intCount++;

                                if (intCount == 2)
                                {
                                    boolHasTwoOrigins = true;
                                    break;
                                }
                            }
                        }
                    }//end loop


                return boolHasTwoOrigins;


        }//origin check






    }//end class
}//end ns