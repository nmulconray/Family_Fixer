﻿namespace Family_Fixer
{
    partial class form_viewfam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_viewfam));
            this.btn_Find_Nxt_Family = new System.Windows.Forms.Button();
            this.btn_Find_Previous_Family = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label_Count = new System.Windows.Forms.Label();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Find_Nxt_Family
            // 
            this.btn_Find_Nxt_Family.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Find_Nxt_Family.Location = new System.Drawing.Point(0, 0);
            this.btn_Find_Nxt_Family.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Find_Nxt_Family.Name = "btn_Find_Nxt_Family";
            this.btn_Find_Nxt_Family.Size = new System.Drawing.Size(184, 45);
            this.btn_Find_Nxt_Family.TabIndex = 0;
            this.btn_Find_Nxt_Family.Text = "Find Next Family";
            this.btn_Find_Nxt_Family.UseVisualStyleBackColor = true;
            this.btn_Find_Nxt_Family.Click += new System.EventHandler(this.btn_Find_Family_Click);
            // 
            // btn_Find_Previous_Family
            // 
            this.btn_Find_Previous_Family.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Find_Previous_Family.Location = new System.Drawing.Point(0, 0);
            this.btn_Find_Previous_Family.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Find_Previous_Family.Name = "btn_Find_Previous_Family";
            this.btn_Find_Previous_Family.Size = new System.Drawing.Size(171, 45);
            this.btn_Find_Previous_Family.TabIndex = 1;
            this.btn_Find_Previous_Family.Text = "Find Previous Family";
            this.btn_Find_Previous_Family.UseVisualStyleBackColor = true;
            this.btn_Find_Previous_Family.Click += new System.EventHandler(this.btn_Find_Previous_Family_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.btn_Find_Previous_Family);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.btn_Find_Nxt_Family);
            this.splitContainer1.Size = new System.Drawing.Size(360, 45);
            this.splitContainer1.SplitterDistance = 171;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 2;
            // 
            // label_Count
            // 
            this.label_Count.AutoSize = true;
            this.label_Count.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_Count.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Count.Location = new System.Drawing.Point(0, 0);
            this.label_Count.Name = "label_Count";
            this.label_Count.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.label_Count.Size = new System.Drawing.Size(60, 34);
            this.label_Count.TabIndex = 3;
            this.label_Count.Text = "Count";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.label_Count);
            this.splitContainer2.Size = new System.Drawing.Size(430, 45);
            this.splitContainer2.SplitterDistance = 360;
            this.splitContainer2.SplitterWidth = 5;
            this.splitContainer2.TabIndex = 4;
            // 
            // form_viewfam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(430, 45);
            this.Controls.Add(this.splitContainer2);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "form_viewfam";
            this.Text = "Find A Family";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.form_viewfam_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Find_Nxt_Family;
        private System.Windows.Forms.Button btn_Find_Previous_Family;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label_Count;
        private System.Windows.Forms.SplitContainer splitContainer2;
    }
}