﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using Application = Autodesk.Revit.ApplicationServices.Application;
using Color = System.Drawing.Color;
using ComboBox = System.Windows.Forms.ComboBox;
using Document = Autodesk.Revit.DB.Document;
using Form = System.Windows.Forms.Form;
using System.Linq;

/// <summary>
/// Populate DataGridView
/// EXERCISE_4 - Refer lab handout this is editing the family_XML file
/// </summary>
namespace Family_Fixer
{
    /// <summary>
    /// Author: nikolai Mulconray
    /// email: nikmulconray.architecture@gmail.com
    /// This is free and unencumbered software released into the public domain.
/*
    Anyone is free to copy, modify, publish, use, compile, sell, or
    distribute this software, either in source code form or as a compiled
    binary, for any purpose, commercial or non-commercial, and by any
    means.

    In jurisdictions that recognize copyright laws, the author or authors
    of this software dedicate any and all copyright interest in the
    software to the public domain.We make this dedication for the benefit
    of the public at large and to the detriment of our heirs and
    successors.We intend this dedication to be an overt act of
    relinquishment in perpetuity of all present and future rights to this
    software under copyright law.


    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
    IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
    OTHER DEALINGS IN THE SOFTWARE.
*/
    /// </summary>




    public partial class Fam_DGV_Form : Form
    {
        //Parameter that recalls the first open document, should be a project
        string _strProjModelPath;

        //Parameter that recalls the previously selected row
        int newRowFromID = 0;
        int CurrentRowIndex = 0;
        List<int> selectedRows_list = new List<int>(); 

        private ExternalEvent _exEvent;
        private Fam_ExternalEvent _handler;

        //List
        public Dictionary<Family, List<ElementType>> family_dictionary = new Dictionary<Family, List<ElementType>>();
        //The state has changed ie the sch filter, hide chcked, has been either checked or unchecked



        //Document handle
        Application _app;
        Document _doc;
        UIDocument _uiDoc;
        UIApplication _uiApp;


        public Fam_DGV_Form(UIApplication uiApp, ExternalEvent exEvent, Fam_ExternalEvent handler)
        {

            InitializeComponent();
            //Publicly expose Revit Handle
            //App
            _uiApp = uiApp;
            _app = uiApp.Application;
            //Doc
            _uiDoc = _uiApp.ActiveUIDocument;
            _doc = _uiDoc.Document;
            _strProjModelPath = _doc.PathName;

            //event handlers
            _handler = handler;
            _exEvent = exEvent;

            //Populate view family instance combo box
            Cmbx_Show_ReptdFamInst.popCmbBx(cmbBx_ViewFamilyInstance);

            ToolTip_Custom tip = new ToolTip_Custom();
            tip.SetToolTip(btn_Swap_FamDoc_RmPoint, "Room Point Location");
            //tip.SetToolTip(btn_Swap_FamDoc_Category, "Swap Category");
            btn_Swap_FamDoc_RmPoint.Tag = Properties.Resources.FamilyGrid2D_Preview; // pull image from the resources file
            //btn_Swap_FamDoc_Category.Tag = Properties.Resources.inplace32;
        }



        private void FF_DatGrd_Form_Load(object sender, EventArgs e)
        {
            //Call To update DataGridView
            bool boolUpdated = PopulateDataGridView();

            //set the selected row to the first row on opening winform
            dataGridView_Fam.CurrentRow.Selected = false;
            dataGridView_Fam.Rows[0].Selected = true;
        }



        //Update DataGridView
        private bool PopulateDataGridView()
        {

            //Build Family Model
            List<Fam_Model> family_model = Fam_Collector.Family_Dictionary(_doc, chkBx_FilterInDGV);

            //Call to Fill Data Grid Views Row by Row 
            fillDataGridViewRows(family_model);
            //Sort only the category programmatically
            this.dataGridView_Fam.Sort(this.FAMILY_NAME, ListSortDirection.Ascending);
            //this.dataGridView_Fam.Sort(this.OWNER_CATEGORY, ListSortDirection.Ascending);


            return true;
        }




        /// <summary>
        /// Fill Data Grid Views Row by Row
        /// </summary>
        /// <param name="family_model"></param>        
        private void fillDataGridViewRows(List<Fam_Model> family_model)
        {
            //Loop through instances of the family model created on form load,
            //add the objects properties to each row in the datagridview 
            foreach (Fam_Model fm in family_model)
            {
                //Families uniqueID
                DataGridViewTextBoxCell UNIQUE_ID = new DataGridViewTextBoxCell();
                UNIQUE_ID.Value = fm.unique_id;


                //Filter from schedule
                //checkbox cell
                DataGridViewCheckBoxCell FILTER_FROM_SCHEDULE_CELL = new DataGridViewCheckBoxCell();
                FILTER_FROM_SCHEDULE_CELL.Value = fm.filter_from_schedule;


                ///Family QA, checks family name structure and specific type parameters are populated
                //Checkbox cell
                DataGridViewTextBoxCell FAMILY_QA_CELL = new DataGridViewTextBoxCell();
                FAMILY_QA_CELL.Value = "No";
                if (fm.fam_qa == true)
                {
                    FAMILY_QA_CELL.Value = "Yes";
                }

                //Inplace Family
                //TextBox cell
                DataGridViewTextBoxCell INPLACE_FAMILY_CELL = new DataGridViewTextBoxCell();
                INPLACE_FAMILY_CELL.Value = "[:(]";

                //Family is nested and it's shared value is checked making it visible in the project schedules
                //TextBox cell
                DataGridViewTextBoxCell SHARED_NESTED_FAMILY_CELL = new DataGridViewTextBoxCell();
                SHARED_NESTED_FAMILY_CELL.Value = "A⊂B";


                //Check for each family all it's instances belong to a room and creates a ratio of..
                //(families owned by room)/(total family instances)
                //textbox cell
                DataGridViewTextBoxCell FAMILY_INSTANCE_OWNED_BY_RM_CELL = new DataGridViewTextBoxCell();
                FAMILY_INSTANCE_OWNED_BY_RM_CELL.Value = fm.family_instance_owned_by_rm;

                //Check for each family all it's instances are inside a room boundingbox and creates a ratio of..
                //(families completely inside a room)/(total family instances)
                //textbox cell
                DataGridViewTextBoxCell FAMILY_INSTANCE_IS_INSIDE_RM_CELL = new DataGridViewTextBoxCell();
                FAMILY_INSTANCE_IS_INSIDE_RM_CELL.Value = fm.family_instance_is_inside_rm;


                //textbox cell
                DataGridViewTextBoxCell FAMILY_DOC_TO_SPEC_CELL = new DataGridViewTextBoxCell();
                FAMILY_DOC_TO_SPEC_CELL.Value = "FD";
                



                //Modify Family Document
                //This will show a checkbox checked as it's room point is on, further the pts location can be set
                //checkbox cell
                DataGridViewCheckBoxCell RM_POINT_ON_CELL = new DataGridViewCheckBoxCell();
                RM_POINT_ON_CELL.Value = fm.rm_point_on;


                //This provides a combobox of all family categories,
                //note if the category is filtered from the collector it wont be visible 
                //cmbbx cell
                DataGridViewComboBoxCell CATEGORY_LIST_CELL = new DataGridViewComboBoxCell();
                foreach (string type in fm.category_list)
                {
                    CATEGORY_LIST_CELL.Items.Add(type);
                }

                ///Rename Family, Add Group parameter to familyinstances
                //Img cell
                DataGridViewImageCell IMAGE_CELL = new DataGridViewImageCell();
                IMAGE_CELL.Value = fm.imgThumb;
                IMAGE_CELL.Tag = fm.img;


                //textbox cell
                DataGridViewTextBoxCell FAMILY_NAME_CELL = new DataGridViewTextBoxCell();
                FAMILY_NAME_CELL.Value = fm.fam.Name;
                FAMILY_NAME_CELL.Tag = fm.fam;

                //Use this property to determine current category and then upon clicking on the cell,
                //reduce the options in the next combobox 
                //textbox cell
                DataGridViewTextBoxCell CATEGORY_NAME_CELL = new DataGridViewTextBoxCell();
                CATEGORY_NAME_CELL.Value = fm.ownerCat;

                //cmbbx cell
                DataGridViewComboBoxCell FUNCTTYPE_LIST_CELL = new DataGridViewComboBoxCell();
                foreach (string type in fm.functType_list)
                {
                    FUNCTTYPE_LIST_CELL.Items.Add(type);
                }
                //cmbbx cell
                DataGridViewComboBoxCell SUBTYPE_LIST_CELL = new DataGridViewComboBoxCell();
                foreach (string type in fm.subType_list)
                {
                    SUBTYPE_LIST_CELL.Items.Add(type);
                }

                //cmbbx cell
                DataGridViewComboBoxCell MANUFACTURER_LIST_CELL = new DataGridViewComboBoxCell();
                foreach (string type in fm.manufacturer_list)
                {
                    MANUFACTURER_LIST_CELL.Items.Add(type);
                }

                //cmbbx cell
                DataGridViewComboBoxCell DESCRIPTOR_LIST_CELL = new DataGridViewComboBoxCell();
                foreach (string type in fm.descriptor_list)
                {
                    DESCRIPTOR_LIST_CELL.Items.Add(type);
                }

                //cmbbx cell
                DataGridViewComboBoxCell GROUP_LIST_CELL = new DataGridViewComboBoxCell();
                GROUP_LIST_CELL.DataSource = fm.groupType_obj;
                GROUP_LIST_CELL.DisplayMember = "Name";
                GROUP_LIST_CELL.ValueMember = "Code";




                ///Make new family types or add parameters
                //cmbbx cell
                DataGridViewComboBoxCell FAMILY_TYPE_LIST_CELL = new DataGridViewComboBoxCell();
                FAMILY_TYPE_LIST_CELL.DataSource = fm.famType_obj;
                FAMILY_TYPE_LIST_CELL.DisplayMember = "Name";
                FAMILY_TYPE_LIST_CELL.ValueMember = "famType";

                //EXERCISE_FINAL
                //TASK_FINAL.3 - Rename the <SCHEDULE_CODE_TYPES_LIST_CELL> to <PARAM_1_TYPES_LIST_CELL>, when asked if you want to update
                //other parameter names click yes. this will update the parameter name that is added to the row
                //cmbbx cell
                DataGridViewComboBoxCell SCHEDULE_CODE_TYPES_LIST_CELL = new DataGridViewComboBoxCell();
                foreach (string str in fm.scheduleCodeType_list)
                {
                    SCHEDULE_CODE_TYPES_LIST_CELL.Items.Add(str);
                }

                //cmbbx cell
                DataGridViewComboBoxCell QSID_CODE_TYPES_LIST_CELL = new DataGridViewComboBoxCell();
                QSID_CODE_TYPES_LIST_CELL.DataSource = fm.QSIDType_obj;
                QSID_CODE_TYPES_LIST_CELL.DisplayMember = "Name";
                QSID_CODE_TYPES_LIST_CELL.ValueMember = "Code";

                //cmbbx cell
                DataGridViewComboBoxCell DESCRIPTION_TYPES_LIST_CELL = new DataGridViewComboBoxCell();
                foreach (string str in fm.descriptionType_list)
                {
                    DESCRIPTION_TYPES_LIST_CELL.Items.Add(str);
                }


                ///////// MAKE NEW ROW AND ADD CELLS
                DataGridViewRow row = new DataGridViewRow();
                //Add Cells To Rows
                //UniqueID a hidden parameter
                row.Cells.Add(UNIQUE_ID);
                //Filter from schedules and hide in addin
                row.Cells.Add(FILTER_FROM_SCHEDULE_CELL);
                //Report on Family Instances
                row.Cells.Add(FAMILY_QA_CELL);
                row.Cells.Add(INPLACE_FAMILY_CELL);
                row.Cells.Add(SHARED_NESTED_FAMILY_CELL);
                row.Cells.Add(FAMILY_INSTANCE_OWNED_BY_RM_CELL);
                row.Cells.Add(FAMILY_INSTANCE_IS_INSIDE_RM_CELL);
                row.Cells.Add(FAMILY_DOC_TO_SPEC_CELL); 
                //Amend Family
                row.Cells.Add(RM_POINT_ON_CELL);
                row.Cells.Add(CATEGORY_LIST_CELL);
                //Rename and add instance params to Family
                row.Cells.Add(IMAGE_CELL);
                row.Cells.Add(FAMILY_NAME_CELL);
                row.Cells.Add(CATEGORY_NAME_CELL);
                row.Cells.Add(FUNCTTYPE_LIST_CELL);
                row.Cells.Add(SUBTYPE_LIST_CELL);
                row.Cells.Add(MANUFACTURER_LIST_CELL);
                row.Cells.Add(DESCRIPTOR_LIST_CELL);
                row.Cells.Add(GROUP_LIST_CELL);
                //add type and type parameters
                row.Cells.Add(FAMILY_TYPE_LIST_CELL);
                //EXERCISE_FINAL
                //TASK_FINAL.3 - Check Parameter has been updated to the value between the..
                //Less than greater than symbols <PARAM_1_TYPES_LIST_CELL>
                row.Cells.Add(SCHEDULE_CODE_TYPES_LIST_CELL);
                row.Cells.Add(QSID_CODE_TYPES_LIST_CELL);
                row.Cells.Add(DESCRIPTION_TYPES_LIST_CELL);

                ///// ADD ENTIRE ROW TO DATA GRID
                //Set all row heights to 28
                row.Height = 32;

                this.dataGridView_Fam.Rows.Add(row);
            }

            //Call to set Column header colours
            Dgv_ColHeadColour.setColHeader(dataGridView_Fam);


        }//end of building data grid view






        /// <summary>
        /// Call Value Changed, to populate another cell on same row
        /// </summary>
        private void dataGridView_Family_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView senderGrid = (DataGridView)sender;

            //Only update on user changing a cell value in the family naming components column
            if (e.RowIndex >= 0)
            {
                //Functional type
                if (senderGrid.Columns[e.ColumnIndex] == this.dataGridView_Fam.Columns[Dgv_Col_Name.FUNCTIONAL_TYPE])
                {
                    FilterCmbBxCellsOnUserSelection(senderGrid, Dgv_Col_Name.FUNCTIONAL_TYPE, Dgv_Col_Name.SUB_TYPE);
                }
                //Sub Type
                if (senderGrid.Columns[e.ColumnIndex] == this.dataGridView_Fam.Columns[Dgv_Col_Name.SUB_TYPE])
                {
                    FilterCmbBxCellsOnUserSelection(senderGrid, Dgv_Col_Name.SUB_TYPE, Dgv_Col_Name.DESCRIPTOR);
                }
                //Manufacturer
                if (senderGrid.Columns[e.ColumnIndex] == this.dataGridView_Fam.Columns[Dgv_Col_Name.DESCRIPTOR])
                {
                    FilterCmbBxCellsOnUserSelection(senderGrid, Dgv_Col_Name.DESCRIPTOR, Dgv_Col_Name.MANUFACTURER);
                }


                if (senderGrid.Columns[e.ColumnIndex] == this.dataGridView_Fam.Columns[Dgv_Col_Name.FUNCTIONAL_TYPE] ||
                    senderGrid.Columns[e.ColumnIndex] == this.dataGridView_Fam.Columns[Dgv_Col_Name.SUB_TYPE] ||
                    senderGrid.Columns[e.ColumnIndex] == this.dataGridView_Fam.Columns[Dgv_Col_Name.MANUFACTURER] ||
                    senderGrid.Columns[e.ColumnIndex] == this.dataGridView_Fam.Columns[Dgv_Col_Name.DESCRIPTOR]
                    )
                {
                    string strSelectFamNameText =
                    Fam_Amend_Field.format(Convert.ToString(dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.FUNCTIONAL_TYPE].FormattedValue.ToString())) +
                    "_" +
                    Fam_Amend_Field.format(Convert.ToString(dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.SUB_TYPE].FormattedValue.ToString())) +
                    "_" +
                    (Convert.ToString(dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.MANUFACTURER].FormattedValue.ToString())).ToUpper() +
                    "_" +
                    Fam_Amend_Field.format(Convert.ToString(dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.DESCRIPTOR].FormattedValue.ToString()));

                    ///
                    ///Set The New Family Name
                    ///
                    rchTxtBx_NewFamilyName.Text = strSelectFamNameText;
                }

                //Only update on user changing a cell value in the family naming components column
                fillRchTxtBx(sender, Dgv_Col_Name.FAMILY_TYPES, rchTxtBx_FamTypeAndParam);
                fillRchTxtBx(sender, Dgv_Col_Name.GROUP, rchTxtBx_Group);
                fillRchTxtBx(sender, Dgv_Col_Name.SCHEDULE_CODE_TYPES, rchTxtBx_SCH_Code);
                fillRchTxtBx(sender, Dgv_Col_Name.QSID_CODE_TYPES, rchTxtBx_QSID);
                fillRchTxtBx(sender, Dgv_Col_Name.DESCRIPTION_TYPES, rchTxtBx_Description);
            }
        }//end mthd








        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="strColumnName"></param>
        /// <param name="rchTxtBx"></param>
        private void fillRchTxtBx(object sender, string strColumnName, RichTextBox rchTxtBx)
        {
            var senderGrid = (DataGridView)sender;
            string strCmbBxSelectedText =
                Fam_Amend_Field.format(Convert.ToString(dataGridView_Fam.CurrentRow.Cells[strColumnName].FormattedValue.ToString()));
            ///Set parameter value
            rchTxtBx.Text = strCmbBxSelectedText;
        }






        /// <summary>
        /// Cell Click - Enables One click ComboBox drop
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView_Family_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Enables one click operation
            var senderGrid = sender as DataGridView;

            // Check to make sure the cell clicked is the cell containing the combobox 
            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewComboBoxColumn && (e.RowIndex != -1))
            {

                dataGridView_Fam.DefaultCellStyle.SelectionForeColor = Color.BlueViolet;

                senderGrid.BeginEdit(true);
                ((ComboBox)senderGrid.EditingControl).DroppedDown = true;

            }

            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewTextBoxColumn && (e.RowIndex != -1))
            {
                List<string> newAttrb_list = new List<string>();

                //Build a new list from user selected value
                newAttrb_list = Fam_XML.addInnerField_FromFamilyXML(
                    Convert.ToString(dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.OWNER_CATEGORY].FormattedValue.ToString()),
                    Dgv_Col_Name.CATEGORY,
                    Dgv_Col_Name.FUNCTIONAL_TYPE
                    );

                if (newAttrb_list != null)
                {
                    //Clear Cell
                    (senderGrid.CurrentRow.Cells[Dgv_Col_Name.FUNCTIONAL_TYPE] as DataGridViewComboBoxCell).Items.Clear();
                    //repopulate cell
                    (senderGrid.CurrentRow.Cells[Dgv_Col_Name.FUNCTIONAL_TYPE] as DataGridViewComboBoxCell).Items.AddRange(newAttrb_list.ToArray());
                }
            }

        }//end mthd







        /// <summary>
        /// Enables autocomplete search in Comboboxes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView_Family_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (e.Control is DataGridViewComboBoxEditingControl)
            {
                ((ComboBox)e.Control).DropDownStyle = ComboBoxStyle.DropDown;
                ((ComboBox)e.Control).AutoCompleteSource = AutoCompleteSource.ListItems;
                ((ComboBox)e.Control).AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            }
        }//end mthd






        /// <summary>
        /// 
        /// </summary>
        /// <param name="senderGrid"></param>
        /// <param name="famAttribute"></param>
        /// <param name="famSubAttribute"></param>
        private void FilterCmbBxCellsOnUserSelection(DataGridView senderGrid, string famAttribute, string famSubAttribute)
        {
            List<string> newAttrb_list = new List<string>();

            //Get Selected Value from cell
            string strSelectedValue = Convert.ToString(dataGridView_Fam.CurrentRow.Cells[famAttribute].FormattedValue.ToString());
            //
            if (strSelectedValue != null)
            {
                //Build a new list from user selected value
                newAttrb_list = Fam_XML.addInnerField_FromFamilyXML(strSelectedValue, famAttribute, famSubAttribute);

                if (newAttrb_list != null)
                {
                    //Clear Cell
                    (senderGrid.CurrentRow.Cells[famSubAttribute] as DataGridViewComboBoxCell).Items.Clear();
                    //repopulate cell
                    (senderGrid.CurrentRow.Cells[famSubAttribute] as DataGridViewComboBoxCell).Items.AddRange(newAttrb_list.ToArray());
                }
            }
        }



        ///
        ///Events Raised by User
        ///
        /// 


        ///
        ///Filter From Schedule, uses multi row selection
        ///
        private void btn_FilterFromSchedule_Global_Click(object sender, EventArgs e)
        {
            Dictionary<Family, bool> fam_schFilter_dict = new Dictionary<Family, bool>();

            foreach (DataGridViewRow row in dataGridView_Fam.SelectedRows)
            {

                //*Note don't remember rows for sch_filter as user can inadvertently select and hide families
                //Get the SCH_Filter Value from the DGV
                bool boolSCHFilter = false;
                if(   (bool)(row.Cells[Dgv_Col_Name.FILTER_FROM_SCHEDULE] as DataGridViewCheckBoxCell).Value == true )
                {
                    boolSCHFilter = false;
                }
                if ((bool)(row.Cells[Dgv_Col_Name.FILTER_FROM_SCHEDULE] as DataGridViewCheckBoxCell).Value == false)
                {
                    boolSCHFilter = true;
                }

                //get the family from the cell tag
                Family family = (Family)row.Cells[Dgv_Col_Name.FAMILY_NAME].Tag;


                    if (family != null)
                    {
                    fam_schFilter_dict.Add(family, boolSCHFilter);
                    }

                   
            }//end for loop


            
                _handler.scheduleFilter(
                    Btn_Call.SCH_FILTER,
                    fam_schFilter_dict,
                    Fam_SharedParam.SCH_FILTER_SP,
                    CurrentRowIndex
                    );
                _exEvent.Raise();

        }//end event


        //Refresh after state change
        private void chkBx_FilterInDGV_CheckedChanged(object sender, EventArgs e)
        {

            // refresh DataGrid
            RefreshDataGridView(Btn_Call.SCH_FILTER);
        }




        /// <summary>
        /// Run Report, uses multi row selction
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_RunReport_Click(object sender, EventArgs e)
        {
            //Warning color
            Color warningRGBColor = Color.FromArgb(225, 164, 5);

            //Iterate through each row in the datagridview and perform the operations below
            foreach (DataGridViewRow row in dataGridView_Fam.SelectedRows)
            {

                //Get the family from the cell tag
                Family _family = (Family)row.Cells[Dgv_Col_Name.FAMILY_NAME].Tag;


                //0. Check if family is to specification, just the start!, should also see if main extrusions below ref plane
                if (!_family.IsInPlace && _Rept_FamDoc.famDocToSpec(_uiApp, _family) == true)
                {
                    row.Cells[Dgv_Col_Name.FAMILY_DOC_TO_SPEC].Value = "Yes";
                }
                else
                {
                    row.Cells[Dgv_Col_Name.FAMILY_DOC_TO_SPEC].Value = "No";
                    row.Cells[Dgv_Col_Name.FAMILY_DOC_TO_SPEC].Style.BackColor = warningRGBColor;
                }



                //1. Show all family instances if reqd by user
                if (cmbBx_ViewFamilyInstance.Text == Show_ReptdFamInst.SHOW_ALL_FAMILYINSTANCE)
                {
                    _Rept_AllFamInst.checkInstance(_uiDoc, _doc, _uiApp, _family, cmbBx_ViewFamilyInstance);
                }


                //2. Family Is Quality Assured, well by a rule
                if (_Filt_FamTypeHasParamValue.ParamValueExist(_doc, _family) == true)
                {
                    row.Cells[Dgv_Col_Name.FAMILY_QA].Value = "Yes";
                }             
                else
                {
                    row.Cells[Dgv_Col_Name.FAMILY_QA].Value = "No";
                    row.Cells[Dgv_Col_Name.FAMILY_QA].Style.BackColor = warningRGBColor;
                }


                //3.family is inplace
                (row.Cells[Dgv_Col_Name.INPLACE_FAMILY] as DataGridViewTextBoxCell).Value = "No";
                if (_Rept_Inplace.checkInstance(_uiDoc, _doc, _family, _uiApp, cmbBx_ViewFamilyInstance) == true)
                {
                    (row.Cells[Dgv_Col_Name.INPLACE_FAMILY] as DataGridViewTextBoxCell).Value = "Yes";
                    row.Cells[Dgv_Col_Name.INPLACE_FAMILY].Style.BackColor = warningRGBColor;
                }


                //4.Nested Families in Proj (check logic in test project)
                (row.Cells[Dgv_Col_Name.SHARED_NESTED_FAMILY] as DataGridViewTextBoxCell).Value = "No";
                if (_Rept_NestedAndShared.checkInstance(_uiDoc, _doc, _uiApp, _family, cmbBx_ViewFamilyInstance) == true)
                {
                    (row.Cells[Dgv_Col_Name.SHARED_NESTED_FAMILY] as DataGridViewTextBoxCell).Value = "Yes";
                    row.Cells[Dgv_Col_Name.SHARED_NESTED_FAMILY].Style.BackColor = warningRGBColor;
                }


                //5.Ratio of family instances Owned$ to total num family instances per family
                string strInsideRatio_a = _Rept_OwnedByRm.checkInstance(_uiDoc, _doc, _uiApp, _family, cmbBx_ViewFamilyInstance);
                (row.Cells[Dgv_Col_Name.FAMILY_INSTANCE_OWNED_BY_RM] as DataGridViewTextBoxCell).Value = strInsideRatio_a;
                string[] strArrayInside = strInsideRatio_a.Split('/');
                if (Convert.ToInt16(strArrayInside[1]) != 0 && Convert.ToInt16(strArrayInside[0]) / Convert.ToInt16(strArrayInside[1]) != 1)
                {
                    row.Cells[Dgv_Col_Name.FAMILY_INSTANCE_OWNED_BY_RM].Style.BackColor = warningRGBColor;
                }



                //6.Ratio of family instances inside>< to total num family instances per family
                string strInsideRatio_b = _Rept_InsideBndBx.checkInstance(_uiDoc, _doc, _uiApp, _family, cmbBx_ViewFamilyInstance);
                (row.Cells[Dgv_Col_Name.FAMILY_INSTANCE_IS_INSIDE_RM] as DataGridViewTextBoxCell).Value = strInsideRatio_b;
                string[] strArrayInside_b = strInsideRatio_b.Split('/');
                if (Convert.ToInt16(strArrayInside[1]) != 0 && Convert.ToInt16(strArrayInside[0]) / Convert.ToInt16(strArrayInside[1]) != 1)
                {
                    row.Cells[Dgv_Col_Name.FAMILY_INSTANCE_IS_INSIDE_RM].Style.BackColor = warningRGBColor;
                }


                //7.Family name convention is correct
                if (_Filt_FamilyName.famFileStructureChecker( (string)(row.Cells[Dgv_Col_Name.FAMILY_NAME] as DataGridViewTextBoxCell).Value) == false)
                {
                    row.Cells[Dgv_Col_Name.FAMILY_NAME].Style.BackColor = warningRGBColor;
                }



                //8. Reset Combobx back to idle option for finding a family instance against a rule in view
                int indexFIR = cmbBx_ViewFamilyInstance.FindString(Show_ReptdFamInst.NONE);
                cmbBx_ViewFamilyInstance.SelectedIndex = indexFIR;
               


            }//end for loop
        }//end event







        /// <summary>
        /// Swap Room Pointsx
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Swap_FamDoc_RmPoint_Click(object sender, EventArgs e)
        {
            Dictionary<Family, bool> family_dict = new Dictionary<Family, bool>();
            double _pickPt_X = 0;
            double _pickPt_Y = 0;
            double _pickPt_Z = 0;

            foreach (DataGridViewRow row in dataGridView_Fam.SelectedRows)
            {
                //Remember the selected rows after refreshing the dgv
                selectedRows_list.Add(row.Index);


                //get the family from the cell tag
                Family familyInProject = (Family)row.Cells[Dgv_Col_Name.FAMILY_NAME].Tag;

                if (!familyInProject.IsInPlace)
                {
                    ///Call modeless form to pick 2d coordinate point of room awareness
                    using (Form_2DPicker form2DPicker = new Form_2DPicker())
                    {
                        form2DPicker.ShowDialog();

                        //form2DPicker.buttonOK.DialogResult = DialogResult.OK;
                        //form2DPicker.buttonCancel.DialogResult = DialogResult.Cancel;

                        //var result = new Form_2DPicker();
                        //result.Result = form2DPicker.ShowDialog();

                        //if (result.Result == DialogResult.OK)
                        //{
                           _pickPt_X = form2DPicker.pickPt_X;
                           _pickPt_Y = form2DPicker.pickPt_Y;
                           _pickPt_Z = form2DPicker.pickPt_Z;

                            //TaskDialog.Show("2d point", ",ptx:" + _pickPt_X + ",pty:" + _pickPt_Y + ",ptz:" + _pickPt_Z);
                        //}
                        //return result;   
                        //}
                    }





                    //Get the Rm_Point_On Value from the DGV
                    bool boolRmPointOn = false;
                    if ((bool)(row.Cells[Dgv_Col_Name.RM_POINT_ON] as DataGridViewCheckBoxCell).Value == true)
                    {
                        boolRmPointOn = false;
                    }
                    if ((bool)(row.Cells[Dgv_Col_Name.RM_POINT_ON] as DataGridViewCheckBoxCell).Value == false)
                    {
                        boolRmPointOn = true;
                    }

                    family_dict.Add(familyInProject, boolRmPointOn);

                    _handler.showRmPt(
                        Btn_Call.SHOW_RM_PT,
                        _uiApp,
                        _strProjModelPath,
                        family_dict,
                        chkBx_SetProjUnits,
                        chkBx_DeleteSharedParam,
                        _pickPt_X,
                        _pickPt_Y,
                        _pickPt_Z
                        );
                    _exEvent.Raise();


                }
                else
                {
                    //Clear selected rows to prevent selected rows accumulating rows each run
                    selectedRows_list.Clear();
                    TaskDialog.Show("Warning In-Place", familyInProject.Name + ", Family Doc cannot be updated as it's in-place");
                }//end if

            }//end loop through selected rows

        }//end event




        /// <summary>
        /// Swap Categoryx
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Swap_FamDoc_Category_Click(object sender, EventArgs e)
        {
            Dictionary<Family, string> family_dict = new Dictionary<Family, string>();

            foreach (DataGridViewRow row in dataGridView_Fam.SelectedRows)
            {
                //Remember the selected rows after refreshing the dgv
                selectedRows_list.Add(row.Index);

                //get the family from the cell tag
                Family familyInProject = (Family)row.Cells[Dgv_Col_Name.FAMILY_NAME].Tag;

                if (!familyInProject.IsInPlace)
                {
                    //Get Selected Value from CATEGORY cell, set to it's original category as user may not change
                    string strSelectedCategory = Convert.ToString(row.Cells[Dgv_Col_Name.OWNER_CATEGORY].FormattedValue.ToString());
                    strSelectedCategory = Convert.ToString(row.Cells[Dgv_Col_Name.CATEGORY].FormattedValue.ToString());

                    family_dict.Add(familyInProject, strSelectedCategory);

                    _handler.SwapCategory(
                        Btn_Call.SWAP_CATEGORY,
                        _uiApp,
                        _strProjModelPath,
                        family_dict,
                        chkBx_SetProjUnits,
                        chkBx_DeleteSharedParam
                        );
                    _exEvent.Raise();


                }
                else
                {
                    //Clear selected rows to prevent selected rows accumulating rows each run
                    selectedRows_list.Clear();
                    TaskDialog.Show("Warning In-Place", familyInProject.Name + ", Family Doc cannot be updated as it's in-place");
                }//end if

            }//end loop


        }//end event







        /// <summary>
        /// Update family Name and Parameters x
        /// </summary>
        private void btn_UpdateFamNameAndParam_Click(object sender, EventArgs e)
        {
            //Project - Rename Family
                _handler.renameFamily(
                Btn_Call.RENAME_FAMILY,
                (Family)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.FAMILY_NAME].Tag,
                rchTxtBx_NewFamilyName.Text
                );
                _exEvent.Raise();
        }

        /// <summary>
        /// Project - Add Instance Parameter Values x
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_InstanceParams_Click(object sender, EventArgs e)
        {
            ///USE OVERLOADED METHODS FOR ADDITIONAL METHODS
            ///Set Family attributes

            //Get the Group
            string strGroup = (string)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.GROUP].Value;

            //Project - Add Parameter Values to family instances
            if (strGroup != null)
            {
                _handler.SetInstanceParam(
                Btn_Call.SET_INSTANCE_PARAM,
                (Family)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.FAMILY_NAME].Tag,
                Fam_SharedParam.GROUP_SP,
                strGroup
                );
                _exEvent.Raise();
            }
        }



        /// <summary>
        /// Update family types and add parameters x
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_UpdateFamTypeAndParam_Click(object sender, EventArgs e)
        {
            //Get the element type
            ElementType elementType = (ElementType)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.FAMILY_TYPES].Value;

            //Get the SCH_Code
            string strSCH_Code = (string)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.SCHEDULE_CODE_TYPES].Value;
            //Get the QSID_Code
            string strQSID_Code = (string)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.QSID_CODE_TYPES].Value;
            //Get the Description
            string strDescription = (string)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.DESCRIPTION_TYPES].Value;
            //Get The Manufacturer
            string strManufacturer = (string)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.MANUFACTURER].Value;
            //Get The Version
            string strVersion = Fam_Version.getVersion(_doc);

            if (elementType != null)
            {

                _handler.RenameFamType(
                   Btn_Call.RENAME_FAM_TYPE,
                   elementType,
                    rchTxtBx_FamTypeAndParam.Text,
                    strSCH_Code,
                    strQSID_Code,
                    strDescription,
                    strManufacturer,
                    strVersion
                   );
                _exEvent.Raise();


            }//end if elemtype not null


        }//end mthd




        /// <summary>
        /// Duplicate Element Type
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Create_FamilyType_Click(object sender, EventArgs e)
        {
            //Get the family
            Family family = ((Family)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.FAMILY_NAME].Tag);
            //Get the element type
            ElementType elementType = (ElementType)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.FAMILY_TYPES].Value;
            //Get the type count
            int typeCount = ((Family)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.FAMILY_NAME].Tag).GetFamilySymbolIds().Count;

            //Get the SCH_Code
            string strSCH_Code = (string)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.SCHEDULE_CODE_TYPES].Value;
            //Get the QSID_Code
            string strQSID_Code = (string)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.QSID_CODE_TYPES].Value;
            //Get the Description
            string strDescription = (string)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.DESCRIPTION_TYPES].Value;
            //Get The Manufacturer
            string strManufacturer = (string)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.MANUFACTURER].Value;
            //Get The Version
            string strVersion = Fam_Version.getVersion(_doc);





            if (elementType != null)
            {
                //Add Family Type
                _handler.AddFamType(
                   Btn_Call.ADD_FAM_TYPE,
                   family,
                   elementType,
                   ((Family)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.FAMILY_NAME].Tag).GetFamilySymbolIds().Count,
                    rchTxtBx_FamTypeAndParam.Text,
                    strSCH_Code,
                    strQSID_Code,
                    strDescription,
                    strManufacturer,
                    strVersion
                   );
                _exEvent.Raise();

            }

        }//end mthd




        /// <summary>
        /// Delete Family Type
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Delete_Type_Click(object sender, EventArgs e)
        {
            _handler.DelFamType(            
               Btn_Call.DEL_FAM_TYPE,
               (ElementType)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.FAMILY_TYPES].Value,
               ((Family)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.FAMILY_NAME].Tag).GetFamilySymbolIds().Count
               );
            _exEvent.Raise();

        }//end mthd






        /// <summary>
        /// Open family doc on user right mouse clicking x
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView_Fam_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            //Check for user right mouse click
            if (e.Button == MouseButtons.Right)
            {
                int rowSelected = e.RowIndex;
                if (e.RowIndex != -1)
                {
                    //Open and view family doc
                    _handler.openFamDoc(
                    Btn_Call.OPEN_FAMILY,
                    (Family)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.FAMILY_NAME].Tag
                    );
                    _exEvent.Raise();

                }
            }
        }






        /// <summary>
        /// Error Swallower of Sorts, if user clicks on rows without a selected item in the comboboxcell
        /// </summary>
        private void dataGridView_Family_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            //place your own dialog or do nothing here
        }

        /// <summary>
        /// Form close event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            // we own both the event and the handler
            // we should dispose it before we are closed
            _exEvent.Dispose();
            _exEvent = null;
            _exEvent = null;

            // do not forget to call the base class
            base.OnFormClosed(e);
        }
        /// <summary>
        ///   Exit - closing the dialog
        /// </summary>
        /// 
        private void btnExit_Click(object sender, EventArgs e)
        {
            TaskDialog.Show("closed","frm closed");
            Close();
        }




        /// <summary>
        /// Refresh The DataGrid
        /// </summary>
        /// <returns></returns>
        public bool RefreshDataGridView(string _strWhichBtnIsRefreshing)
        {
            //get dgv row position
            //CurrentRowIndex = (dataGridView_Fam.CurrentRow.Index);

            string strRowUniqueID = (string)dataGridView_Fam.CurrentRow.Cells[Dgv_Col_Name.UNIQUE_ID].Value;


            //clear old rows first
            dataGridView_Fam.Rows.Clear();
            //Populate dgv
            PopulateDataGridView();

            //after refresh set back to original dgv selected row
            //dataGridView_Fam.ClearSelection();

     
                try
                {
                //find a Row that has the same uniqueID as previously selected, we can reset the selected
                foreach (DataGridViewRow row in dataGridView_Fam.Rows)
                {
                    if (Convert.ToString(row.Cells[Dgv_Col_Name.UNIQUE_ID].FormattedValue.ToString()) == strRowUniqueID)
                    {
                        newRowFromID = row.Index;
                        break;
                    }
                }


                // The following are the three different behaviours created dependent on what button is pressed ie rename_family, needs to rely on the uniqueID, family doc needs to rely on the formerly selectred row 
                switch (_strWhichBtnIsRefreshing)
                {

                    case Btn_Call.SCH_FILTER:
                        {
                            dataGridView_Fam.CurrentRow.Selected = false;
                            break;
                        }
                    case Btn_Call.SHOW_RM_PT:
                        {
                            dataGridView_Fam.CurrentRow.Selected = false;
                            foreach (int row in selectedRows_list)
                            {
                                dataGridView_Fam.Rows[row].Selected = true;
                            }

                            //Clear selected rows to prevent selected rows accumulating rows each run
                            selectedRows_list.Clear();

                            break;
                        }
                    case Btn_Call.SWAP_CATEGORY:
                        {
                            dataGridView_Fam.CurrentRow.Selected = false;
                            foreach (int row in selectedRows_list)
                            {
                                dataGridView_Fam.Rows[row].Selected = true;
                            }

                            //Clear selected rows to prevent selected rows accumulating rows each run
                            selectedRows_list.Clear();

                            break;
                        }
                    case Btn_Call.OPEN_FAMILY:
                        {
                            dataGridView_Fam.CurrentRow.Selected = false;
                            //Set the selected row back to its original
                            dataGridView_Fam.Rows[newRowFromID].Selected = true;
                            break;
                        }
                    case Btn_Call.RENAME_FAMILY:
                        {
                            dataGridView_Fam.CurrentRow.Selected = false;
                            //Set the selected row back to its original
                            dataGridView_Fam.Rows[newRowFromID].Selected = true;
                            break;
                        }
                    case Btn_Call.SET_INSTANCE_PARAM:
                        {
                            dataGridView_Fam.CurrentRow.Selected = false;
                            //Set the selected row back to its original
                            dataGridView_Fam.Rows[newRowFromID].Selected = true;
                            break;
                        }
                    case Btn_Call.RENAME_FAM_TYPE:
                        {
                            dataGridView_Fam.CurrentRow.Selected = false;
                            //Set the selected row back to its original
                            dataGridView_Fam.Rows[newRowFromID].Selected = true;
                            break;
                        }

                    case Btn_Call.ADD_FAM_TYPE:
                        {
                            dataGridView_Fam.CurrentRow.Selected = false;
                            //Set the selected row back to its original
                            dataGridView_Fam.Rows[newRowFromID].Selected = true;
                            break;
                        }

                    case Btn_Call.DEL_FAM_TYPE:
                        {
                            dataGridView_Fam.CurrentRow.Selected = false;
                            //Set the selected row back to its original
                            dataGridView_Fam.Rows[newRowFromID].Selected = true;
                            break;
                        }

                       
                    default:
                        {
                            //add error report
                            break;
                        }
                }

            }
            catch
            {
                //stop errors if user hides this row, with schedule filter
            }


            return true;
        }

        private void dataGridView_Fam_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //
        }
    }//end class
    }//end ns
