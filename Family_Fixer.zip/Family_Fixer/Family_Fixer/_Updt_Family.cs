﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;

namespace Family_Fixer
{
    static class _Updt_Family
    {


        //Rename family
        public static void editFamAttributes(Document _doc, Family oldFamily, string strNewfamilyName)
        {

            try
            {
                //If user doesn't change family name just update Group parameter
                if ( !string.IsNullOrWhiteSpace(strNewfamilyName) )
                { 
                    //Only allow renaming if name has at least *_*_*_* FAMILY NAME
                    if (_Filt_FamilyName.famFileStructureChecker(strNewfamilyName) == true)
                    {
                        using (Transaction trans = new Transaction(_doc, "FF - Rename, Set Params"))
                        {
                            trans.Start();
                            oldFamily.Name = strNewfamilyName;
                            trans.Commit();
                        }
                    }
                    else
                    {
                        TaskDialog.Show("Naming Error", "You are trying to name the family..." + strNewfamilyName +
                            ", which is not the company standard");
                    }
                }
            }//end try
            catch (Exception ex)
            {
                TaskDialog.Show("Family Hasn't been renamed", ex.Message);
            }
        }//end mthd










    }//end cl


    // FamilyLoadOptions - overwrites families already in doc on load and allow a family to be reloaded into a project after it has been modified
    public class FamilyLoadOptions : IFamilyLoadOptions
    {
        // Always return true so that all existing families and their parameters are overwritten with the new family
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues)
        {
            overwriteParameterValues = true;
            return true;
        }
        public bool OnSharedFamilyFound(Family sharedFamily, bool familyInUse, out FamilySource source, out bool overwriteParameterValues)
        {
            overwriteParameterValues = true;
            source = FamilySource.Family;
            return true;
        }
    }//end class


}//end ns
