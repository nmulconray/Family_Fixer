﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ComboBox = System.Windows.Forms.ComboBox;

namespace Family_Fixer
{
    static class _Rept_AllFamInst
    {


        public static void checkInstance(UIDocument _uiDoc, Document _doc, UIApplication _uiApp, Family _family, ComboBox cmbBx_ViewFamilyInstance)
        {
            //family instance list
            List<FamilyInstance> famInst_list = new List<FamilyInstance>();


            String ruleValStr = _family.Name;
            BuiltInParameter testParam = BuiltInParameter.ALL_MODEL_FAMILY_NAME;
            ParameterValueProvider pvp = new ParameterValueProvider(new ElementId((int)testParam));
            FilterStringRuleEvaluator fnrvStr = new FilterStringEquals();
            FilterStringRule paramFr = new FilterStringRule(pvp, fnrvStr, ruleValStr, false);
            ElementParameterFilter epf = new ElementParameterFilter(paramFr);



            foreach
            (
            FamilyInstance _familyinstance in new FilteredElementCollector(_doc)
            .OfClass(typeof(FamilyInstance))
            .WherePasses(epf)
            .WhereElementIsNotElementType()
            .Cast<FamilyInstance>()
            //.Where(f => f.Symbol.FamilyName == _family.Name)
            )
            {
                famInst_list.Add(_familyinstance);
            }



            ///
            ///Show families where their bounding box is not completely inside a room
            ///
            if (famInst_list.Count > 0 && cmbBx_ViewFamilyInstance.Text == Show_ReptdFamInst.SHOW_ALL_FAMILYINSTANCE)
            {
                _Find_FamInst.showView(_uiDoc, _doc, _uiApp, famInst_list);
            }


        }
    }
}
