﻿using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Linq;

namespace Family_Fixer
{
    class _Updt_FamInstance
    {


        /*   
           EXERCISE_7 - Report if Family Parameters are not bound correctly as Instance or type in a family document
           TASK_7.1 - Copy this Call to a method that will report
           if a family Parameter is bound to a type or instance
           It is best that it's only called when you cant get the parameter, place it where it would best call the method in TASK_7.2
           
           if (!_family.IsInPlace)
           {
               //Verify if parameter is actually bound to instance
               _Rept_InstOrTypeBinding.check(_doc, _family, strLookUp);
           }
       */
        //Family type values using shared parameter, bool parameter
        public static void editFamAttributes(Application _app, Document _doc, Family _family, string strLookUp, string strParameterValue)
        {
            try
            {

                foreach
                (
                FamilyInstance _familyinstance in new FilteredElementCollector(_doc)
                .OfClass(typeof(FamilyInstance))
                .WhereElementIsNotElementType()
                .Cast<FamilyInstance>()
                .Where(f => f.Symbol.FamilyName == _family.Name)
                )
                {
                    //Find family geometry test
                    //Element elem = _familyinstance as Element; 
                    //Geom_Get geo = new Geom_Get();
                    //geo.GetAndTransformCurve(_app, elem);




                    //for each family instance set parameter value
                    Parameter Element_parameter = _familyinstance.LookupParameter(strLookUp);



                    if (Element_parameter != null)
                    {
                        //Future maybe check with dialog if hasValue is true to let user  know they can either overwrite or cancel
                        if (!Element_parameter.IsReadOnly)
                        {
                            using (Transaction trans = new Transaction(_doc, "Set Family Shared Parameter Values"))
                            {
                                trans.Start();
                                Element_parameter.Set(strParameterValue);
                                trans.Commit();
                            }
                        }
                    }
                    else
                    {
                        //Report to user that an element cant be found
                        TaskDialog.Show("Typed Param Error", "The Parameter, " + strLookUp + "\n"
                            + "has probably been made a type parameter when that's not the company standard");

                    }


                }//end loop




            }//end try
            catch (Exception ex)
            {
                TaskDialog.Show("Family Parameters not Added", ex.Message);
            }
        }//end mthd

    }
}
