﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Family_Fixer
{
    static class Cmbx_Show_ReptdFamInst
    {
        public static void popCmbBx(ComboBox cmbBx_ViewFamilyInstance)
        {
            List<string> famInstance_list = new List<string>();
            famInstance_list.Add(Show_ReptdFamInst.NONE);
            famInstance_list.Add(Show_ReptdFamInst.SHOW_ALL_FAMILYINSTANCE);
            famInstance_list.Add(Show_ReptdFamInst.SHOW_INPLACE_FAMILY);
            famInstance_list.Add(Show_ReptdFamInst.SHOW_FAMILYINSTANCE_WITHOUT_RM);
            famInstance_list.Add(Show_ReptdFamInst.SHOW_FAMILYINSTANCE_OUTSIDE_RM);
            famInstance_list.Add(Show_ReptdFamInst.SHOW_NESTED_AND_SHARED_FAMILYINSTANCE);
            cmbBx_ViewFamilyInstance.DataSource = famInstance_list;
        }

    }
}
