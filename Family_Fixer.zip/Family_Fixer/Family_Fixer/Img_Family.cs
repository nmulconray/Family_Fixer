﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Media.Imaging;

namespace Family_Fixer
{
    public static class Img_Family
    {
        //Preview image on form
        public static Image createPreviewImage(Document _doc, Family family, int size)
        {
            ElementType elemType = null;
            //image size property
            Size imgSize = new Size(size, size);

            try
            {

                //Create a temp directory for the preview image
                CAVCreateDirectory.AddDirectory();

                //Get Family Symbol from family
                foreach (ElementId fsids in family.GetFamilySymbolIds())
                {
                    elemType = _doc.GetElement(fsids) as ElementType;
                    break;
                }



                if (elemType.GetPreviewImage(imgSize) == null)
                {
                    if (family.IsInPlace)
                    {
                        //Set The inplace Image
                        Bitmap image = Properties.Resources.inplace32;
                        image.Tag = Properties.Resources.inplace;

                        return image;
                    }
                    else
                    {
                        //Set The invalid family Image
                        Bitmap image = Properties.Resources.unknown32;
                        image.Tag = Properties.Resources.unknown;

                        return image;
                    }
                }
                else
                {

                    //Create bitmap image if can get preview image
                    Bitmap image = elemType.GetPreviewImage(imgSize);
                    return image;
                }

            }
            catch (Exception)
            {
                return Properties.Resources.unknown;

            }

        }




        /// <summary>
        /// Resize the image to the specified width and height.
        /// </summary>
        /// <param name="image">The image to resize.</param>
        /// <param name="width">The width to resize to.</param>
        /// <param name="height">The height to resize to.</param>
        /// <returns>The resized image.</returns>
        public static Bitmap ResizeImage(Image image, int width, int height)
        {
            var destRect = new System.Drawing.Rectangle(0, 0, width, height);
            var destImage = new Bitmap(width, height);

            destImage.SetResolution(image.HorizontalResolution, image.VerticalResolution);

            using (var graphics = Graphics.FromImage(destImage))
            {
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

                using (var wrapMode = new ImageAttributes())
                {
                    wrapMode.SetWrapMode(WrapMode.TileFlipXY);
                    graphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, wrapMode);
                }
            }

            return destImage;
        }



    }

        //start of support classes
        //add a directory if required
        public static class CAVCreateDirectory
        {
            public static void AddDirectory()
            {
                // Specify the directory you want to manipulate. 
                string path = @"c:\temp\";

                try
                {
                    // Determine whether the directory exists. 
                    if (!Directory.Exists(path))
                    {
                        // Try to create the directory.
                        DirectoryInfo di = Directory.CreateDirectory(path);
                    }

                }
                catch (Exception e)
                {
                    TaskDialog.Show("The process failed: {0}", e.ToString());
                }
                finally { }
            }
        }

        //Convert revit preview bitmap source to bitmap image
        public static class CAVImaging
        {
            public static BitmapSource ConvertBitmapToBitmapSource(Bitmap bitmap)
            {
                if (bitmap == null)
                    throw new ArgumentNullException("bitmap");

                return System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                    bitmap.GetHbitmap(),
                    IntPtr.Zero,
                    System.Windows.Int32Rect.Empty,
                    BitmapSizeOptions.FromEmptyOptions());
            }
        }//End Class
}//end ns
