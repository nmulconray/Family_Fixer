﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;

namespace Family_Fixer
{
    class _Filt_HideFrmSched
    {
        public static void editFamTypeAttributes(Document _doc, Dictionary<Family, bool> _fam_schFilter_dict, string strLookUp)
        {
            try
            {
                //set all family QA to 0 = false unless true has been found for that family
                int intParameterValue = 0;

                foreach (KeyValuePair<Family, bool> kvp in _fam_schFilter_dict)
                {
                    foreach (ElementId elemId in kvp.Key.GetFamilySymbolIds())
                    {
                        //Get element values                               
                        Element elem = _doc.GetElement(elemId) as Element;
                        ElementType elementType = elem as ElementType;


                        //for each family type set parameter value
                        Parameter Element_parameter = elementType.LookupParameter(strLookUp);
                        if (Element_parameter != null)
                        {
                            if (!Element_parameter.IsReadOnly)
                            {
                                //Parse bool value to an integer value
                                if (kvp.Value == true)
                                { intParameterValue = 1; }

                                using (Transaction trans = new Transaction(_doc, "Set Family Shared Parameter Values"))
                                {
                                    trans.Start();
                                    Element_parameter.Set(intParameterValue);
                                    trans.Commit();
                                }
                            }
                            else
                            {
                                TaskDialog.Show("Type Parameter Locked", strLookUp + ", Parameter is locked to a formula. \n Open Family> Edit the family parameter manually");
                            }
                        }
                        else
                        {
                            TaskDialog.Show("Type Parameter Missing", strLookUp + ", Parameter is missing. \n Open Family> Edit the family parameter manually");
                        }
                    }//end family loop
                }//end dict loop
            }//end try
            catch (Exception ex)
            {
                TaskDialog.Show("Parameters not Added", ex.Message);
            }
        }//end mthd




    }//end mthd
}//end ns
