﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using ComboBox = System.Windows.Forms.ComboBox;

namespace Family_Fixer
{
    static class _Rept_OwnedByRm
    {


        public static string checkInstance(UIDocument _uiDoc, Document _doc,  UIApplication _uiApp, Family _family, ComboBox cmbBx_ViewFamilyInstance)
        {
            List<FamilyInstance> famInst_list = new List<FamilyInstance>();

            int intfamInstCount = 0;
            int intfamInstOwnedByRm = 0;
            string str = null;

            String ruleValStr = _family.Name;
            BuiltInParameter testParam = BuiltInParameter.ALL_MODEL_FAMILY_NAME;
            ParameterValueProvider pvp = new ParameterValueProvider(new ElementId((int)testParam));
            FilterStringRuleEvaluator fnrvStr = new FilterStringEquals();
            FilterStringRule paramFr = new FilterStringRule(pvp, fnrvStr, ruleValStr, false);
            ElementParameterFilter epf = new ElementParameterFilter(paramFr);

            //Family instance collector
            //check if all family instances have valid rooms associated with them
            foreach
                    (
                    FamilyInstance _familyinstance in new FilteredElementCollector(_doc)
                    .OfClass(typeof(FamilyInstance))
                    .WherePasses(epf)
                    .WhereElementIsNotElementType()
                    .Cast<FamilyInstance>()
                    //.Where(f => f.Symbol.FamilyName == _family.Name)
                    )
            {
                //

                Element foundElem = _familyinstance as Element;
                //Count each family instance
                intfamInstCount++;

                str += "\n" + "family => " + _family.Name + ", instance => " + _familyinstance.Name;

                //Iterate phases in document
                foreach (Phase phase in _familyinstance.Document.Phases)
                {

                    // TaskDialog.Show("get phase ", "fam inst phase in doc" + phase.Name);

                    if (_familyinstance.GetPhaseStatus(phase.Id) == ElementOnPhaseStatus.New)
                    {
                        //TaskDialog.Show("get phase status", "fam inst phase status");

                        //if family element has a valid room in its new phase
                        if (_familyinstance.get_Room(phase) != null)
                        {
                            //increment owned family count
                            intfamInstOwnedByRm++;
                        }
                        else
                        {
                            //add fam inst to list
                            famInst_list.Add(_familyinstance);
                        }

                    }//end if



                }//end loop


            }//end loop

            ///
            ///Show families not owned by room
            ///EXERCISE_3 - create a plan view to preview the erroneous family
            ///TASK_3.7 - Add the following two lines of code to the method below
            /// View view = View_Operations.createView(_doc, "Ground Level");
            ///_uiDoc.ActiveView = view;
            ///TASK_3.8 - open a revit project check checkbox <View Family without Room>, click run report button
            ///you should be taken to a 3d view
            if (famInst_list.Count > 0 && cmbBx_ViewFamilyInstance.Text == Show_ReptdFamInst.SHOW_FAMILYINSTANCE_WITHOUT_RM)
                    {
                    //uncomment to complete EXERCISE_3, open a project to test, check level name is correct
                     //View view = View_Operations.createView(_doc, "GROUND LEVEL");
                     //_uiDoc.ActiveView = view;

                    _Find_FamInst.showView(_uiDoc, _doc, _uiApp, famInst_list);
                    }

                ///
                return intfamInstOwnedByRm.ToString() + "/" + intfamInstCount.ToString();



        }//end method
    }//end class
}//end ns
