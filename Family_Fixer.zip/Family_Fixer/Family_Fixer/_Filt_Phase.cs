﻿using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Family_Fixer
{
    class _Filt_Phase
    {
        ///EXERCISE_5
        ///TASK_5.1 uncomment out this class so it can be called from the Fam_Collector Class
        /// <summary>
        /// Filter out family if it ONLY!!! exists as a pre-project phase for standard standards, legends and not part of documentation
        /// Also filters out any unplaced families as they dont yet have a phase!
        /// </summary>
        /// <param name="_doc"></param>
        /// <param name="_family"></param>
        /// <returns></returns>
        /*
        public static bool hidePreProject(Document _doc, Family _family)
        {
            bool boolAllPreProjPhase = false;

            String ruleValStr = _family.Name;
            BuiltInParameter testParam = BuiltInParameter.ALL_MODEL_FAMILY_NAME;
            ParameterValueProvider pvp = new ParameterValueProvider(new ElementId((int)testParam));
            FilterStringRuleEvaluator fnrvStr = new FilterStringEquals();
            FilterStringRule paramFr = new FilterStringRule(pvp, fnrvStr, ruleValStr, false);
            ElementParameterFilter elemParamFilter = new ElementParameterFilter(paramFr);

            //Family instance collector
            //check if all family instances are in the phase to filter out, if so hide them
            foreach
                    (
                    FamilyInstance _familyinstance in new FilteredElementCollector(_doc)
                    .OfClass(typeof(FamilyInstance))
                    .WherePasses(elemParamFilter)
                    .WhereElementIsNotElementType()
                    .Cast<FamilyInstance>()
                    )
                {
                    //Hide All instances of Family if alll instances are on the preproject phase
                    if ( !_doc.GetElement(_familyinstance.CreatedPhaseId).Name.Contains("Pre-project Phase") )
                    {
                        boolAllPreProjPhase = true;
                        //At least one instance is not on pre-project phase, so lets break!
                        break;
                    }

                }

                //Send false if only pre-project phases can be found
                return boolAllPreProjPhase;
        }
        */









    }//end class
}//end ns
