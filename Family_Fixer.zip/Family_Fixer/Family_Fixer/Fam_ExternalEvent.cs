﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using Application = Autodesk.Revit.ApplicationServices.Application;
using CheckBox = System.Windows.Forms.CheckBox;

namespace Family_Fixer
{
    public class Fam_ExternalEvent : IExternalEventHandler
    {
        //The Form, for refreshing current list of families
        internal Fam_DGV_Form FormThing;

        //Class level parameters
        private string ExtEvent_name = "Family Fixer External Event";
        string _state = null;

        //Edit Family Document
        Family _family = null;

        //SCH-Filter
        private Dictionary<Family, bool> _fam_schFilter_dict;
        private string _strSCHFilter;
        //Set Rm point, Family Doc - swap category
        private UIApplication _uiApp;
        private Dictionary<Family, bool> _familyRmPt_dict;
        private string _strProjModelPath;
        CheckBox _chkBx_SetProjUnits;
        CheckBox _chkBx_DeleteSharedParam;
        private double _pickPt_X;
        private double _pickPt_Y;
        private double _pickPt_Z;

        private Dictionary<Family, string> _familyCat_dict;
        //Rename Family
        private string _strNewFamName;
        //Shared param Name
        private string _sharedParamName;
        //Instance Param Value
        private string _strInstanceParamValue;
        //Family Types
        private ElementType _elementType;
        private int _familySymbolCount;
        private string _strFamily_Type_Name;
        private string _strSCH_Code;
        private string _strQSID_Code;
        private string _strDescription;
        private string _strManufacturer;
        private string _strVersion;












        //Project - Schedule Filter
        public void scheduleFilter(
            string Newstate,
             Dictionary<Family, bool> fam_schFilter_dict,
             string strSCHFilter,
             int intCurrentRow
            )
        {
            _state = Newstate;
            _fam_schFilter_dict = fam_schFilter_dict;
            _strSCHFilter = strSCHFilter;

        }


        //Fam Doc - Room Point
        public void showRmPt(
            string Newstate,
            UIApplication uiApp,
            string strProjModelPath,
            Dictionary<Family, bool> familyRmPt_dict,
            CheckBox chkBx_SetProjUnits,
            CheckBox chkBx_DeleteSharedParam,
            Double pickPt_X,
            Double pickPt_Y,
            Double pickPt_Z
            )
        {
            _state = Newstate;
            _uiApp = uiApp;
            _strProjModelPath = strProjModelPath;
            _familyRmPt_dict = familyRmPt_dict;
            _chkBx_SetProjUnits = chkBx_SetProjUnits;
            _chkBx_DeleteSharedParam = chkBx_DeleteSharedParam;
            _pickPt_X = pickPt_X;
            _pickPt_Y = pickPt_Y;
            _pickPt_Z = pickPt_Z;
        }


        //Fam Doc - Category
        public void SwapCategory(
            string Newstate,
            UIApplication uiApp,
            string strProjModelPath,
            Dictionary<Family, string> familyCat_dict,
            CheckBox chkBx_SetProjUnits,
            CheckBox chkBx_DeleteSharedParam
            )
        {
            _state = Newstate;
            _uiApp = uiApp;
            _strProjModelPath = strProjModelPath;
            _familyCat_dict = familyCat_dict;
            _chkBx_SetProjUnits = chkBx_SetProjUnits;
            _chkBx_DeleteSharedParam = chkBx_DeleteSharedParam;
        }


        //Fam Doc - Open Family
        public void openFamDoc(
            string Newstate,
            Family family
            )
        {
            _state = Newstate;
            _family = family;
        }



        //Project - Rename Family
        public void renameFamily(
            string Newstate,
            Family family,
            string strNewFamName
            )
        {
            _state = Newstate;
            _family = family;
            _strNewFamName = strNewFamName;
        }



        //Project - Set Instance Param
        public void SetInstanceParam(
            string Newstate,
            Family family,
            string sharedParamName,
            string strInstanceParamValue
            )
        {
            _state = Newstate;
            _family = family;
            _sharedParamName = sharedParamName;
            _strInstanceParamValue = strInstanceParamValue;
        }




        //Project - Rename Family Type
        public void RenameFamType(
            string Newstate,
            ElementType elementType,
            string strFamily_Type_Name,
            string strSCH_Code,
            string strQSID_Code,
            string strDescription,
            string strManufacturer,
            string strVersion
            )
        {
            _state = Newstate;
            _elementType = elementType;
            _strFamily_Type_Name = strFamily_Type_Name;
            _strSCH_Code = strSCH_Code;
            _strQSID_Code = strQSID_Code;
            _strDescription = strDescription;
            _strManufacturer = strManufacturer;
            _strVersion = strVersion;
        }




        //Project - Add Family Type
        public void AddFamType(
            string Newstate,
            Family family,
            ElementType elementType,
            int familySymbolCount,
            string strFamily_Type_Name,
            string strSCH_Code,
            string strQSID_Code,
            string strDescription,
            string strManufacturer,
            string strVersion
            )
        {
            _state = Newstate;
            _family = family;
            _elementType = elementType;
            _strFamily_Type_Name = strFamily_Type_Name;
            _familySymbolCount = familySymbolCount;
            _strSCH_Code = strSCH_Code;
            _strQSID_Code = strQSID_Code;
            _strDescription = strDescription;
            _strManufacturer = strManufacturer;
            _strVersion = strVersion;
        }

 





        //Project - Delete Family Type
        public void DelFamType(
            string Newstate,
            ElementType familyType,
            int familySymbolCount
            )
        {
            _state = Newstate;
            _elementType = familyType;
            _familySymbolCount = familySymbolCount;
        }



        public void SetName(string Newstate)
        {
            _state = Newstate;
        }

        /// <summary>
        /// All the Calls within a valid API context are made from here
        /// </summary>
        /// <param name="uiApp"></param>
        public void Execute(UIApplication uiApp)
        {
            //Get document handle
            //App
            Application _app = uiApp.Application;
            //Doc
            Document _doc = uiApp.ActiveUIDocument.Document;


            // The following are actions within a valid Revit API context thread
            switch (_state)
            {
                case  Btn_Call.NONE:
                    {
                        return;  // no request at this time -> we can leave immediately
                    }

                case Btn_Call.SCH_FILTER:
                    {
 
                        _Filt_HideFrmSched.editFamTypeAttributes(
                        _doc,
                        _fam_schFilter_dict,
                        _strSCHFilter
                        );

                        FormThing.RefreshDataGridView(Btn_Call.SCH_FILTER);
                        break;
                    }

                case Btn_Call.SHOW_RM_PT:
                    {
                        _Updt_FamDoc.editFamDoc(
                         _uiApp,
                         _strProjModelPath,
                         _familyRmPt_dict,
                         _chkBx_SetProjUnits,
                         _chkBx_DeleteSharedParam,
                         _pickPt_X,
                         _pickPt_Y,
                         _pickPt_Z);

                        FormThing.RefreshDataGridView(Btn_Call.SHOW_RM_PT);
                        break;
                    }

                case Btn_Call.SWAP_CATEGORY:
                    {
                        _Updt_FamDoc.editFamDoc(
                        _uiApp,
                        _strProjModelPath,
                        _familyCat_dict,
                        _chkBx_SetProjUnits,
                        _chkBx_DeleteSharedParam);

                        FormThing.RefreshDataGridView(Btn_Call.SWAP_CATEGORY);
                        break;
                    }

                //if user edits and reloads family form will have to be reloaded after, one soln might be to:
                // use a doc changed event to detect a load event and then call FormThing.RefreshDataGridView();
                case Btn_Call.OPEN_FAMILY:
                    {
                        _Open_FamDoc.openToView(
                        uiApp,
                        _doc,
                        _family);

                        FormThing.RefreshDataGridView(Btn_Call.OPEN_FAMILY);
                        break;
                    }

                case Btn_Call.RENAME_FAMILY:
                    {
                        _Updt_Family.editFamAttributes(
                           _doc,
                           _family,
                           _strNewFamName
                           );

                        FormThing.RefreshDataGridView(Btn_Call.RENAME_FAMILY);
                        break;
                    }

                case Btn_Call.SET_INSTANCE_PARAM:
                    {
                        _Updt_FamInstance.editFamAttributes(
                        _app,
                        _doc,
                        _family,
                        _sharedParamName,
                        _strInstanceParamValue
                        );

                        FormThing.RefreshDataGridView(Btn_Call.SET_INSTANCE_PARAM);
                        break;
                    }

                case Btn_Call.RENAME_FAM_TYPE:
                    {
                        _Updt_FamType.RENAMEFamilyType(
                        _doc,
                        _elementType,
                        _strFamily_Type_Name
                        );

                        AddParameterValues(
                        _doc,
                        _elementType,
                        _strSCH_Code,
                        _strQSID_Code,
                        _strVersion,
                        _strDescription,
                        _strManufacturer
                        );

                        FormThing.RefreshDataGridView(Btn_Call.RENAME_FAM_TYPE);
                        break;
                    }

                case Btn_Call.ADD_FAM_TYPE:
                    {
                        _Updt_FamType.ADDFamilyType(
                        _doc,
                        _family,
                        _elementType,
                        _strFamily_Type_Name,
                        _familySymbolCount
                        );

                        AddParameterValues(
                        _doc,
                        _elementType,
                        _strSCH_Code,
                        _strQSID_Code,
                        _strVersion,
                        _strDescription,
                        _strManufacturer
                        );

                        FormThing.RefreshDataGridView(Btn_Call.ADD_FAM_TYPE);
                        break;
                    }

                case Btn_Call.DEL_FAM_TYPE:
                    {
                        _Updt_FamType.DELETEFamilyType(
                        _doc,
                        _elementType,
                        _familySymbolCount
                        );

                        FormThing.RefreshDataGridView(Btn_Call.DEL_FAM_TYPE);
                        break;
                    }

                default:
                    {
                        // some kind of a warning here should
                        // notify us about an unexpected request 
                        break;
                    }
            }


        }//end Execute mthd














        /// <summary>
        /// Add Type Parameter Values, To Family Types
        /// </summary>
        /// <param name="familyObj"></param>
        private void AddParameterValues(
            Document _doc,
            ElementType familyObj,
            string _strSCH_Code,
            string _strQSID_Code,
            string _strVersion,
            string _strDescription,
            string _strManufacturer
            )
        {

            //OVERLOADED METHODS, easy to copy and paste and tweak
            if (_strSCH_Code != null)
            {
                _Updt_FamType.editFamTypeAttributes(
                    _doc,
                    familyObj,
                    Fam_SharedParam.SCHEDULECODE_SP,
                    _strSCH_Code
                    );
            }

            if (_strQSID_Code != null)
            {
                _Updt_FamType.editFamTypeAttributes(
                    _doc,
                    familyObj,
                    Fam_SharedParam.QSID_SP,
                    _strQSID_Code
                    );
            }


            if (_strVersion != null)
            {
                _Updt_FamType.editFamTypeAttributes(
                _doc,
                familyObj,
                Fam_SharedParam.VERSION_SP,
                _strVersion
                );
            }

            if (_strDescription != null)
            {
                _Updt_FamType.editFamTypeAttributes(
                    _doc,
                    familyObj,
                    BuiltInParameter.ALL_MODEL_DESCRIPTION,
                    _strDescription
                    );
            }

            if (_strManufacturer != null)
            {
                _Updt_FamType.editFamTypeAttributes(
                    _doc,
                    familyObj,
                    BuiltInParameter.ALL_MODEL_MANUFACTURER,
                    _strDescription
                    );
            }

        }//end mthd






        public string GetName()
        {
            return ExtEvent_name;
        }


    }
}
