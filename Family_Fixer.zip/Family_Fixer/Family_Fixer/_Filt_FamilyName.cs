﻿using System.Text.RegularExpressions;

namespace Family_Fixer
{
    static class _Filt_FamilyName
    {
        /// <summary>
        /// EXERCISE_1 - Create a Family naming Pattern to match your companies family naming convention
        /// TASK_1.1 - Your company uses 3 hypens as a delimiter(seperator) and not underscores, change the Regex string "\S_\S*_\S*_\S"
        /// and rename a family so that after a report is run the family will be seen as compliant, ie QA will have "Yes" in the QA column of the GUI.
        /// </summary>
        /// <param name="_family"></param>
        /// <returns></returns>
        public static bool famFileStructureChecker(string _familyname)
        {
            //Check if family name has at least the pattern <*_*_*_*>
            if (Regex.IsMatch( _familyname, @"(\S+_){3}\S" )  &!Regex.IsMatch( _familyname, @"(\S+_){4}\S" )  ) 
            { return true; }
            else
            { return false; }
        }


    }
}
