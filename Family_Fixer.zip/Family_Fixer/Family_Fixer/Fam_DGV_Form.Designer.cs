﻿namespace Family_Fixer
{
    partial class Fam_DGV_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Fam_DGV_Form));
            this.dataGridView_Fam = new System.Windows.Forms.DataGridView();
            this.UNIQUE_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FILTER_FROM_SCHEDULE = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.FAMILY_QA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.INPLACE_FAMILY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SHARED_NESTED_FAMILY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FAMILY_INSTANCE_OWNED_BY_RM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FAMILY_INSTANCE_IS_INSIDE_RM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FAMILY_DOC_TO_SPEC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RM_POINT_ON = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.CATEGORY = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.IMAGE = new System.Windows.Forms.DataGridViewImageColumn();
            this.FAMILY_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OWNER_CATEGORY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FUNCTIONALTYPE = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.SUBTYPE = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.MANUFACTURER = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.DESCRIPTOR = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.GROUP = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.FAMILY_TYPES = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.SCHEDULE_CODE_TYPES = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.QSID_CODE_TYPES = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.DESCRIPTION_TYPES = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.splitContainer8 = new System.Windows.Forms.SplitContainer();
            this.splitContainer9 = new System.Windows.Forms.SplitContainer();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.chkBx_FilterInDGV = new System.Windows.Forms.CheckBox();
            this.btn_FilterFromSchedule_Global = new System.Windows.Forms.Button();
            this.cmbBx_ViewFamilyInstance = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_RunReport = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.splitContainer13 = new System.Windows.Forms.SplitContainer();
            this.btn_Swap_FamDoc_RmPoint = new System.Windows.Forms.Button();
            this.btn_Swap_FamDoc_Category = new System.Windows.Forms.Button();
            this.chkBx_SetProjUnits = new System.Windows.Forms.CheckBox();
            this.chkBx_DeleteSharedParam = new System.Windows.Forms.CheckBox();
            this.splitContainer14 = new System.Windows.Forms.SplitContainer();
            this.splitContainer15 = new System.Windows.Forms.SplitContainer();
            this.btn_UpdateFamNameAndParam = new System.Windows.Forms.Button();
            this.btn_InstanceParams = new System.Windows.Forms.Button();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.rchTxtBx_NewFamilyName = new System.Windows.Forms.RichTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rchTxtBx_Group = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.splitContainer11 = new System.Windows.Forms.SplitContainer();
            this.btn_UpdateFamTypeAndParam = new System.Windows.Forms.Button();
            this.splitContainer12 = new System.Windows.Forms.SplitContainer();
            this.btn_Create_FamilyType = new System.Windows.Forms.Button();
            this.btn_Delete_Type = new System.Windows.Forms.Button();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.rchTxtBx_FamTypeAndParam = new System.Windows.Forms.RichTextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rchTxtBx_SCH_Code = new System.Windows.Forms.RichTextBox();
            this.splitContainer10 = new System.Windows.Forms.SplitContainer();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.rchTxtBx_QSID = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rchTxtBx_Description = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Fam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).BeginInit();
            this.splitContainer8.Panel1.SuspendLayout();
            this.splitContainer8.Panel2.SuspendLayout();
            this.splitContainer8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).BeginInit();
            this.splitContainer9.Panel1.SuspendLayout();
            this.splitContainer9.Panel2.SuspendLayout();
            this.splitContainer9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer13)).BeginInit();
            this.splitContainer13.Panel1.SuspendLayout();
            this.splitContainer13.Panel2.SuspendLayout();
            this.splitContainer13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer14)).BeginInit();
            this.splitContainer14.Panel1.SuspendLayout();
            this.splitContainer14.Panel2.SuspendLayout();
            this.splitContainer14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer15)).BeginInit();
            this.splitContainer15.Panel1.SuspendLayout();
            this.splitContainer15.Panel2.SuspendLayout();
            this.splitContainer15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).BeginInit();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.Panel2.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).BeginInit();
            this.splitContainer11.Panel1.SuspendLayout();
            this.splitContainer11.Panel2.SuspendLayout();
            this.splitContainer11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer12)).BeginInit();
            this.splitContainer12.Panel1.SuspendLayout();
            this.splitContainer12.Panel2.SuspendLayout();
            this.splitContainer12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).BeginInit();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).BeginInit();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).BeginInit();
            this.splitContainer10.Panel1.SuspendLayout();
            this.splitContainer10.Panel2.SuspendLayout();
            this.splitContainer10.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView_Fam
            // 
            this.dataGridView_Fam.AllowUserToAddRows = false;
            this.dataGridView_Fam.AllowUserToDeleteRows = false;
            this.dataGridView_Fam.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Blue;
            this.dataGridView_Fam.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_Fam.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridView_Fam.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Fam.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_Fam.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Fam.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.UNIQUE_ID,
            this.FILTER_FROM_SCHEDULE,
            this.FAMILY_QA,
            this.INPLACE_FAMILY,
            this.SHARED_NESTED_FAMILY,
            this.FAMILY_INSTANCE_OWNED_BY_RM,
            this.FAMILY_INSTANCE_IS_INSIDE_RM,
            this.FAMILY_DOC_TO_SPEC,
            this.RM_POINT_ON,
            this.CATEGORY,
            this.IMAGE,
            this.FAMILY_NAME,
            this.OWNER_CATEGORY,
            this.FUNCTIONALTYPE,
            this.SUBTYPE,
            this.MANUFACTURER,
            this.DESCRIPTOR,
            this.GROUP,
            this.FAMILY_TYPES,
            this.SCHEDULE_CODE_TYPES,
            this.QSID_CODE_TYPES,
            this.DESCRIPTION_TYPES});
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_Fam.DefaultCellStyle = dataGridViewCellStyle24;
            this.dataGridView_Fam.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_Fam.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGridView_Fam.GridColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridView_Fam.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_Fam.Margin = new System.Windows.Forms.Padding(5);
            this.dataGridView_Fam.Name = "dataGridView_Fam";
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Fam.RowHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.dataGridView_Fam.RowHeadersVisible = false;
            this.dataGridView_Fam.RowTemplate.DefaultCellStyle.Padding = new System.Windows.Forms.Padding(5);
            this.dataGridView_Fam.RowTemplate.Height = 32;
            this.dataGridView_Fam.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Fam.ShowCellErrors = false;
            this.dataGridView_Fam.Size = new System.Drawing.Size(1513, 514);
            this.dataGridView_Fam.TabIndex = 0;
            this.dataGridView_Fam.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_Family_CellClick);
            this.dataGridView_Fam.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_Fam_CellContentClick);
            this.dataGridView_Fam.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView_Fam_CellMouseDown);
            this.dataGridView_Fam.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_Family_CellValueChanged);
            this.dataGridView_Fam.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dataGridView_Family_DataError);
            this.dataGridView_Fam.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dataGridView_Family_EditingControlShowing);
            // 
            // UNIQUE_ID
            // 
            this.UNIQUE_ID.HeaderText = "Unique Id";
            this.UNIQUE_ID.Name = "UNIQUE_ID";
            this.UNIQUE_ID.Visible = false;
            // 
            // FILTER_FROM_SCHEDULE
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(217)))), ((int)(((byte)(230)))));
            dataGridViewCellStyle3.NullValue = false;
            this.FILTER_FROM_SCHEDULE.DefaultCellStyle = dataGridViewCellStyle3;
            this.FILTER_FROM_SCHEDULE.HeaderText = "Filter from Schedule";
            this.FILTER_FROM_SCHEDULE.Name = "FILTER_FROM_SCHEDULE";
            this.FILTER_FROM_SCHEDULE.ReadOnly = true;
            this.FILTER_FROM_SCHEDULE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.FILTER_FROM_SCHEDULE.ToolTipText = "Use the Toggle Schedule Filter to check or uncheck The Schedule Filter parameter(" +
    "SCH_filter), Hide uncheck will hide in the add-in those rows that are checked";
            this.FILTER_FROM_SCHEDULE.Width = 75;
            // 
            // FAMILY_QA
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(195)))), ((int)(((byte)(229)))));
            this.FAMILY_QA.DefaultCellStyle = dataGridViewCellStyle4;
            this.FAMILY_QA.HeaderText = "QA";
            this.FAMILY_QA.Name = "FAMILY_QA";
            this.FAMILY_QA.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.FAMILY_QA.ToolTipText = "This Reporting value on the quality of a family is based on rules, such as family" +
    " name structure and parameters having values";
            this.FAMILY_QA.Width = 60;
            // 
            // INPLACE_FAMILY
            // 
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(195)))), ((int)(((byte)(229)))));
            this.INPLACE_FAMILY.DefaultCellStyle = dataGridViewCellStyle5;
            this.INPLACE_FAMILY.HeaderText = "Inplace Family";
            this.INPLACE_FAMILY.Name = "INPLACE_FAMILY";
            this.INPLACE_FAMILY.ReadOnly = true;
            this.INPLACE_FAMILY.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.INPLACE_FAMILY.ToolTipText = "Reports if a family has been modelled inplace";
            this.INPLACE_FAMILY.Width = 60;
            // 
            // SHARED_NESTED_FAMILY
            // 
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(195)))), ((int)(((byte)(229)))));
            this.SHARED_NESTED_FAMILY.DefaultCellStyle = dataGridViewCellStyle6;
            this.SHARED_NESTED_FAMILY.HeaderText = "Shared Nested Family";
            this.SHARED_NESTED_FAMILY.Name = "SHARED_NESTED_FAMILY";
            this.SHARED_NESTED_FAMILY.ToolTipText = "Reports if a family is nested into another family and has it\'s shared value switc" +
    "hed on";
            this.SHARED_NESTED_FAMILY.Width = 60;
            // 
            // FAMILY_INSTANCE_OWNED_BY_RM
            // 
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(195)))), ((int)(((byte)(229)))));
            this.FAMILY_INSTANCE_OWNED_BY_RM.DefaultCellStyle = dataGridViewCellStyle7;
            this.FAMILY_INSTANCE_OWNED_BY_RM.HeaderText = "Family Instance Owned By Room";
            this.FAMILY_INSTANCE_OWNED_BY_RM.Name = "FAMILY_INSTANCE_OWNED_BY_RM";
            this.FAMILY_INSTANCE_OWNED_BY_RM.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.FAMILY_INSTANCE_OWNED_BY_RM.ToolTipText = "Reports the ratio of family instances that belong to a room (in other words the f" +
    "amily instances have their room point inside and report a room that it belongs t" +
    "o)";
            this.FAMILY_INSTANCE_OWNED_BY_RM.Width = 60;
            // 
            // FAMILY_INSTANCE_IS_INSIDE_RM
            // 
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(195)))), ((int)(((byte)(229)))));
            this.FAMILY_INSTANCE_IS_INSIDE_RM.DefaultCellStyle = dataGridViewCellStyle8;
            this.FAMILY_INSTANCE_IS_INSIDE_RM.HeaderText = "Family Instance Inside Room";
            this.FAMILY_INSTANCE_IS_INSIDE_RM.Name = "FAMILY_INSTANCE_IS_INSIDE_RM";
            this.FAMILY_INSTANCE_IS_INSIDE_RM.ToolTipText = "Reports on Families that are completely inside or enclosed by a rooms volume as t" +
    "he the ratio of family instances inside a room to the total number of family ins" +
    "tances";
            this.FAMILY_INSTANCE_IS_INSIDE_RM.Width = 60;
            // 
            // FAMILY_DOC_TO_SPEC
            // 
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(195)))), ((int)(((byte)(229)))));
            this.FAMILY_DOC_TO_SPEC.DefaultCellStyle = dataGridViewCellStyle9;
            this.FAMILY_DOC_TO_SPEC.HeaderText = "Family Doc to Spec";
            this.FAMILY_DOC_TO_SPEC.Name = "FAMILY_DOC_TO_SPEC";
            this.FAMILY_DOC_TO_SPEC.ToolTipText = "Reports the family document has at least one control and two origins";
            this.FAMILY_DOC_TO_SPEC.Width = 60;
            // 
            // RM_POINT_ON
            // 
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(146)))), ((int)(((byte)(168)))));
            dataGridViewCellStyle10.NullValue = false;
            this.RM_POINT_ON.DefaultCellStyle = dataGridViewCellStyle10;
            this.RM_POINT_ON.HeaderText = "Room Point On";
            this.RM_POINT_ON.Name = "RM_POINT_ON";
            this.RM_POINT_ON.ReadOnly = true;
            this.RM_POINT_ON.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.RM_POINT_ON.ToolTipText = "Select the row and Toggle Rm Point To switch the room location point to on";
            this.RM_POINT_ON.Width = 50;
            // 
            // CATEGORY
            // 
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(146)))), ((int)(((byte)(168)))));
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HotTrack;
            this.CATEGORY.DefaultCellStyle = dataGridViewCellStyle11;
            this.CATEGORY.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.CATEGORY.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CATEGORY.HeaderText = "FamDoc Category";
            this.CATEGORY.Name = "CATEGORY";
            this.CATEGORY.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.CATEGORY.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.CATEGORY.ToolTipText = "Select the row containing the family you want to modify and hit the swap category" +
    " button (this will edit the family document and reload it back into the project)" +
    "";
            this.CATEGORY.Width = 125;
            // 
            // IMAGE
            // 
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(158)))), ((int)(((byte)(168)))));
            dataGridViewCellStyle12.NullValue = null;
            this.IMAGE.DefaultCellStyle = dataGridViewCellStyle12;
            this.IMAGE.FillWeight = 64F;
            this.IMAGE.HeaderText = "Img";
            this.IMAGE.Name = "IMAGE";
            this.IMAGE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.IMAGE.Width = 32;
            // 
            // FAMILY_NAME
            // 
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(158)))), ((int)(((byte)(168)))));
            this.FAMILY_NAME.DefaultCellStyle = dataGridViewCellStyle13;
            this.FAMILY_NAME.HeaderText = "Family Name";
            this.FAMILY_NAME.Name = "FAMILY_NAME";
            this.FAMILY_NAME.ToolTipText = "Displays the original family name, after changing the values in the drop down sel" +
    "ectors and modifying in the text box this value will be updated on pressing the " +
    "button: rename family";
            this.FAMILY_NAME.Width = 300;
            // 
            // OWNER_CATEGORY
            // 
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(158)))), ((int)(((byte)(168)))));
            this.OWNER_CATEGORY.DefaultCellStyle = dataGridViewCellStyle14;
            this.OWNER_CATEGORY.HeaderText = "Owner Category";
            this.OWNER_CATEGORY.Name = "OWNER_CATEGORY";
            // 
            // FUNCTIONALTYPE
            // 
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(158)))), ((int)(((byte)(168)))));
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HotTrack;
            this.FUNCTIONALTYPE.DefaultCellStyle = dataGridViewCellStyle15;
            this.FUNCTIONALTYPE.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.FUNCTIONALTYPE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FUNCTIONALTYPE.HeaderText = "Funct Type";
            this.FUNCTIONALTYPE.Name = "FUNCTIONALTYPE";
            this.FUNCTIONALTYPE.Sorted = true;
            this.FUNCTIONALTYPE.Width = 125;
            // 
            // SUBTYPE
            // 
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(158)))), ((int)(((byte)(168)))));
            this.SUBTYPE.DefaultCellStyle = dataGridViewCellStyle16;
            this.SUBTYPE.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.SUBTYPE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SUBTYPE.HeaderText = "Sub Type";
            this.SUBTYPE.Name = "SUBTYPE";
            this.SUBTYPE.Sorted = true;
            this.SUBTYPE.Width = 125;
            // 
            // MANUFACTURER
            // 
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(158)))), ((int)(((byte)(168)))));
            this.MANUFACTURER.DefaultCellStyle = dataGridViewCellStyle17;
            this.MANUFACTURER.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.MANUFACTURER.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MANUFACTURER.HeaderText = "Manufacturer";
            this.MANUFACTURER.Name = "MANUFACTURER";
            this.MANUFACTURER.Sorted = true;
            this.MANUFACTURER.Width = 125;
            // 
            // DESCRIPTOR
            // 
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(158)))), ((int)(((byte)(168)))));
            this.DESCRIPTOR.DefaultCellStyle = dataGridViewCellStyle18;
            this.DESCRIPTOR.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.DESCRIPTOR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DESCRIPTOR.HeaderText = "Descriptor";
            this.DESCRIPTOR.Name = "DESCRIPTOR";
            this.DESCRIPTOR.Sorted = true;
            this.DESCRIPTOR.Width = 150;
            // 
            // GROUP
            // 
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(158)))), ((int)(((byte)(168)))));
            this.GROUP.DefaultCellStyle = dataGridViewCellStyle19;
            this.GROUP.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.GROUP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GROUP.HeaderText = "Group";
            this.GROUP.Name = "GROUP";
            this.GROUP.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.GROUP.Sorted = true;
            this.GROUP.ToolTipText = "The group is an instance field used for the classifying of who is responsible for" +
    " the purchase and installment of varying items in a project";
            // 
            // FAMILY_TYPES
            // 
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.FAMILY_TYPES.DefaultCellStyle = dataGridViewCellStyle20;
            this.FAMILY_TYPES.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.FAMILY_TYPES.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FAMILY_TYPES.HeaderText = "Family Types";
            this.FAMILY_TYPES.Name = "FAMILY_TYPES";
            this.FAMILY_TYPES.Sorted = true;
            this.FAMILY_TYPES.ToolTipText = "By using the drop down selectors parameters can be populated with pre-built stand" +
    "ards in naming conventions can be adopted from an XML file";
            this.FAMILY_TYPES.Width = 150;
            // 
            // SCHEDULE_CODE_TYPES
            // 
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.SCHEDULE_CODE_TYPES.DefaultCellStyle = dataGridViewCellStyle21;
            this.SCHEDULE_CODE_TYPES.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.SCHEDULE_CODE_TYPES.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SCHEDULE_CODE_TYPES.HeaderText = "Schedule Code Types";
            this.SCHEDULE_CODE_TYPES.Name = "SCHEDULE_CODE_TYPES";
            this.SCHEDULE_CODE_TYPES.Sorted = true;
            this.SCHEDULE_CODE_TYPES.Width = 50;
            // 
            // QSID_CODE_TYPES
            // 
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.QSID_CODE_TYPES.DefaultCellStyle = dataGridViewCellStyle22;
            this.QSID_CODE_TYPES.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.QSID_CODE_TYPES.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.QSID_CODE_TYPES.HeaderText = "QSID Code Types";
            this.QSID_CODE_TYPES.Name = "QSID_CODE_TYPES";
            this.QSID_CODE_TYPES.Sorted = true;
            this.QSID_CODE_TYPES.Width = 150;
            // 
            // DESCRIPTION_TYPES
            // 
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.DESCRIPTION_TYPES.DefaultCellStyle = dataGridViewCellStyle23;
            this.DESCRIPTION_TYPES.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.DESCRIPTION_TYPES.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DESCRIPTION_TYPES.HeaderText = "Description Types";
            this.DESCRIPTION_TYPES.Name = "DESCRIPTION_TYPES";
            this.DESCRIPTION_TYPES.Sorted = true;
            this.DESCRIPTION_TYPES.Width = 300;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.MinimumSize = new System.Drawing.Size(0, 128);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            this.splitContainer1.Panel1.Padding = new System.Windows.Forms.Padding(5);
            this.splitContainer1.Panel1MinSize = 128;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dataGridView_Fam);
            this.splitContainer1.Panel2MinSize = 128;
            this.splitContainer1.Size = new System.Drawing.Size(1513, 652);
            this.splitContainer1.SplitterDistance = 134;
            this.splitContainer1.TabIndex = 3;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(5, 5);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.splitContainer2.Panel2.Controls.Add(this.label5);
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer4);
            this.splitContainer2.Panel2.Padding = new System.Windows.Forms.Padding(5);
            this.splitContainer2.Size = new System.Drawing.Size(1503, 124);
            this.splitContainer2.SplitterDistance = 991;
            this.splitContainer2.TabIndex = 13;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.IsSplitterFixed = true;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.BackColor = System.Drawing.Color.LightBlue;
            this.splitContainer3.Panel1.Controls.Add(this.splitContainer8);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(158)))), ((int)(((byte)(168)))));
            this.splitContainer3.Panel2.Controls.Add(this.splitContainer14);
            this.splitContainer3.Panel2.Controls.Add(this.label4);
            this.splitContainer3.Panel2.Padding = new System.Windows.Forms.Padding(5);
            this.splitContainer3.Size = new System.Drawing.Size(991, 124);
            this.splitContainer3.SplitterDistance = 633;
            this.splitContainer3.TabIndex = 0;
            // 
            // splitContainer8
            // 
            this.splitContainer8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.splitContainer8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer8.IsSplitterFixed = true;
            this.splitContainer8.Location = new System.Drawing.Point(0, 0);
            this.splitContainer8.Name = "splitContainer8";
            // 
            // splitContainer8.Panel1
            // 
            this.splitContainer8.Panel1.BackColor = System.Drawing.Color.Gold;
            this.splitContainer8.Panel1.Controls.Add(this.splitContainer9);
            // 
            // splitContainer8.Panel2
            // 
            this.splitContainer8.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(146)))), ((int)(((byte)(168)))));
            this.splitContainer8.Panel2.Controls.Add(this.label3);
            this.splitContainer8.Panel2.Controls.Add(this.splitContainer13);
            this.splitContainer8.Panel2.Controls.Add(this.chkBx_SetProjUnits);
            this.splitContainer8.Panel2.Controls.Add(this.chkBx_DeleteSharedParam);
            this.splitContainer8.Panel2.Padding = new System.Windows.Forms.Padding(5);
            this.splitContainer8.Size = new System.Drawing.Size(633, 124);
            this.splitContainer8.SplitterDistance = 427;
            this.splitContainer8.TabIndex = 0;
            // 
            // splitContainer9
            // 
            this.splitContainer9.BackColor = System.Drawing.SystemColors.ControlLight;
            this.splitContainer9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer9.IsSplitterFixed = true;
            this.splitContainer9.Location = new System.Drawing.Point(0, 0);
            this.splitContainer9.Name = "splitContainer9";
            // 
            // splitContainer9.Panel1
            // 
            this.splitContainer9.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(217)))), ((int)(((byte)(230)))));
            this.splitContainer9.Panel1.Controls.Add(this.label6);
            this.splitContainer9.Panel1.Controls.Add(this.label1);
            this.splitContainer9.Panel1.Controls.Add(this.chkBx_FilterInDGV);
            this.splitContainer9.Panel1.Controls.Add(this.btn_FilterFromSchedule_Global);
            this.splitContainer9.Panel1.Padding = new System.Windows.Forms.Padding(5);
            // 
            // splitContainer9.Panel2
            // 
            this.splitContainer9.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(195)))), ((int)(((byte)(229)))));
            this.splitContainer9.Panel2.Controls.Add(this.cmbBx_ViewFamilyInstance);
            this.splitContainer9.Panel2.Controls.Add(this.label2);
            this.splitContainer9.Panel2.Controls.Add(this.btn_RunReport);
            this.splitContainer9.Panel2.Padding = new System.Windows.Forms.Padding(5);
            this.splitContainer9.Size = new System.Drawing.Size(427, 124);
            this.splitContainer9.SplitterDistance = 77;
            this.splitContainer9.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Top;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(5, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 15);
            this.label6.TabIndex = 19;
            this.label6.Text = "in Schedule";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 17);
            this.label1.TabIndex = 18;
            this.label1.Text = "Filter: Schedule";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // chkBx_FilterInDGV
            // 
            this.chkBx_FilterInDGV.AutoSize = true;
            this.chkBx_FilterInDGV.Dock = System.Windows.Forms.DockStyle.Top;
            this.chkBx_FilterInDGV.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx_FilterInDGV.Location = new System.Drawing.Point(5, 34);
            this.chkBx_FilterInDGV.Name = "chkBx_FilterInDGV";
            this.chkBx_FilterInDGV.Size = new System.Drawing.Size(67, 19);
            this.chkBx_FilterInDGV.TabIndex = 17;
            this.chkBx_FilterInDGV.Text = "Hide";
            this.chkBx_FilterInDGV.UseVisualStyleBackColor = true;
            this.chkBx_FilterInDGV.CheckedChanged += new System.EventHandler(this.chkBx_FilterInDGV_CheckedChanged);
            // 
            // btn_FilterFromSchedule_Global
            // 
            this.btn_FilterFromSchedule_Global.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_FilterFromSchedule_Global.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_FilterFromSchedule_Global.Location = new System.Drawing.Point(5, 5);
            this.btn_FilterFromSchedule_Global.Name = "btn_FilterFromSchedule_Global";
            this.btn_FilterFromSchedule_Global.Size = new System.Drawing.Size(67, 29);
            this.btn_FilterFromSchedule_Global.TabIndex = 0;
            this.btn_FilterFromSchedule_Global.Text = "Toggle";
            this.btn_FilterFromSchedule_Global.UseVisualStyleBackColor = false;
            this.btn_FilterFromSchedule_Global.Click += new System.EventHandler(this.btn_FilterFromSchedule_Global_Click);
            // 
            // cmbBx_ViewFamilyInstance
            // 
            this.cmbBx_ViewFamilyInstance.Dock = System.Windows.Forms.DockStyle.Top;
            this.cmbBx_ViewFamilyInstance.FormattingEnabled = true;
            this.cmbBx_ViewFamilyInstance.Location = new System.Drawing.Point(5, 34);
            this.cmbBx_ViewFamilyInstance.Name = "cmbBx_ViewFamilyInstance";
            this.cmbBx_ViewFamilyInstance.Size = new System.Drawing.Size(336, 25);
            this.cmbBx_ViewFamilyInstance.TabIndex = 21;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(5, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(336, 17);
            this.label2.TabIndex = 19;
            this.label2.Text = "Report: Family, Family Instance states";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btn_RunReport
            // 
            this.btn_RunReport.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_RunReport.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_RunReport.ForeColor = System.Drawing.Color.Black;
            this.btn_RunReport.Location = new System.Drawing.Point(5, 5);
            this.btn_RunReport.Name = "btn_RunReport";
            this.btn_RunReport.Size = new System.Drawing.Size(336, 29);
            this.btn_RunReport.TabIndex = 0;
            this.btn_RunReport.Text = "Run Family Report";
            this.btn_RunReport.UseVisualStyleBackColor = false;
            this.btn_RunReport.Click += new System.EventHandler(this.btn_RunReport_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(5, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(192, 17);
            this.label3.TabIndex = 20;
            this.label3.Text = "Modify: the Family Docs Properties";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // splitContainer13
            // 
            this.splitContainer13.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitContainer13.Location = new System.Drawing.Point(5, 5);
            this.splitContainer13.Name = "splitContainer13";
            // 
            // splitContainer13.Panel1
            // 
            this.splitContainer13.Panel1.Controls.Add(this.btn_Swap_FamDoc_RmPoint);
            // 
            // splitContainer13.Panel2
            // 
            this.splitContainer13.Panel2.Controls.Add(this.btn_Swap_FamDoc_Category);
            this.splitContainer13.Size = new System.Drawing.Size(192, 29);
            this.splitContainer13.SplitterDistance = 94;
            this.splitContainer13.TabIndex = 14;
            // 
            // btn_Swap_FamDoc_RmPoint
            // 
            this.btn_Swap_FamDoc_RmPoint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(146)))), ((int)(((byte)(168)))));
            this.btn_Swap_FamDoc_RmPoint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Swap_FamDoc_RmPoint.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Swap_FamDoc_RmPoint.Location = new System.Drawing.Point(0, 0);
            this.btn_Swap_FamDoc_RmPoint.Name = "btn_Swap_FamDoc_RmPoint";
            this.btn_Swap_FamDoc_RmPoint.Size = new System.Drawing.Size(94, 29);
            this.btn_Swap_FamDoc_RmPoint.TabIndex = 12;
            this.btn_Swap_FamDoc_RmPoint.Text = "Toggle Rm Pt";
            this.btn_Swap_FamDoc_RmPoint.UseVisualStyleBackColor = false;
            this.btn_Swap_FamDoc_RmPoint.Click += new System.EventHandler(this.btn_Swap_FamDoc_RmPoint_Click);
            // 
            // btn_Swap_FamDoc_Category
            // 
            this.btn_Swap_FamDoc_Category.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(146)))), ((int)(((byte)(168)))));
            this.btn_Swap_FamDoc_Category.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Swap_FamDoc_Category.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Swap_FamDoc_Category.Location = new System.Drawing.Point(0, 0);
            this.btn_Swap_FamDoc_Category.Name = "btn_Swap_FamDoc_Category";
            this.btn_Swap_FamDoc_Category.Size = new System.Drawing.Size(94, 29);
            this.btn_Swap_FamDoc_Category.TabIndex = 13;
            this.btn_Swap_FamDoc_Category.Text = "Swap Category";
            this.btn_Swap_FamDoc_Category.UseVisualStyleBackColor = false;
            this.btn_Swap_FamDoc_Category.Click += new System.EventHandler(this.btn_Swap_FamDoc_Category_Click);
            // 
            // chkBx_SetProjUnits
            // 
            this.chkBx_SetProjUnits.AutoSize = true;
            this.chkBx_SetProjUnits.Checked = true;
            this.chkBx_SetProjUnits.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkBx_SetProjUnits.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx_SetProjUnits.Location = new System.Drawing.Point(8, 54);
            this.chkBx_SetProjUnits.Name = "chkBx_SetProjUnits";
            this.chkBx_SetProjUnits.Size = new System.Drawing.Size(152, 19);
            this.chkBx_SetProjUnits.TabIndex = 15;
            this.chkBx_SetProjUnits.Text = "Family Doc Units Metric";
            this.chkBx_SetProjUnits.UseVisualStyleBackColor = true;
            // 
            // chkBx_DeleteSharedParam
            // 
            this.chkBx_DeleteSharedParam.AutoSize = true;
            this.chkBx_DeleteSharedParam.Checked = true;
            this.chkBx_DeleteSharedParam.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkBx_DeleteSharedParam.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx_DeleteSharedParam.Location = new System.Drawing.Point(7, 34);
            this.chkBx_DeleteSharedParam.Name = "chkBx_DeleteSharedParam";
            this.chkBx_DeleteSharedParam.Size = new System.Drawing.Size(185, 19);
            this.chkBx_DeleteSharedParam.TabIndex = 14;
            this.chkBx_DeleteSharedParam.Text = "Delete Xeno Share-Parameters";
            this.chkBx_DeleteSharedParam.UseVisualStyleBackColor = true;
            // 
            // splitContainer14
            // 
            this.splitContainer14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer14.Location = new System.Drawing.Point(5, 5);
            this.splitContainer14.Name = "splitContainer14";
            this.splitContainer14.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer14.Panel1
            // 
            this.splitContainer14.Panel1.Controls.Add(this.splitContainer15);
            // 
            // splitContainer14.Panel2
            // 
            this.splitContainer14.Panel2.Controls.Add(this.splitContainer7);
            this.splitContainer14.Size = new System.Drawing.Size(344, 97);
            this.splitContainer14.SplitterDistance = 27;
            this.splitContainer14.TabIndex = 22;
            // 
            // splitContainer15
            // 
            this.splitContainer15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer15.Location = new System.Drawing.Point(0, 0);
            this.splitContainer15.Name = "splitContainer15";
            // 
            // splitContainer15.Panel1
            // 
            this.splitContainer15.Panel1.Controls.Add(this.btn_UpdateFamNameAndParam);
            // 
            // splitContainer15.Panel2
            // 
            this.splitContainer15.Panel2.Controls.Add(this.btn_InstanceParams);
            this.splitContainer15.Size = new System.Drawing.Size(344, 27);
            this.splitContainer15.SplitterDistance = 206;
            this.splitContainer15.TabIndex = 0;
            // 
            // btn_UpdateFamNameAndParam
            // 
            this.btn_UpdateFamNameAndParam.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(158)))), ((int)(((byte)(168)))));
            this.btn_UpdateFamNameAndParam.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_UpdateFamNameAndParam.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_UpdateFamNameAndParam.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_UpdateFamNameAndParam.Location = new System.Drawing.Point(0, 0);
            this.btn_UpdateFamNameAndParam.Name = "btn_UpdateFamNameAndParam";
            this.btn_UpdateFamNameAndParam.Size = new System.Drawing.Size(206, 27);
            this.btn_UpdateFamNameAndParam.TabIndex = 2;
            this.btn_UpdateFamNameAndParam.Text = "Rename Family ";
            this.btn_UpdateFamNameAndParam.UseVisualStyleBackColor = false;
            this.btn_UpdateFamNameAndParam.Click += new System.EventHandler(this.btn_UpdateFamNameAndParam_Click);
            // 
            // btn_InstanceParams
            // 
            this.btn_InstanceParams.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(158)))), ((int)(((byte)(168)))));
            this.btn_InstanceParams.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_InstanceParams.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_InstanceParams.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_InstanceParams.Location = new System.Drawing.Point(0, 0);
            this.btn_InstanceParams.Name = "btn_InstanceParams";
            this.btn_InstanceParams.Size = new System.Drawing.Size(134, 27);
            this.btn_InstanceParams.TabIndex = 4;
            this.btn_InstanceParams.Text = "Add Instance Values";
            this.btn_InstanceParams.UseVisualStyleBackColor = false;
            this.btn_InstanceParams.Click += new System.EventHandler(this.btn_InstanceParams_Click);
            // 
            // splitContainer7
            // 
            this.splitContainer7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer7.Location = new System.Drawing.Point(0, 0);
            this.splitContainer7.Name = "splitContainer7";
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.rchTxtBx_NewFamilyName);
            // 
            // splitContainer7.Panel2
            // 
            this.splitContainer7.Panel2.Controls.Add(this.groupBox2);
            this.splitContainer7.Size = new System.Drawing.Size(344, 66);
            this.splitContainer7.SplitterDistance = 208;
            this.splitContainer7.TabIndex = 3;
            // 
            // rchTxtBx_NewFamilyName
            // 
            this.rchTxtBx_NewFamilyName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(158)))), ((int)(((byte)(168)))));
            this.rchTxtBx_NewFamilyName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rchTxtBx_NewFamilyName.Location = new System.Drawing.Point(0, 0);
            this.rchTxtBx_NewFamilyName.Name = "rchTxtBx_NewFamilyName";
            this.rchTxtBx_NewFamilyName.Size = new System.Drawing.Size(208, 66);
            this.rchTxtBx_NewFamilyName.TabIndex = 1;
            this.rchTxtBx_NewFamilyName.Text = "";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(158)))), ((int)(((byte)(168)))));
            this.groupBox2.Controls.Add(this.rchTxtBx_Group);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(132, 66);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Group";
            // 
            // rchTxtBx_Group
            // 
            this.rchTxtBx_Group.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(158)))), ((int)(((byte)(168)))));
            this.rchTxtBx_Group.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rchTxtBx_Group.Location = new System.Drawing.Point(3, 19);
            this.rchTxtBx_Group.Name = "rchTxtBx_Group";
            this.rchTxtBx_Group.Size = new System.Drawing.Size(126, 44);
            this.rchTxtBx_Group.TabIndex = 5;
            this.rchTxtBx_Group.Text = "";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(344, 17);
            this.label4.TabIndex = 21;
            this.label4.Text = "Modify: the Family And Family Instance Parameters";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(5, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(498, 17);
            this.label5.TabIndex = 22;
            this.label5.Text = "Modify: the Family Types Parameters";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitContainer4.Location = new System.Drawing.Point(5, 5);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.splitContainer11);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.splitContainer5);
            this.splitContainer4.Size = new System.Drawing.Size(498, 97);
            this.splitContainer4.SplitterDistance = 28;
            this.splitContainer4.TabIndex = 0;
            // 
            // splitContainer11
            // 
            this.splitContainer11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer11.Location = new System.Drawing.Point(0, 0);
            this.splitContainer11.Name = "splitContainer11";
            // 
            // splitContainer11.Panel1
            // 
            this.splitContainer11.Panel1.Controls.Add(this.btn_UpdateFamTypeAndParam);
            // 
            // splitContainer11.Panel2
            // 
            this.splitContainer11.Panel2.Controls.Add(this.splitContainer12);
            this.splitContainer11.Size = new System.Drawing.Size(498, 28);
            this.splitContainer11.SplitterDistance = 176;
            this.splitContainer11.TabIndex = 0;
            // 
            // btn_UpdateFamTypeAndParam
            // 
            this.btn_UpdateFamTypeAndParam.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.btn_UpdateFamTypeAndParam.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_UpdateFamTypeAndParam.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_UpdateFamTypeAndParam.Location = new System.Drawing.Point(0, 0);
            this.btn_UpdateFamTypeAndParam.Name = "btn_UpdateFamTypeAndParam";
            this.btn_UpdateFamTypeAndParam.Size = new System.Drawing.Size(176, 28);
            this.btn_UpdateFamTypeAndParam.TabIndex = 4;
            this.btn_UpdateFamTypeAndParam.Text = "Add Params To Selected Type";
            this.btn_UpdateFamTypeAndParam.UseVisualStyleBackColor = false;
            this.btn_UpdateFamTypeAndParam.Click += new System.EventHandler(this.btn_UpdateFamTypeAndParam_Click);
            // 
            // splitContainer12
            // 
            this.splitContainer12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer12.Location = new System.Drawing.Point(0, 0);
            this.splitContainer12.Name = "splitContainer12";
            // 
            // splitContainer12.Panel1
            // 
            this.splitContainer12.Panel1.Controls.Add(this.btn_Create_FamilyType);
            // 
            // splitContainer12.Panel2
            // 
            this.splitContainer12.Panel2.Controls.Add(this.btn_Delete_Type);
            this.splitContainer12.Size = new System.Drawing.Size(318, 28);
            this.splitContainer12.SplitterDistance = 164;
            this.splitContainer12.TabIndex = 0;
            // 
            // btn_Create_FamilyType
            // 
            this.btn_Create_FamilyType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.btn_Create_FamilyType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Create_FamilyType.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Create_FamilyType.Location = new System.Drawing.Point(0, 0);
            this.btn_Create_FamilyType.Name = "btn_Create_FamilyType";
            this.btn_Create_FamilyType.Size = new System.Drawing.Size(164, 28);
            this.btn_Create_FamilyType.TabIndex = 9;
            this.btn_Create_FamilyType.Text = "Duplicate Selected Type";
            this.btn_Create_FamilyType.UseVisualStyleBackColor = false;
            this.btn_Create_FamilyType.Click += new System.EventHandler(this.btn_Create_FamilyType_Click);
            // 
            // btn_Delete_Type
            // 
            this.btn_Delete_Type.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.btn_Delete_Type.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Delete_Type.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Delete_Type.Location = new System.Drawing.Point(0, 0);
            this.btn_Delete_Type.Name = "btn_Delete_Type";
            this.btn_Delete_Type.Size = new System.Drawing.Size(150, 28);
            this.btn_Delete_Type.TabIndex = 10;
            this.btn_Delete_Type.Text = "Delete Selected Type";
            this.btn_Delete_Type.UseVisualStyleBackColor = false;
            this.btn_Delete_Type.Click += new System.EventHandler(this.btn_Delete_Type_Click);
            // 
            // splitContainer5
            // 
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.Location = new System.Drawing.Point(0, 0);
            this.splitContainer5.Name = "splitContainer5";
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.splitContainer6);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.splitContainer10);
            this.splitContainer5.Size = new System.Drawing.Size(498, 65);
            this.splitContainer5.SplitterDistance = 259;
            this.splitContainer5.TabIndex = 0;
            // 
            // splitContainer6
            // 
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.Location = new System.Drawing.Point(0, 0);
            this.splitContainer6.Name = "splitContainer6";
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.rchTxtBx_FamTypeAndParam);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.groupBox3);
            this.splitContainer6.Size = new System.Drawing.Size(259, 65);
            this.splitContainer6.SplitterDistance = 176;
            this.splitContainer6.TabIndex = 0;
            // 
            // rchTxtBx_FamTypeAndParam
            // 
            this.rchTxtBx_FamTypeAndParam.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.rchTxtBx_FamTypeAndParam.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rchTxtBx_FamTypeAndParam.Location = new System.Drawing.Point(0, 0);
            this.rchTxtBx_FamTypeAndParam.Name = "rchTxtBx_FamTypeAndParam";
            this.rchTxtBx_FamTypeAndParam.Size = new System.Drawing.Size(176, 65);
            this.rchTxtBx_FamTypeAndParam.TabIndex = 3;
            this.rchTxtBx_FamTypeAndParam.Text = "";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.groupBox3.Controls.Add(this.rchTxtBx_SCH_Code);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(79, 65);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Schedule Code";
            // 
            // rchTxtBx_SCH_Code
            // 
            this.rchTxtBx_SCH_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.rchTxtBx_SCH_Code.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rchTxtBx_SCH_Code.Location = new System.Drawing.Point(3, 19);
            this.rchTxtBx_SCH_Code.Name = "rchTxtBx_SCH_Code";
            this.rchTxtBx_SCH_Code.Size = new System.Drawing.Size(73, 43);
            this.rchTxtBx_SCH_Code.TabIndex = 6;
            this.rchTxtBx_SCH_Code.Text = "";
            // 
            // splitContainer10
            // 
            this.splitContainer10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer10.Location = new System.Drawing.Point(0, 0);
            this.splitContainer10.Name = "splitContainer10";
            // 
            // splitContainer10.Panel1
            // 
            this.splitContainer10.Panel1.Controls.Add(this.groupBox4);
            // 
            // splitContainer10.Panel2
            // 
            this.splitContainer10.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer10.Size = new System.Drawing.Size(235, 65);
            this.splitContainer10.SplitterDistance = 76;
            this.splitContainer10.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.groupBox4.Controls.Add(this.rchTxtBx_QSID);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(0, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(76, 65);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "QSID";
            // 
            // rchTxtBx_QSID
            // 
            this.rchTxtBx_QSID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.rchTxtBx_QSID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rchTxtBx_QSID.Location = new System.Drawing.Point(3, 19);
            this.rchTxtBx_QSID.Name = "rchTxtBx_QSID";
            this.rchTxtBx_QSID.Size = new System.Drawing.Size(70, 43);
            this.rchTxtBx_QSID.TabIndex = 7;
            this.rchTxtBx_QSID.Text = "";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.groupBox1.Controls.Add(this.rchTxtBx_Description);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(155, 65);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Description";
            // 
            // rchTxtBx_Description
            // 
            this.rchTxtBx_Description.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.rchTxtBx_Description.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rchTxtBx_Description.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBx_Description.Location = new System.Drawing.Point(3, 19);
            this.rchTxtBx_Description.Name = "rchTxtBx_Description";
            this.rchTxtBx_Description.Size = new System.Drawing.Size(149, 43);
            this.rchTxtBx_Description.TabIndex = 8;
            this.rchTxtBx_Description.Text = "";
            // 
            // Fam_DGV_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1513, 652);
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Fam_DGV_Form";
            this.Text = "Family Standardiser For Projects";
            this.Load += new System.EventHandler(this.FF_DatGrd_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Fam)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer8.Panel1.ResumeLayout(false);
            this.splitContainer8.Panel2.ResumeLayout(false);
            this.splitContainer8.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).EndInit();
            this.splitContainer8.ResumeLayout(false);
            this.splitContainer9.Panel1.ResumeLayout(false);
            this.splitContainer9.Panel1.PerformLayout();
            this.splitContainer9.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).EndInit();
            this.splitContainer9.ResumeLayout(false);
            this.splitContainer13.Panel1.ResumeLayout(false);
            this.splitContainer13.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer13)).EndInit();
            this.splitContainer13.ResumeLayout(false);
            this.splitContainer14.Panel1.ResumeLayout(false);
            this.splitContainer14.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer14)).EndInit();
            this.splitContainer14.ResumeLayout(false);
            this.splitContainer15.Panel1.ResumeLayout(false);
            this.splitContainer15.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer15)).EndInit();
            this.splitContainer15.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).EndInit();
            this.splitContainer7.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.splitContainer11.Panel1.ResumeLayout(false);
            this.splitContainer11.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).EndInit();
            this.splitContainer11.ResumeLayout(false);
            this.splitContainer12.Panel1.ResumeLayout(false);
            this.splitContainer12.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer12)).EndInit();
            this.splitContainer12.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).EndInit();
            this.splitContainer5.ResumeLayout(false);
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).EndInit();
            this.splitContainer6.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.splitContainer10.Panel1.ResumeLayout(false);
            this.splitContainer10.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).EndInit();
            this.splitContainer10.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_Fam;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.RichTextBox rchTxtBx_FamTypeAndParam;
        private System.Windows.Forms.RichTextBox rchTxtBx_Description;
        private System.Windows.Forms.RichTextBox rchTxtBx_QSID;
        private System.Windows.Forms.RichTextBox rchTxtBx_SCH_Code;
        private System.Windows.Forms.RichTextBox rchTxtBx_Group;
        private System.Windows.Forms.Button btn_Create_FamilyType;
        private System.Windows.Forms.Button btn_Delete_Type;
        private System.Windows.Forms.Button btn_Swap_FamDoc_RmPoint;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.Button btn_UpdateFamTypeAndParam;
        private System.Windows.Forms.RichTextBox rchTxtBx_NewFamilyName;
        private System.Windows.Forms.Button btn_UpdateFamNameAndParam;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox chkBx_DeleteSharedParam;
        private System.Windows.Forms.CheckBox chkBx_SetProjUnits;
        private System.Windows.Forms.SplitContainer splitContainer8;
        private System.Windows.Forms.SplitContainer splitContainer9;
        private System.Windows.Forms.Button btn_FilterFromSchedule_Global;
        private System.Windows.Forms.Button btn_RunReport;
        private System.Windows.Forms.CheckBox chkBx_FilterInDGV;
        private System.Windows.Forms.SplitContainer splitContainer7;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.SplitContainer splitContainer11;
        private System.Windows.Forms.SplitContainer splitContainer12;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.SplitContainer splitContainer10;
        private System.Windows.Forms.SplitContainer splitContainer13;
        private System.Windows.Forms.Button btn_Swap_FamDoc_Category;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.SplitContainer splitContainer14;
        private System.Windows.Forms.Button btn_InstanceParams;
        private System.Windows.Forms.SplitContainer splitContainer15;
        private System.Windows.Forms.ComboBox cmbBx_ViewFamilyInstance;
        private System.Windows.Forms.DataGridViewTextBoxColumn UNIQUE_ID;
        private System.Windows.Forms.DataGridViewCheckBoxColumn FILTER_FROM_SCHEDULE;
        private System.Windows.Forms.DataGridViewTextBoxColumn FAMILY_QA;
        private System.Windows.Forms.DataGridViewTextBoxColumn INPLACE_FAMILY;
        private System.Windows.Forms.DataGridViewTextBoxColumn SHARED_NESTED_FAMILY;
        private System.Windows.Forms.DataGridViewTextBoxColumn FAMILY_INSTANCE_OWNED_BY_RM;
        private System.Windows.Forms.DataGridViewTextBoxColumn FAMILY_INSTANCE_IS_INSIDE_RM;
        private System.Windows.Forms.DataGridViewTextBoxColumn FAMILY_DOC_TO_SPEC;
        private System.Windows.Forms.DataGridViewCheckBoxColumn RM_POINT_ON;
        private System.Windows.Forms.DataGridViewComboBoxColumn CATEGORY;
        private System.Windows.Forms.DataGridViewImageColumn IMAGE;
        private System.Windows.Forms.DataGridViewTextBoxColumn FAMILY_NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn OWNER_CATEGORY;
        private System.Windows.Forms.DataGridViewComboBoxColumn FUNCTIONALTYPE;
        private System.Windows.Forms.DataGridViewComboBoxColumn SUBTYPE;
        private System.Windows.Forms.DataGridViewComboBoxColumn MANUFACTURER;
        private System.Windows.Forms.DataGridViewComboBoxColumn DESCRIPTOR;
        private System.Windows.Forms.DataGridViewComboBoxColumn GROUP;
        private System.Windows.Forms.DataGridViewComboBoxColumn FAMILY_TYPES;
        private System.Windows.Forms.DataGridViewComboBoxColumn SCHEDULE_CODE_TYPES;
        private System.Windows.Forms.DataGridViewComboBoxColumn QSID_CODE_TYPES;
        private System.Windows.Forms.DataGridViewComboBoxColumn DESCRIPTION_TYPES;
        private System.Windows.Forms.Label label6;
    }
}