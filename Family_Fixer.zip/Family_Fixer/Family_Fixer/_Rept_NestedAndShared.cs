﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using ComboBox = System.Windows.Forms.ComboBox;

namespace Family_Fixer
{
    class _Rept_NestedAndShared
    {

        public static bool checkInstance(UIDocument _uiDoc, Document _doc, UIApplication _uiApp, Family family, ComboBox Cmbx_Show_ReptdFamInst)
        {
            List<FamilyInstance> famInst_list = new List<FamilyInstance>();
            bool boolNestedAndShared = false;

            //Family instance collector
            //check if all family instances have valid rooms associated with them
            foreach
                    (
                    FamilyInstance _familyinstance in new FilteredElementCollector(_doc)
                    .OfClass(typeof(FamilyInstance))
                    .WhereElementIsNotElementType()
                    .Cast<FamilyInstance>()
                    .Where(f => f.Symbol.FamilyName == family.Name)
                    .Where(f => f.SuperComponent != null)
                    )
            {
                //cast to element
                //Element foundElem = _familyinstance as Element;            
                //str += "\n" + "family => " + family.Name + ", instance => " + _familyinstance.Name;
                famInst_list.Add(_familyinstance);
                boolNestedAndShared = true;
                //break;

            }//end loop


            ///
            ///Show families where their bounding box is not completely inside a room
            ///
            if (famInst_list.Count > 0 && Cmbx_Show_ReptdFamInst.Text == Show_ReptdFamInst.SHOW_NESTED_AND_SHARED_FAMILYINSTANCE)
            {
                _Find_FamInst.showView(_uiDoc, _doc, _uiApp, famInst_list);
            }

            return boolNestedAndShared;



        }//end method
    }//end class
}//end ns

