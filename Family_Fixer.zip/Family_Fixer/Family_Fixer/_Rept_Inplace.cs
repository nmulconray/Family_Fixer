﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using ComboBox = System.Windows.Forms.ComboBox;

namespace Family_Fixer
{
    class _Rept_Inplace
    {
        public static bool checkInstance(UIDocument _uiDoc, Document _doc, Family _family, UIApplication _uiApp, ComboBox cmbBx_ViewFamilyInstance)
        {
            if (_family.IsInPlace == true)
            {
                List<FamilyInstance> famInst_list = new List<FamilyInstance>();

                //ParameterFilter, faster pre-processing
                String ruleValStr = _family.Name;
                BuiltInParameter testParam = BuiltInParameter.ALL_MODEL_FAMILY_NAME;
                ParameterValueProvider pvp = new ParameterValueProvider(new ElementId((int)testParam));
                FilterStringRuleEvaluator fnrvStr = new FilterStringEquals();
                FilterStringRule paramFr = new FilterStringRule(pvp, fnrvStr, ruleValStr, false);
                ElementParameterFilter epf = new ElementParameterFilter(paramFr);

                //Family instance collector
                //check if all family instances have valid rooms associated with them
                foreach
                        (
                        FamilyInstance _familyinstance in new FilteredElementCollector(_doc)
                        .OfClass(typeof(FamilyInstance))
                        .WherePasses(epf)
                        .WhereElementIsNotElementType()
                        .Cast<FamilyInstance>()
                        )
                {

                    famInst_list.Add(_familyinstance);
                }


                ///
                ///Show families inplace
                ///
                if (famInst_list.Count > 0 && cmbBx_ViewFamilyInstance.Text == Show_ReptdFamInst.SHOW_INPLACE_FAMILY)
                {
                    _Find_FamInst.showView(_uiDoc, _doc, _uiApp, famInst_list);
                }

                return true;
            }
            else
            {
                return false;
            }


        }//end method





    }//end class
}//end ns
