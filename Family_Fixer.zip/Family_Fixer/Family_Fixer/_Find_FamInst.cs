﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;

namespace Family_Fixer
{
    static class _Find_FamInst
    {

        /// <summary>
        /// Show FamilyInstance not owned by a room in a Revit View
        /// future updates may include changing to modeless form so user may edit, tailoring a 3d view with wireframe on so can see family
        /// use model document otherwise elementid error will result
        /// </summary>
        /// <param name="_uiApp"></param>
        /// <param name="famInst_List"></param>
        public static void showView(UIDocument _uiDoc, Document _doc, UIApplication _uiApp, List<FamilyInstance> famInst_List)
        {
            try
            {
                List<Element> element_List = new List<Element>();

                foreach (FamilyInstance famInst in famInst_List)
                {
                    //cast to element
                    Element elem = famInst as Element;



                    //Set active document to the Project Doc, as user may have opened a family for preview
                    Document ProjDoc = _uiApp.OpenAndActivateDocument(_doc.PathName).Document;

                        //Warn users to minimize to view, close addin to edit selected family
                        //TaskDialog.Show("Showing Family Instances", "Close Add-in to edit family instance found in view, <Element Name>::" + elem.Name);
                        //Highlight and show element
                        //_uiDoc.Selection.SetElementIds(new[] { elem.Id });
                        //build a list 
                        element_List.Add(elem);


                    //_uiDoc.ShowElements(elem.Id);

                    //just show first family instance found, user has to run again from addin eto find each instance 
                    //break;
                }

                ///Call modeless form to view errorneous families, hopefully disposes correctly?
                Form_Showfam fvf = new Form_Showfam(_uiDoc, element_List);         
                fvf.Show();

            }
            catch (Exception ex)
            {
                TaskDialog.Show("error family instance", ex.Message);
            }
        }


    }//end class
}//end ns
