﻿namespace Family_Fixer
{
    static class Unit_Convert
    {
        public static double MMToFt(double distanceMM)
        {
            return distanceMM / 304.8;
        }
        public static double FtToMM(double distanceFeet)
        {
            return distanceFeet * 304.8;
        }

    }//Maths conversions class
}
