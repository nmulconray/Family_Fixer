﻿using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Windows.Media.Imaging;

namespace Family_Fixer
{

    [Transaction(TransactionMode.Manual)]
    class Ribbon_FamFix : Autodesk.Revit.UI.IExternalApplication
    {

        // class instance
        public static Ribbon_FamFix thisApp = null;

        // ModelessForm instance
        private Fam_DGV_Form m_MyForm;

        //Paths
        public string DLLFilePath = @"C:\ProgramData\Autodesk\Revit\Addins\2018\Family_Fixer\Family_Fixer\bin\Release\";
        public string utilFilePath = @"C:\ProgramData\Autodesk\Revit\Addins\2018\Family_Fixer\Family_Fixer\bin\Release\";
        public string resourcesFilePath = @"C:\ProgramData\Autodesk\Revit\Addins\2018\PT_Images_2018\";


        //3.<PROJECT>
        private string AppName1A = "Project Family Fixer";


        public Autodesk.Revit.UI.Result OnStartup(UIControlledApplication application)
        {
            // add new ribbon tab, panels and buttons
            application.CreateRibbonTab("Project Family Fixer");


            //Add Ribbon Panel Group <3.PROJECT>
            RibbonPanel ribbonPanel_Family_Fixer = application.CreateRibbonPanel("Project Family Fixer", "Family");

             PushButton pushButton1A = ribbonPanel_Family_Fixer.AddItem(new PushButtonData("Family Fixer", AppName1A,
             DLLFilePath + "Family_Fixer.dll", "Family_Fixer.Fam_Command")) as PushButton;




            // Set ToolTip and contextual help 
            pushButton1A.ToolTip = "Family Reanimator has split into Offspring" + "\n" +
            "todo";

            pushButton1A.LongDescription =
            "1.) Please run the add-in Family Re-Animator's Offspring." + "\n" + "\n" +
            "2.) Add a family type" + "\n" + "\n" +
            "3.) Use the drop down selectors to select from the top Drop Down Lists the family <Functional Type>, <Sub Type>,<Manufacturer>,<Descriptor>" + "\n" + "\n" +
            "4.) Then Select the Family Parameter Drop Down Lists to choose and push in the required shared parameters" + "\n" + "\n" +
            "5.) Go to the subcategories tab and push in the subcategories to the family" + "\n" + "\n" +
            "6.) Select the manufacturer parameters you would like to remove" + "\n" + "\n" +
            "7.) For Model Managers Only - Use the Training tab to teach the add-in for family names to improve it's naming conventions and update the schedule codes list if your company codes change";





            //2.<PROJECT>

            Uri uriImage1A = new Uri(resourcesFilePath + "FamFix32pi96dpi.png");
            BitmapImage largeImage1A = new BitmapImage(uriImage1A);
            pushButton1A.LargeImage = largeImage1A;

   

            ///
            ///RegisterUpdater;
            ///
            m_MyForm = null; // no dialog needed yet; the command will bring it
            thisApp = this; // static access to this application instance 

            return Result.Succeeded;
        }





        public Result OnShutdown(UIControlledApplication application)
        {
            ///
            ///UnregisterUpdater      
            if (m_MyForm != null && m_MyForm.Visible)
                {
            m_MyForm.Close();
                }

            return Result.Succeeded;
        }





        // The external command invokes this on the end-user's request
        public void ShowForm(UIApplication uiapp)
        {

                // If we do not have a dialog yet, create and show it
                if (m_MyForm == null || m_MyForm.IsDisposed)
                {

                // A new handler to handle request posting by the dialog
                Fam_ExternalEvent handler = new Fam_ExternalEvent();
                

                // External Event for the dialog to use (to post requests
                ExternalEvent exEvent = ExternalEvent.Create(handler);


                // We give the objects to the new dialog;
                // The dialog becomes the owner responsible for disposing them, eventually.
                m_MyForm = new Fam_DGV_Form(uiapp, exEvent, handler);
                
                //Add the form to the handler, so that the form can be updated from the externalEvent class(the handler)
                handler.FormThing = m_MyForm;

                m_MyForm.Show();
                }

        }//end shw frm






    }//end class
}//end ns
