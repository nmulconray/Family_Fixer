﻿using Autodesk.Revit.DB;
using System.Linq;
using CheckBox = System.Windows.Forms.CheckBox;

namespace Family_Fixer
{
    /// <summary>
    /// Two Rules, 
    /// 1. Family Name Structure
    /// 2. Type Parameters are populated with a value
    /// </summary>
    class _Filt_FamTypeHasParamValue
    {  
        /// <summary>
        /// Use method overloads to check shared, boolean, builtInParameters by their parameter signatures
        /// </summary>
        /// <param name="_doc"></param>
        /// <param name="_family"></param>
        /// <returns></returns>
        public static bool ParamValueExist(Document _doc, Family _family)
        {
            if (_Filt_FamilyName.famFileStructureChecker(_family.Name) == true &&
            famTypeParameterChecker(_doc, _family, Fam_SharedParam.QSID_SP) == true &&
            famTypeParameterChecker(_doc, _family, Fam_SharedParam.SCHEDULECODE_SP) == true &&
            famTypeParameterChecker(_doc, _family, BuiltInParameter.ALL_MODEL_DESCRIPTION) == true
                )
            {
                return true;
            }
            else
            {
                return false;
            }
        }



        /// <summary>
        /// Method overloading
        /// </summary>
        /// <param name="_doc"></param>
        /// <param name="_family"></param>
        /// <param name="strSharedParamName"></param>
        /// <returns></returns>
        public static bool famTypeParameterChecker(Document _doc, Family _family, string strSharedParamName)
        {
            bool _bool_paramValue = false;

            //Iterate through elemIds
            foreach (ElementId elemId in _family.GetFamilySymbolIds())
            {
                //Get Element Type values                               
                Element elem = _doc.GetElement(elemId) as Element;
                ElementType elemtype = elem as ElementType;

                //Get shared parameter
                Parameter param = elemtype.LookupParameter(strSharedParamName);
                if (param != null)
                {
                    if (param.HasValue)
                    {
                        _bool_paramValue = true;
                        break;
                    }
                }
            }//end get elementtype

            return _bool_paramValue;
        }

        public static bool famTypeParameterChecker(Document _doc, Family _family, BuiltInParameter builtInParam)
        {
            bool _bool_paramValue = false;

            //Iterate through elemIds
            foreach (ElementId elemId in _family.GetFamilySymbolIds())
            {
                //Get Element Type values                               
                Element elem = _doc.GetElement(elemId) as Element;
                ElementType elemtype = elem as ElementType;

                //Get shared parameter
                Parameter param = elemtype.get_Parameter(builtInParam);
                if (param != null)
                {
                    if (param.HasValue)
                    {
                        _bool_paramValue = true;
                        break;
                    }
                }
            }//end get elementtype

            return _bool_paramValue;
        }

        public static bool famTypeParameterChecker(Document _doc, Family _family, string strSharedParamName, bool initBool)
        {
            bool _bool_paramValue = initBool;

            foreach
            (
            FamilyInstance _familyinstance in new FilteredElementCollector(_doc)
            .OfClass(typeof(FamilyInstance))
            .WhereElementIsNotElementType()
            .Cast<FamilyInstance>()
            .Where(f => f.Symbol.FamilyName == _family.Name)
            )
            {
                //for each family instance set parameter value
                Parameter param = _familyinstance.LookupParameter(strSharedParamName);

                if (param != null)
                {
                    //If at least one instance has a group value exit with true, otherwise on large files will drag
                    if (param.HasValue)
                    {
                        _bool_paramValue = true;
                        break;
                    }
                }

            }//end loop

            return _bool_paramValue;
        }//end method




        public static bool famTypeParameterChecker(Document _doc, Family _family, string strSharedParamName, CheckBox chkBx_FilterInDGV)
        {
            if (chkBx_FilterInDGV.Checked == true)
            {
                bool _bool_paramValue = false;

                //Iterate through elemIds
                foreach (ElementId elemId in _family.GetFamilySymbolIds())
                {
                    //Get Element Type values                               
                    Element elem = _doc.GetElement(elemId) as Element;
                    ElementType elemtype = elem as ElementType;

                    //Get shared parameter
                    Parameter param = elemtype.LookupParameter(strSharedParamName);
                    if (param != null)
                    {
                        if (param.AsInteger() == 1)
                        {
                            _bool_paramValue = true;
                            break;
                        }
                    }
                }//end get elementtype

                return _bool_paramValue;
            }
            else
            { return false; }
        }






    }
}
