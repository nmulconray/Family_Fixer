﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Family_Fixer
{
    public partial class Form_2DPicker : Form
    {
        public double pickPt_X { get; set; }
        public double pickPt_Y { get; set; }
        public double pickPt_Z { get; set; }

        public Form_2DPicker()
        {
            InitializeComponent();
            txtBx_X.Text = "1000";
            txtBx_Y.Text = "1000";
            txtBx_Z.Text = "1000";
        }

        private void Form_2DPicker_Load(object sender, EventArgs e)
        {
        //do nothing here
        }

        private void picBx_2D_Picker_Click(object sender, EventArgs e)
        {
            var mouseEventArgs = e as MouseEventArgs;
            if (mouseEventArgs != null)
            {

                double ctr = 200; //pixels, *10 to get mm, then later convert to feet as API works in rogue units, not imperial
                double X = 0;
                double Y = 0;

                //Get mouse clicked points
                X = mouseEventArgs.X;
                Y = mouseEventArgs.Y;
                paintRect(X*10, Y*10);

                //X axis - create a new cartesian coordinate system, with 200,200 pixels at the centre
                if (X < ctr)
                { X = ( (ctr * 10) -(X * 10) )*-1; }
                else if (X > ctr)
                { X = (X * 10) - (ctr * 10); }

                //Y Axis - create a new cartesian coordinate system, with 200,200 pixels at the centre
                if (Y < ctr)
                { Y = (ctr * 10) - (Y * 10); }
                else if (Y > ctr)
                { Y = ( (Y * 10) - (ctr * 10) ) *-1; }

                //Show user x,y
                txtBx_X.Text = X.ToString();
                txtBx_Y.Text = Y.ToString();
                //Show rectangle at clicked point, create new object each call?




                //set return values for x, y, z
                this.pickPt_X = Convert.ToDouble(txtBx_X.Text);
                this.pickPt_Y = Convert.ToDouble(txtBx_Y.Text);
                this.pickPt_Z = Convert.ToDouble(txtBx_Z.Text);
            };
        }

        //Paint Rectangle
        private void paintRect(double X, double Y)
        {
            System.Drawing.Graphics graphicsObj;           
            graphicsObj = picBx_2D_Picker.CreateGraphics();

            float[] dashValues = { 2, 2, 2, 2 };
            Pen myPen = new Pen(System.Drawing.Color.Blue, 5);
            myPen.DashPattern = dashValues;

            graphicsObj.DrawLine(myPen, 200, 200, Convert.ToInt16(X / 10), Convert.ToInt16(Y / 10));

            //dispose graphics object
            graphicsObj.Dispose();
        }

        }//end class
}//end ns
