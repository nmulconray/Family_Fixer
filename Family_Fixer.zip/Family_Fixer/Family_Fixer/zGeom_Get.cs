﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace Family_Fixer
{
    //cant be static class?
    class zGeom_Get
    {
            public void GetAndTransformCurve(Autodesk.Revit.ApplicationServices.Application app,  Autodesk.Revit.DB.Element element)
            {
            Options geoOptions = new Options();
            geoOptions.DetailLevel = ViewDetailLevel.Fine;

                // Get geometry element of the selected element
                Autodesk.Revit.DB.GeometryElement geoElement = element.get_Geometry(geoOptions);

                // Get geometry object
                foreach (GeometryObject geoObject in geoElement)
                {
                    // Get the geometry instance which contains the geometry information
                    Autodesk.Revit.DB.GeometryInstance instance =  geoObject as Autodesk.Revit.DB.GeometryInstance;
                    if (null != instance)
                    {
                        GeometryElement instanceGeometryElement = instance.GetInstanceGeometry();
                        foreach (GeometryObject o in instanceGeometryElement)
                        {
                            // Try to find curves
                            Curve curve = o as Curve;
                            if (curve != null)
                            {
                            TaskDialog.Show("Curve", "Geometry Curve");
                                // The curve is already transformed into the project coordinate system
                            }
                        }
                    }
                }
            }//end mthd


    }//end class
}//end ns
