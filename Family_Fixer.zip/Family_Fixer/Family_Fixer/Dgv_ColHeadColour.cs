﻿using System.Windows.Forms;
using Color = System.Drawing.Color;

namespace Family_Fixer
{
    class Dgv_ColHeadColour
    {
        public static void setColHeader(DataGridView dataGridView_Fam)
        {
            //Free up control set programmatically set header colours
            dataGridView_Fam.EnableHeadersVisualStyles = false;

            //grp0 (173,217,230)
            dataGridView_Fam.Columns[Dgv_Col_Name.FILTER_FROM_SCHEDULE].HeaderCell.Style.BackColor = Color.FromArgb(173, 217, 230);

            //grp1(83,195,229)
            dataGridView_Fam.Columns[Dgv_Col_Name.FAMILY_QA].HeaderCell.Style.BackColor = Color.FromArgb(83, 195, 229);
            dataGridView_Fam.Columns[Dgv_Col_Name.INPLACE_FAMILY].HeaderCell.Style.BackColor = Color.FromArgb(83, 195, 229);
            dataGridView_Fam.Columns[Dgv_Col_Name.SHARED_NESTED_FAMILY].HeaderCell.Style.BackColor = Color.FromArgb(83, 195, 229);
            dataGridView_Fam.Columns[Dgv_Col_Name.FAMILY_INSTANCE_OWNED_BY_RM].HeaderCell.Style.BackColor = Color.FromArgb(83, 195, 229);
            dataGridView_Fam.Columns[Dgv_Col_Name.FAMILY_INSTANCE_IS_INSIDE_RM].HeaderCell.Style.BackColor = Color.FromArgb(83, 195, 229);
            dataGridView_Fam.Columns[Dgv_Col_Name.FAMILY_DOC_TO_SPEC].HeaderCell.Style.BackColor = Color.FromArgb(83, 195, 229);

            //grp2(74,146,168)
            dataGridView_Fam.Columns[Dgv_Col_Name.CATEGORY].HeaderCell.Style.BackColor = Color.FromArgb(74, 146, 168);
            dataGridView_Fam.Columns[Dgv_Col_Name.RM_POINT_ON].HeaderCell.Style.BackColor = Color.FromArgb(74, 146, 168);

            //grp3(126,158,168)
            dataGridView_Fam.Columns[Dgv_Col_Name.IMAGE].HeaderCell.Style.BackColor = Color.FromArgb(126, 158, 168);
            dataGridView_Fam.Columns[Dgv_Col_Name.FAMILY_NAME].HeaderCell.Style.BackColor = Color.FromArgb(126, 158, 168);
            dataGridView_Fam.Columns[Dgv_Col_Name.OWNER_CATEGORY].HeaderCell.Style.BackColor = Color.FromArgb(126, 158, 168);
            dataGridView_Fam.Columns[Dgv_Col_Name.FUNCTIONAL_TYPE].HeaderCell.Style.BackColor = Color.FromArgb(126, 158, 168);
            dataGridView_Fam.Columns[Dgv_Col_Name.SUB_TYPE].HeaderCell.Style.BackColor = Color.FromArgb(126, 158, 168);
            dataGridView_Fam.Columns[Dgv_Col_Name.MANUFACTURER].HeaderCell.Style.BackColor = Color.FromArgb(126, 158, 168);
            dataGridView_Fam.Columns[Dgv_Col_Name.DESCRIPTOR].HeaderCell.Style.BackColor = Color.FromArgb(126, 158, 168);
            dataGridView_Fam.Columns[Dgv_Col_Name.GROUP].HeaderCell.Style.BackColor = Color.FromArgb(126, 158, 168);

            //grp4(99,99,99)
            dataGridView_Fam.Columns[Dgv_Col_Name.FAMILY_TYPES].HeaderCell.Style.BackColor = Color.FromArgb(99, 99, 99);
            //EXERCISE_FINAL - check this column name has been updated
            dataGridView_Fam.Columns[Dgv_Col_Name.SCHEDULE_CODE_TYPES].HeaderCell.Style.BackColor = Color.FromArgb(99, 99, 99);
            dataGridView_Fam.Columns[Dgv_Col_Name.QSID_CODE_TYPES].HeaderCell.Style.BackColor = Color.FromArgb(99, 99, 99);
            dataGridView_Fam.Columns[Dgv_Col_Name.DESCRIPTION_TYPES].HeaderCell.Style.BackColor = Color.FromArgb(99, 99, 99);

        }






    }
}
