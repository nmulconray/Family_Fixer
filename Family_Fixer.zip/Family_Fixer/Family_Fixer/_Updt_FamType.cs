﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;



namespace Family_Fixer
{
    class _Updt_FamType
    {


        public static void RENAMEFamilyType(Document _doc, ElementType elemType, string newFamilyType)
        {
            try
            {
                //set family type name, by text box new type
                using (Transaction trans = new Transaction(_doc, "FF - Rename Family Type"))
                {
                    trans.Start();
                    elemType.Name = newFamilyType;
                    trans.Commit();
                }
            }
            catch (Exception)
            {
                //do nothing
            }

        }//end mthd





        /// <summary>
        /// ADD Family Type
        /// </summary>
        /// <param name="_doc"></param>
        /// <param name="oldfamilyObj"></param>
        /// <param name="newFamilyType"></param>
        public static void ADDFamilyType(Document _doc, Family family, ElementType oldfamilyObj, string newFamilyType, int typeCount)
        {
            try
            {
                //set family type name, by text box new type
                using (Transaction trans = new Transaction(_doc, "FF - Add Family Type"))
                {
                    trans.Start();

                    if (typeCount > 0)
                    {
                        //Duplicate the element type 
                        FamilySymbol famSym = oldfamilyObj.Duplicate(newFamilyType) as FamilySymbol;
                    }
                    else
                    {
                        //FamilySymbol famSym = family
                    }
              
                    trans.Commit();
                }
            }
            catch (Exception)
            {
                //do nothing
            }
        }//end mthd





        /// <summary>
        /// Delete Family Type
        /// </summary>
        /// <param name="_doc"></param>
        /// <param name="delfamilyObj"></param>
        /// <param name="newFamilyType"></param>
        public static void DELETEFamilyType(Document _doc, ElementType delfamilyObj, int typeCount)
        {
            try
            {
                //set family type name, by text box new type
                using (Transaction trans = new Transaction(_doc, "FF - Delete Family Type"))
                {
                    trans.Start();
                    //Duplicate the element type 
                    if (typeCount > 1)
                    {
                        _doc.Delete(delfamilyObj.Id);
                    }
                    else
                    {
                        TaskDialog.Show("Save One For Last!","At least one family type is required");
                    }
                    trans.Commit();
                }
            }
            catch (Exception)
            {
                //do nothing
            }
        }//end mthd





        /// <summary>
        /// Update Shared Parameters
        /// </summary>
        /// <param name="_doc"></param>
        /// <param name="elemType"></param>
        /// <param name="strLookUp"></param>
        /// <param name="ParameterValue"></param>
        public static void editFamTypeAttributes(Document _doc, ElementType elemType, string strLookUp, string ParameterValue)
        {
            try
            {
                    //for each family type set parameter value
                    Parameter Element_parameter = elemType.LookupParameter(strLookUp);
                    if (Element_parameter != null)
                    {
                        if (!Element_parameter.IsReadOnly)
                        {
                            using (Transaction trans = new Transaction(_doc, "Set Family Shared Parameter Values"))
                            {
                                trans.Start();
                                    Element_parameter.Set(ParameterValue);
                                trans.Commit();
                            }
                        }
                        else
                        {
                            TaskDialog.Show("Type Parameter Locked", strLookUp + ", Parameter is locked to a formula. \n Open Family> Edit the family parameter manually");
                        }
                    }
                    else
                    {
                        TaskDialog.Show("Type Parameter Null", strLookUp + ", Parameter is missing. \n Open Family> Edit the family parameter manually");
                    }
            }//end try
            catch (Exception ex)
            {
                TaskDialog.Show("Parameters not Added", ex.Message);
            }
        }//end mthd





        /// <summary>
        /// Update Shared Parameters
        /// </summary>
        /// <param name="_doc"></param>
        /// <param name="elemType"></param>
        /// <param name="strLookUp"></param>
        /// <param name="ParameterValue"></param>
        public static void editFamTypeAttributes(Document _doc, ElementType elemType, string strLookUp, bool ParameterValue)
        {
            try
            {
                //set all family QA to 0 = false unless true has been found for that family
                int intParameterValue = 0;
                //for each family type set parameter value
                Parameter Element_parameter = elemType.LookupParameter(strLookUp);
                if (Element_parameter != null)
                {
                    if (!Element_parameter.IsReadOnly)
                    {
                        //Parse bool value to an integer value
                        if (ParameterValue == true)
                        { intParameterValue = 1; }

                            using (Transaction trans = new Transaction(_doc, "Set Family Shared Parameter Values"))
                            {
                                trans.Start();
                                Element_parameter.Set(intParameterValue);
                                trans.Commit();
                            }
                        }
                        else
                        {
                            TaskDialog.Show("Type Parameter Locked", strLookUp + ", Parameter is locked to a formula. \n Open Family> Edit the family parameter manually");
                        }
                    }
                else
                {
                    TaskDialog.Show("Type Parameter Null", strLookUp + ", Parameter is missing. \n Open Family> Edit the family parameter manually");
                }
            }//end try
            catch (Exception ex)
            {
                TaskDialog.Show("Parameters not Added", ex.Message);
            }
        }//end mthd




        /// <summary>
        /// Update BuiltInParameters
        /// </summary>
        /// <param name="_doc"></param>
        /// <param name="elemType"></param>
        /// <param name="BuiltInParam"></param>
        /// <param name="ParameterValue"></param>
        public static void editFamTypeAttributes(Document _doc, ElementType elemType, BuiltInParameter BuiltInParam, string ParameterValue)
        {
            try
            {
                //for each family type set parameter value
                Parameter Element_parameter = elemType.get_Parameter(BuiltInParam);
                if (Element_parameter != null)
                {
                    if (!Element_parameter.IsReadOnly)
                    {
                        using (Transaction trans = new Transaction(_doc, "Set Family Shared Parameter Values"))
                        {
                            trans.Start();
                            Element_parameter.Set(ParameterValue);
                            trans.Commit();
                        }
                    }
                    else
                    {
                        TaskDialog.Show("Type Parameter Locked", BuiltInParam.ToString() + ", Parameter is locked to a formula. \n Open Family> Edit the family parameter manually");
                    }
                }
                else
                {
                    TaskDialog.Show("Type Parameter Null", BuiltInParam.ToString() + ", Parameter is missing. \n Open Family> Edit the family parameter manually");
                }
            }//end try
            catch (Exception ex)
            {
                TaskDialog.Show("Parameters not Added", ex.Message);
            }
        }//end mthd













    }//end cl
}//end ns
