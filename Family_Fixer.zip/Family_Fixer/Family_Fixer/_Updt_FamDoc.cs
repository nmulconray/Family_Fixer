﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Family_Fixer
{
    class _Updt_FamDoc
    {

        //RM POINT ON
        public static void editFamDoc(
            UIApplication _uiApp,
            string _strProjModelPath,
            Dictionary<Family, bool> _family_dict,
            CheckBox chkBx_SetProjUnits,
            CheckBox chkBx_DeleteSharedParam,
            double _pickPt_X,
            double _pickPt_Y,
            double _pickPt_Z
            )
        {
            try
            {
                //Get Current project doc
                Document _doc = _uiApp.ActiveUIDocument.Document;

                foreach (KeyValuePair<Family, bool> kvp in _family_dict)
                {
                    //open and edit family from project
                    Document famdoc = _doc.EditFamily(kvp.Key);
                    Family OwnerFamily = famdoc.OwnerFamily;
                    FamilyLoadOptions famLoadOpts = new FamilyLoadOptions();

                    if (famdoc != null)
                    {
                        //Get the family manager from the opened family doc
                        FamilyManager fammanager = famdoc.FamilyManager;


                        //Call to Set Project Units to Metric
                        if (chkBx_SetProjUnits.Checked == true)
                        {
                            bool boolUnitsSet = SetProjectUnits(famdoc);
                        }

                        //Call to delete xeno-parameters
                        if (chkBx_DeleteSharedParam.Checked == true)
                        {
                            bool boolDeleteXenoParam = SetFamDocParam(famdoc);
                        }


                        //Call to Set Room Calc Point
                        bool boolRmCalcSet = SetFamDocParam(famdoc, OwnerFamily, kvp.Value, BuiltInParameter.ROOM_CALCULATION_POINT, _pickPt_X, _pickPt_Y, _pickPt_Z);



                        //Opens the original ProjDoc, as user may have fam doc active
                        setToInitialOnLoadIntoProjDoc(_uiApp, famdoc, _strProjModelPath, famLoadOpts);

                    }//end if
                }//end dictionary loop
            }//end try
            catch (Exception ex)
            {
                TaskDialog.Show("FamDoc Edit error", "Rm pt FamDoc Edit error\n" + ex.Message);
            }
        }//end mthd





        /// <summary>
        /// CATEGORY - Fam Doc
        /// </summary>
        public static void editFamDoc(
            UIApplication _uiApp,
            string _strProjModelPath,
            Dictionary<Family, string> _familyCat_dict,
            CheckBox chkBx_SetProjUnits,
            CheckBox chkBx_DeleteSharedParam)
        {
            try
            {
                //Get Current project doc
                Document _doc = _uiApp.ActiveUIDocument.Document;
                FamilyLoadOptions famLoadOpts = new FamilyLoadOptions();

                foreach (KeyValuePair<Family, string> kvp in _familyCat_dict)
                {
                    //TaskDialog.Show("family cat dictionary", kvp.Key.Name + ", " + kvp.Value.ToString());


                    //open and edit family from project
                    Document famdoc = _doc.EditFamily(kvp.Key);
                    Family OwnerFamily = famdoc.OwnerFamily;

                    if (famdoc != null)
                    {

                        //Get the family manager from the opened family doc
                        FamilyManager fammanager = famdoc.FamilyManager;

                        //Call to Set Project Units to Metric
                        if (chkBx_SetProjUnits.Checked == true)
                        {
                            bool boolUnitsSet = SetProjectUnits(famdoc);
                        }

                        //Call to delete xeno-parameters
                        if (chkBx_DeleteSharedParam.Checked == true)
                        {
                            bool boolDeleteXenoParam = SetFamDocParam(famdoc);
                        }



                        //Call to Set Family Cat
                        bool boolFamDocCat = SetFamDocParam(famdoc, OwnerFamily, kvp.Value);


                        //Opens the original ProjDoc, as user may have fam doc active
                        setToInitialOnLoadIntoProjDoc(_uiApp, famdoc, _strProjModelPath, famLoadOpts);
                        
                    }//end if
       

                }//end loop



            }//end try
            catch (Exception ex)
            {
                TaskDialog.Show("FamDoc Edit error", "Swap Category - FamDoc Edit error" + ex.Message);
            }
        }//end mthd








 
        /// <summary>
        /// Show The spatial element Calculation point
        /// </summary>
        /// <param name="famdoc"></param>
        /// <param name="OwnerFamily"></param>
        /// <param name="boolParameterValue"></param>
        /// <param name="builtInParam"></param>
        /// <returns></returns>
        public static bool SetFamDocParam(Document famdoc, Family OwnerFamily, bool boolParameterValue, BuiltInParameter builtInParam, double _pickPt_X, double _pickPt_Y, double _pickPt_Z)
        {
            try
            {
                using (Transaction trans = new Transaction(famdoc, "Set Fam Doc Params"))
                {
                    trans.Start();

                    //ShowSpatialElementCalculationPoint
                    Parameter famparam = OwnerFamily.get_Parameter(builtInParam);
                    if (famparam != null)
                    {
                        if (boolParameterValue == true)
                        {
                            //Turn on rm point
                            famparam.Set(1);
                            //Move Room Point
                            rotateRmPoint(famdoc, _pickPt_X, _pickPt_Y, _pickPt_Z);
                         
                        }
                        else
                        {
                            famparam.Set(0);
                        }

                    }
                    trans.Commit();
                }


                return true;
            }
            catch (Exception ex)
            {
                TaskDialog.Show("Error pst marker", ex.Message);
                return false;
            }
        }



        /// <summary>
        /// If RmPoint is not -1, rmPoint will switch on and it's position set
        /// </summary>
        /// <param name="_famdoc"></param>
        /// <param name="intRotIncr"></param>
        public static void rotateRmPoint(Document _famdoc, double _pickPt_X, double _pickPt_Y, double _pickPt_Z)
        {
            try
            {
                //open and edit family from project
                FamilyLoadOptions famloadOpt = new FamilyLoadOptions();


                    //Move the Room Point in the Family document
                    SpatialElementCalculationPoint sPoint = new FilteredElementCollector(_famdoc)
                    .OfClass(typeof(SpatialElementCalculationPoint))
                    .Cast<SpatialElementCalculationPoint>()
                    .ToList().FirstOrDefault();

                    //Set the 3d coordinate pt to a position in the 2d array
                    double x = Unit_Convert.MMToFt(_pickPt_X);
                    double y = Unit_Convert.MMToFt(_pickPt_Y);
                    double z = Unit_Convert.MMToFt(_pickPt_Z);


                    //Update Location
                    sPoint.Position = new XYZ(x, y, z);
                    //TaskDialog.Show("xyz", "\nX:" + x + "\nY:" + y + "\nZ:" + z);



            }
            catch
            { }

        }//end mthd










        /// <summary>
        /// Set New Family Category
        /// </summary>
        /// <param name="famdoc"></param>
        /// <param name="OwnerFamily"></param>
        /// <param name="strCategory"></param>
        /// <returns></returns>
        public static bool SetFamDocParam(Document famdoc, Family OwnerFamily, string strCategory)
        {
            try
            {
                //Convert string to built in parameter enum
                //BuiltInParameter bip = strParameterValue as BuiltInParameter; 

                Categories categories = famdoc.Settings.Categories;
                Category newCat = null;
                foreach (Category cat in categories)
                {
                    if (cat.Name == strCategory)
                    {
                        newCat = cat;
                        break;
                    }
                }

                using (Transaction trans = new Transaction(famdoc, "Set Fam Doc Params"))
                {
                    trans.Start();
                    //Set Cat
                    if (newCat != null)
                    {
                        famdoc.OwnerFamily.FamilyCategory = newCat;
                    }
                    trans.Commit();
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }//end method to set Category




        /// <summary>
        /// Delete Xeno-Shared Parameters
        /// </summary>
        /// <param name="famdoc"></param>
        /// <returns></returns>
        public static bool SetFamDocParam(Document famdoc)
        {
            try
            {
                //Get the Family Manager from the Fmaily Document
                FamilyManager fm = famdoc.FamilyManager;

                foreach (FamilyParameter fps in fm.Parameters)
                {
                    //Only delete those shared parameters that are not dimensions and are not own company params
                    if (fps.IsShared &&
                        fps.StorageType != StorageType.Double &&
                        fps.Definition.Name != Fam_SharedParam.GROUP_SP &&
                        fps.Definition.Name != Fam_SharedParam.SCHEDULECODE_SP &&
                        fps.Definition.Name != Fam_SharedParam.QSID_SP &&
                        fps.Definition.Name != Fam_SharedParam.FAMILYQA_SP &&
                        fps.Definition.Name != Fam_SharedParam.WIDTH_SP &&
                        fps.Definition.Name != Fam_SharedParam.DEPTH_SP &&
                        fps.Definition.Name != Fam_SharedParam.HEIGHT_SP
                        )
                    {
                        //Delete By Family Parameter ID
                        using (Transaction trans = new Transaction(famdoc, "FF - Delete by Family Parameter ID"))
                        {
                            trans.Start();
                                if (fps.Definition.Name != null)
                                {
                                    famdoc.Delete(fps.Id);
                                }
                            trans.Commit();
                        }
                    }
                }

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }





        //This 
        private static void setToInitialOnLoadIntoProjDoc(UIApplication _uiApp, Document famdoc, string _strProjModelPath, FamilyLoadOptions famLoadOpts)
        {
            try
            {
                UIDocument _uiDoc = _uiApp.OpenAndActivateDocument(_strProjModelPath);
                Document _projDoc = _uiDoc.Document;
                if (!_projDoc.IsFamilyDocument)
                {
                    //overwrite family in Project
                    famdoc.LoadFamily(_projDoc, famLoadOpts);
                }
                else
                {
                    TaskDialog.Show("Wrong Document", "You need to activate the Project document");
                }
            }
            catch(Exception)
            {
                TaskDialog.Show("Overwrite family in project", "Error loading family back into project");
            }
        }






        /// <summary>
        /// Set The Units in the family editor
        /// </summary>
        /// <param name="doc"></param>
        /// <returns></returns>
        public static bool SetProjectUnits(Document famdoc)
        {
            try
            {
                using (Transaction trans = new Transaction(famdoc, "FF-Change family units to metric"))
                {
                    trans.Start();
                    //Set units to metric
                    Units units = new Units(UnitSystem.Metric);
                    famdoc.SetUnits(units);
                    trans.Commit();
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }






    }//end class
}//end ns
