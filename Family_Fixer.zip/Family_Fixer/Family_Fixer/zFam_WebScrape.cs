﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows.Forms;
using ComboBox = System.Windows.Forms.ComboBox;
using HAP = HtmlAgilityPack;
using LinkLabel = System.Windows.Forms.LinkLabel;

namespace Family_Fixer
{

    public static class zFam_WebScrape
    {
        private static List<string> ls = new List<string>();


        public static string getLink(string strUri , string strKeyword, LinkLabel linkLabel1, ComboBox cmbBx_FamilySelector, string strManufacturer) 
        {
            //Clear list, very important
            ls.Clear();

            //find a valid url
            strUri = getValidWebURL(strUri, cmbBx_FamilySelector, strManufacturer);


            using (var client = new System.Net.WebClient())
            {
                //need to add a test to see if either http or https works
                if (!strUri.Contains("http"))
                {
                    strUri = "http://" + strUri;
                }

                //get filename
                var filename = System.IO.Path.GetTempFileName();
                client.DownloadFile(strUri, filename);
                //get doc
                var doc = new HAP.HtmlDocument();
                doc.Load(filename);
                //get keywords
                var a_nodes = doc.DocumentNode.SelectNodes("//*[text()[contains(., '" + strKeyword + "')]]");


                if (a_nodes != null)
                {
                    a_nodes.ToList().ForEach(a => ls.Add(a.GetAttributeValue("href", "")));

                    foreach (string str in ls)
                    {
                        if (!str.Contains("http"))
                        {
                            return strUri + str + "\n";
                        }
                        else
                        {
                            return str + "\n";
                        }                    
                    }
                    return null;
                }
                else
                {
                    //if node is empty
                    return null;
                }

            }//end using


        }//end mthd



        private static string getValidWebURL(string strUri0, ComboBox cmbBx_FamilySelector, string manufacturer)
        {
            string strUri1 = null;
            string strUri2 = null;

            if (!strUri0.Contains("http"))
            {
                strUri0 = "http://" + strUri0;
            }
            //1
            strUri1 = "http://www." + manufacturer + ".com.au";

            //2
            if (cmbBx_FamilySelector.Text.Contains("_"))
            {
            string[] arrSplit = cmbBx_FamilySelector.Text.Split('_');
            strUri2 = "http://www." + arrSplit[2] + ".com.au";
            }
            else
            {
                strUri2 = "GEN";
            }




            if (checkWebsite(strUri0))
                {
                    MessageBox.Show(strUri0, "strUri0");
                    return strUri0;
                }
                else if (checkWebsite(strUri1))
                {
                    MessageBox.Show(strUri1, "strUri1");
                    return strUri1;
                }
                else if (checkWebsite(strUri2))
                {
                    MessageBox.Show(strUri2, "strUri2");
                    return strUri2;
                }
                else
                {
                    return null;
                }
        }//end mthd


        private static bool checkWebsite(string URL)
        {
            try
            {
                WebClient wc = new WebClient();
                string HTMLSource = wc.DownloadString(URL);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

    }//end cl
}//end ns
