﻿namespace Family_Fixer
{
    //3 classes each storing constant strings that should not change providing constant links to column headers in the DGV,
    //shard parameters and file locations
    //Column headers
    //Paramer names
    //file paths
    public static class Dgv_Col_Name
    {
        //EXERCISE_FINAL
        //TASK_FINAL.2 - Rename the parameter names and their values <SCHEDULE_CODE_TYPES> to <PARAM_1_TYPES>,
        //when asked if you want to update, click yes
        public const string
        FAMILY_SEQUENCE = "FAMILY_SEQUENCE",
        UNIQUE_ID = "UNIQUE_ID",
        FILTER_FROM_SCHEDULE = "FILTER_FROM_SCHEDULE",
        RUN_REPORT_BTN = "RUN_REPORT_BTN",
        FAMILY_QA = "FAMILY_QA",
        INPLACE_FAMILY = "INPLACE_FAMILY",
        SHARED_NESTED_FAMILY = "SHARED_NESTED_FAMILY",
        FAMILY_INSTANCE_OWNED_BY_RM = "FAMILY_INSTANCE_OWNED_BY_RM",
        FAMILY_INSTANCE_IS_INSIDE_RM = "FAMILY_INSTANCE_IS_INSIDE_RM",
        FAMILY_DOC_TO_SPEC = "FAMILY_DOC_TO_SPEC",
        RM_POINT_ON = "RM_POINT_ON",
        OWNER_CATEGORY = "OWNER_CATEGORY",
        IMAGE = "IMAGE",
        CATEGORY = "CATEGORY",
        FAMILY_NAME = "FAMILY_NAME",
        FAMILY_TYPES = "FAMILY_TYPES",
        RENAME_FAMILY = "RENAME_FAMILY",
        FUNCTIONAL_TYPE = "FUNCTIONALTYPE",
        SUB_TYPE = "SUBTYPE",
        MANUFACTURER = "MANUFACTURER",
        DESCRIPTOR = "DESCRIPTOR",
        NEW_FAMILY_NAME = "NEW_FAMILY_NAME",
        FAMILY_OBJECT = "FAMILY_OBJECT",
        NEW_FAMILY_TYPE_NAME_CELL = "NEW_FAMILY_TYPE_NAME_CELL",
        FAMILY_TYPE_OBJECT = "FAMILY_TYPE_OBJECT",
        GROUP = "GROUP",
        SCHEDULE_CODE_TYPES = "SCHEDULE_CODE_TYPES",
        QSID_CODE_TYPES = "QSID_CODE_TYPES",
        DESCRIPTION_TYPES = "DESCRIPTION_TYPES";

    }

    public static class Fam_SharedParam
    {
        public const string
        QSID_SP = "QSID",
        WIDTH_SP = "Width",
        DEPTH_SP = "Depth",
        HEIGHT_SP = "Height",
        VERSION_SP = "Version",
        GROUP_SP = "Group",
        PTAQACCHECK_SP = "PT QA Check",
        FAMILYQA_SP = "Family QA",
        HFBS_SP = "HFBS No.",
        //TASK_FINAL.2 - Rename the shared parameter names and their values <SCH_Code> to <PARAM_1>,
        //when asked if you want to update, click yes
        SCHEDULECODE_SP = "SCH_Code",
        SCH_FILTER_SP = "SCH_Filter";
    }

    public static class Fam_Paths
    {
        public const string
        FAM_XML_PATH = @"C:\ProgramData\Autodesk\Revit\Addins\2018\Family_Fixer\Family_Data.xml",
        FAM_FILES_PATH = @"C:\Revit Content\2018\";
    }

    public static class Phase_Custom
    {
        public const string
        PHASE_PREPROJECT = "Pre-project Phase";
    }

    //These are ExternalEvent Arousing
    public static class Btn_Call
    {
        public const string
        NONE = "NONE",
        SCH_FILTER = "SCH_FILTER",
        SHOW_RM_PT = "SHOW_RM_PT",
        SWAP_CATEGORY = "SWAP_CATEGORY",
        OPEN_FAMILY = "OPEN_FAMILY",
        RENAME_FAMILY = "RENAME_FAMILY",
        SET_INSTANCE_PARAM = "SET_INSTANCE_PARAM",
        RENAME_FAM_TYPE = "RENAME_FAM_TYPE",
        ADD_FAM_TYPE = "ADD_FAM_TYPE",
        DEL_FAM_TYPE = "DEL_FAM_TYPE";
    }

    public static class Show_ReptdFamInst
    {
        public const string
        NONE = "Dont Show Family Instances",
        SHOW_ALL_FAMILYINSTANCE = "Show All Family Instance",
        SHOW_FAMILYINSTANCE_WITHOUT_RM = "Show Family Instance Without Room",
        SHOW_FAMILYINSTANCE_OUTSIDE_RM = "Show Family Instance Outside Room",
        SHOW_INPLACE_FAMILY = "Show In_Place Family",
        SHOW_NESTED_AND_SHARED_FAMILYINSTANCE = "Show Nested And Shared Family Instance";
    }





}//end class
