﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Form = System.Windows.Forms.Form;



namespace Family_Fixer
{
    public partial class form_viewfam : Form
    {
        private UIDocument _uiDoc;
        private int intCounter = 0;
        private Element[] _element_array;

        public form_viewfam(UIDocument uiDoc, List<Element> element_List)
        {
            InitializeComponent();
            _uiDoc = uiDoc;
            _element_array = element_List.ToArray();
            //Add the family name to the form control
            this.Text = element_List.FirstOrDefault().Name;
        }

        //on button click iterate forward
        private void btn_Find_Family_Click(object sender, EventArgs e)
        {

            //go to next found family
            if (intCounter > -1 && intCounter < _element_array.Count())
            {
                iterateFoundElems();
                intCounter++;

                label_Count.Text = intCounter.ToString();
                btn_Find_Nxt_Family.BackColor = System.Drawing.Color.LightGreen;
            }
            else
            {
                btn_Find_Nxt_Family.BackColor = System.Drawing.Color.Red;

            }
        }
        private void btn_Find_Previous_Family_Click(object sender, EventArgs e)
        {

            //go to next found family
            if (intCounter > 0 && intCounter < _element_array.Count() + 1)
            {
                intCounter--;
                iterateFoundElems();


                label_Count.Text = intCounter.ToString();
                btn_Find_Previous_Family.BackColor = System.Drawing.Color.LightGreen;
            }
            else
            {
                btn_Find_Previous_Family.BackColor = System.Drawing.Color.Red;
            }
        }


        private void iterateFoundElems()
        {
            //dont exceed array limits
            if (intCounter > -1 && intCounter < _element_array.Count())
            {
                //Highlight and show element
                _uiDoc.Selection.SetElementIds(new[] { _element_array[intCounter].Id });
                _uiDoc.ShowElements(_element_array[intCounter].Id);
            }

        }



        private void form_viewfam_Load(object sender, EventArgs e)
        {
            //do nothing here
        }
    }//end class
}//end ns
