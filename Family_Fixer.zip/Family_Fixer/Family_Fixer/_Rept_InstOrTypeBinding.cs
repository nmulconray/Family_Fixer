﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;



namespace Family_Fixer
{
    class _Rept_InstOrTypeBinding
    {
        //EXERCISE_7
        //TASK_7.2 - This method will be called to report if a Family Document Parameter is instance or type bound
        //Check if instance or type binding only triggers if failure to parameter binding from element Instance or elementType
        public static void check(Document _doc, Family _family, string strParamLookup)
        {
            //If family isnt in-place safe to attempt to get famDoc
            Document famdoc = _doc.EditFamily(_family);

                //Get the family manager from the opened family doc
                FamilyManager fammanager = famdoc.FamilyManager;
                FamilyParameter fp = fammanager.get_Parameter(strParamLookup);

            if (fp.IsInstance)
            {
                TaskDialog.Show("Wrong Parameter Binding!", "This is not supposed to be..." +
                "\n" + "Instance binding, for the parameter..." +
                strParamLookup +
                "Open family to fix");
            }
            else
            {
                TaskDialog.Show("Wrong Parameter Binding!", "This is not supposed to be..." +
                "\n" + "Type binding, for the parameter..." +
                strParamLookup +
                "Open family to fix" );
            }

        }//end method



  }//end class
}//end ns


