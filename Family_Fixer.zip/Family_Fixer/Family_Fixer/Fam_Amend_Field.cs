﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Family_Fixer
{
    static class Fam_Amend_Field
    {

        //Function Formats fields to sentence case with hyphen delimiter
        public static string format(string strFieldToFormat)
        {
            //counter to prevent adding hypen after last split text component
            int counter = 1;
            //new field to return
            string strFormattedField = "";

            if (!string.IsNullOrWhiteSpace(strFieldToFormat))
            {
                if (strFieldToFormat.Contains(" ") || strFieldToFormat.Contains("-") || strFieldToFormat.Contains("_"))
                {
                    //Split string if one of the following delimiters is found
                    char[] delimiters = new char[] { ' ', '-', '_', ')', '(' };
                    string[] FieldToFormat_split = strFieldToFormat.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);

                    foreach (string strField in FieldToFormat_split)
                    {
                        //convert all strings to sentence case unless specified, ie manufacturer
                        strFormattedField += char.ToUpper(strField[0]) + strField.Substring(1).ToLower();

                        if (counter < FieldToFormat_split.Length)
                        {
                            strFormattedField += "-";
                        }

                        counter++;
                    }

                    return strFormattedField;

                }
                else
                {
                    return strFormattedField = char.ToUpper(strFieldToFormat[0]) + strFieldToFormat.Substring(1).ToLower();
                }
            }
            else
            {
                return strFieldToFormat;
            }
        }//end mthd






        //Function Formats fields to sentence case with hyphen delimiter
        public static List<string> format(List<string> unfiltered_List)
        {
            HashSet<string> filtered_List = new HashSet<string>();

            foreach (string strFields in unfiltered_List)
            {
                //check if contains multiple entries
                if (!strFields.Contains(","))
                {
                    //if just one entry remove null values
                    if (!strFields.ToLower().Contains("null") || !strFields.ToLower().Contains("description"))
                    {
                        filtered_List.Add(strFields.Trim());
                        
                    }
                }
                else
                {
                    char[] delimiters = new char[] { ',' };
                    string[] strFields_split = strFields.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);

                    foreach (string str in strFields_split)
                    {
                        if ( !str.ToLower().Contains("null"))
                        {
                            filtered_List.Add(str.Replace(" ", ""));
                        }
                    }
                }


            }
                return filtered_List.ToList();
        }//end mthd



    }//end cl
}//end ns
