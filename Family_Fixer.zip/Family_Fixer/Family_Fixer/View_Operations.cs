﻿using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Family_Fixer
{
    class View_Operations
    {

            public static View3D find3DView(Document doc, string str3DViewName)
            {
                try
                {
                    // Find a 3D view to use for the ReferenceIntersector constructor
                    FilteredElementCollector collector = new FilteredElementCollector(doc);
                    //Add filter to collector isNotTemplate
                    Func<View3D, bool> isNotSpecificName = v3 => (v3.ViewName == "_3D_Family_Preview") && !(v3.IsTemplate) ;
                    View3D view3d = collector.OfClass(typeof(View3D)).Cast<View3D>().First<View3D>(isNotSpecificName);

                    return view3d;
                }

                catch (Exception)
                {
                    return null;
                }

            }//end routine

        public static View3D find3DView(Document doc)
        {
            try
            {
                // Find a 3D view to use for the ReferenceIntersector constructor
                FilteredElementCollector collector = new FilteredElementCollector(doc);
                //Add filter to collector isNotTemplate
                Func<View3D, bool> isNotSpecificName = v3 => !(v3.IsTemplate);
                View3D view3d = collector.OfClass(typeof(View3D)).Cast<View3D>().First<View3D>(isNotSpecificName);

                return view3d;
            }

            catch (Exception)
            {
                return null;
            }

        }//end routine






        //Test if View exists if not create view and return
        public static View3D createView(Document doc)
            {
                View3D view = null;

                try
                {
                    //Find a particular View Type
                    IEnumerable<ViewFamilyType> viewFamilyTypes = from elem in new FilteredElementCollector(doc).OfClass(typeof(ViewFamilyType))
                                                                  let type = elem as ViewFamilyType
                                                                  where type.ViewFamily == ViewFamily.ThreeDimensional
                                                                  select type;

                    using (Transaction trans = new Transaction(doc, "Get Or Create a new View"))
                    {
                        trans.Start();
                        //Create a new View
                        view = View3D.CreateIsometric(doc, viewFamilyTypes.First().Id);
                        view.Name = "_3D_Family_Preview";
                        view.AreAnnotationCategoriesHidden = true;
                        view.AreImportCategoriesHidden = true;
                        view.ArePointCloudsHidden = true;
                        view.get_Parameter(BuiltInParameter.MODEL_GRAPHICS_STYLE).Set(1);
                        view.SaveOrientation();
                        trans.Commit();
                    }

                    view = find3DView(doc);
                    return view;
                }//end try
                catch (Exception)
                {
                    return null;
                }
            }//end createView




        //EXERCISE_3 - Make a plan view to preview erroneous families
        //TASK_3.1 - Copy and paste below the createView(Document doc) method a copy of that method. Add the parameter type <Level> and the name <level>
        //TASK_3.2 - Change the return parameter type to <ViewPlan>, also rename the parameter equal to null <View3D> to <ViewPlan>
        //TASK_3.3 - There is a lambda filter that starts with IEnumerable. Change the enum ViewType to <FloorPlan>
        //TASK_3.4 - Add this code below to the method, removing the commenting
        //Find a level
        /*IEnumerable<Level> level = from elem in new FilteredElementCollector(doc).OfClass(typeof(Level))
                                   let particularLevel = elem as Level
                                   where particularLevel.Name == strlevelName
                                   select particularLevel;
        */
        //TASK_3.5 - Change view name to view.Name = "_FloorPlan_Family_Preview";
        //TASK_3.6 - delete <view.SaveOrientation();> , delete or comment out //view = find3DView(doc);

        /*
        public static ViewPlan createView(Document doc, string strlevelName)
        {
            ViewPlan view = null;

            try
            {
                //Find a level
                IEnumerable<Level> level = from elem in new FilteredElementCollector(doc).OfClass(typeof(Level))
                                                              let particularLevel = elem as Level
                                                              where particularLevel.Name == strlevelName
                                                              select particularLevel;

                //Find a particular View Type
                IEnumerable<ViewFamilyType> viewFamilyTypes = from elem in new FilteredElementCollector(doc).OfClass(typeof(ViewFamilyType))
                                                              let type = elem as ViewFamilyType
                                                              where type.ViewFamily == ViewFamily.FloorPlan
                                                              select type;

                using (Transaction trans = new Transaction(doc, "Get Or Create a new View"))
                {
                    trans.Start();
                    //Create a new View
                    view = ViewPlan.Create(doc, viewFamilyTypes.First().Id, level.FirstOrDefault().Id);
                    view.Name = "_FloorPlan_Family_Preview";
                    view.AreAnnotationCategoriesHidden = true;
                    view.AreImportCategoriesHidden = true;
                    view.ArePointCloudsHidden = true;
                    view.get_Parameter(BuiltInParameter.MODEL_GRAPHICS_STYLE).Set(1);
                    trans.Commit();
                }

                //view = find3DView(doc);
                return view;
            }//end try
            catch (Exception)
            {
                return null;
            }
        }//end createView
*/










    }//Class to check for existence of 3d view OR add it if it doesn't exist, using calling codes conditional logic
}//end ns
