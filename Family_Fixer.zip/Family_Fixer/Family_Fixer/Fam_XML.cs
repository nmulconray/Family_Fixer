﻿using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Linq;

namespace Family_Fixer
{
    static class Fam_XML
    {
        /// <summary>
        /// Populate Comboboxes on form load event
        /// </summary>
        public static List<string> addInnerField_FromFamilyXML(string strAttributeSelector)
        {
            List<string> _Component_list = new List<string>();

            try
            {
                //Add an XML file with one entry if file doesn't exist
                if (File.Exists(Fam_Paths.FAM_XML_PATH) == true)
                {
                    XmlDocument doc = new XmlDocument();
                    doc.Load(Fam_Paths.FAM_XML_PATH);
                    XmlNodeList nodeList = doc.SelectNodes("FAMILYCATALOG/FAMILY");

                    foreach (XmlNode node in nodeList)
                    {
                        if (!_Component_list.Contains(node.SelectSingleNode(strAttributeSelector).InnerText))
                        {
                            _Component_list.Add(node.SelectSingleNode(strAttributeSelector).InnerText);
                        }
                    }

                }
                else
                {
                    TaskDialog.Show("Family XML Missing", "Add-in, Requires the Family XML File");
                }

                //Sort The List, pushing GEN to the top
                _Component_list.OrderByDescending(i => i == "GEN").ThenBy(i => i);

                //Return the list
                return _Component_list;

            }//end try
            catch (Exception ex)
            {
                TaskDialog.Show("XML Family list Not Created", ex.Message);
                return _Component_list = null;
            }


        }//end mthd









     
            //Sub Types
            //selected value = comboboxcell value
            //ie strAttribute = SUBTYPE, strSubAttribute = DESCRIPTOR
            public static List<string> addInnerField_FromFamilyXML(string strSelectedValue, string strAttribute, string strSubAttribute)
            {
                    HashSet<string> Attr_Hash = new HashSet<string>();
                    List<string> Attr_List = new List<string>();
                    //
                    XDocument xmlDoc = XDocument.Load(Fam_Paths.FAM_XML_PATH);
                    //
                    var FAMILYCATALOG = from FAMILY in xmlDoc.Descendants("FAMILY")
                                        where FAMILY.Element(strAttribute).Value == strSelectedValue
                                        select new
                                        {
                                            newSubAttributeItem = FAMILY.Element(strSubAttribute).Value,
                                        };

                    //comboBox_Descriptor.Items.Clear();
                    foreach (var FAMILY in FAMILYCATALOG)
                    {
                        Attr_Hash.Add(FAMILY.newSubAttributeItem);
                    }
                    Attr_List = Attr_Hash.ToList();


            //Sort The List
            Attr_List.Sort();


            //Return the list
            return Attr_List;
            }
         







    }//end class
}//end namespace
