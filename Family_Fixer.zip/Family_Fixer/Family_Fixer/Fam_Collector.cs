﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using CheckBox = System.Windows.Forms.CheckBox;
using Document = Autodesk.Revit.DB.Document;



namespace Family_Fixer
{
    /// <summary>
    /// Author: Nik Mulconray
    /// Date:30-03-2017
    /// </summary>
    public static class Fam_Collector
    {

        public static List<Fam_Model> Family_Dictionary(Document doc, CheckBox chkBx_FilterInDGV)
        {
            try
            {

                //Get XML - funct type
                List<string> _category = Fam_XML.addInnerField_FromFamilyXML(Dgv_Col_Name.CATEGORY);
                List<string> _functType = Fam_XML.addInnerField_FromFamilyXML(Dgv_Col_Name.FUNCTIONAL_TYPE);
                List<string> _subType = Fam_XML.addInnerField_FromFamilyXML(Dgv_Col_Name.SUB_TYPE);
                List<string> _manufacturer = Fam_XML.addInnerField_FromFamilyXML(Dgv_Col_Name.MANUFACTURER);
                List<string> _descriptor = Fam_XML.addInnerField_FromFamilyXML(Dgv_Col_Name.DESCRIPTOR);

                //TASK_FINAL.5 - The Rename <_ScheduleCodeTypes> to <_param_1_types>, click yes when prompted to rename the one parameter to another.
                //usually this appears as a light bulb
                List<string> _ScheduleCodeTypes = Fam_Amend_Field.format( Fam_XML.addInnerField_FromFamilyXML(Dgv_Col_Name.SCHEDULE_CODE_TYPES) );
                List<string> _descriptionTypes = Fam_Amend_Field.format(Fam_XML.addInnerField_FromFamilyXML(Dgv_Col_Name.DESCRIPTION_TYPES));

                //populate family
                var fam_obj = new List<Fam_Model>();
                string _OwnerCat = "X";
                int intCount = 0;
                string _unique_id = null;

                ///
                ///Collector Filters using...
                ///Category
                ///SCH_filter
                ///EXERCISE_5
                ///TASK_5.2 - add the linq anonymous method below to the foreach statement
                ///.Where(f => _Filt_Phase.hidePreProject(doc, f) == true)
                ///TASK_5.3 - Close and reopen the Add-in, What do you notice about the families collected now?
                ///Are any pre-project families included, are many families missing and why do you think this might be the case?
                foreach
                    (
                    Family _family in new FilteredElementCollector(doc)
                    .OfClass(typeof(Family))
                    .WhereElementIsNotElementType()
                    .Cast<Family>()
                    .Where(f => _Filt_Category.LoadableCategoryList(f) == true)
                    .Where(f=> _Filt_FamTypeHasParamValue.famTypeParameterChecker(doc, f, Fam_SharedParam.SCH_FILTER_SP, chkBx_FilterInDGV) == false)
                    )
                    {
                        if (_family != null)
                        {
                        //Increment Count
                        intCount++;
                        //Get familes uniqueId, stable across worksetted models
                        _unique_id = _family.UniqueId;


                        //Retrieve Category
                        if (_family.FamilyCategory.Name != null)
                        {
                            _OwnerCat = _family.FamilyCategory.Name;
                        }
                        else
                        {
                            _OwnerCat = "X-Category";
                        }


                        //Create Image
                        //deprecated, now using just image thumb
                        Image _fam_image = Fam_Image.createPreviewImage(doc, _family, 128);
                        Image _fam_image_thumb = Fam_Image.createPreviewImage(doc, _family, 32);

                        //Room Awareness Point
                        bool _boolRmPointOn = _family.ShowSpatialElementCalculationPoint;


                        //Family QA; all the following need to be true, for family QA to be true
                        //1. Family name structure is correct
                        //2. QSID value is populated
                        //3. SCH_Code is populated
                        //4. Description builtinparamater is populated
                        //5. //Future - Cant do Group as instance would slow down collector
                        bool _boolfam_qa = false;
                        _boolfam_qa = _Filt_FamTypeHasParamValue.ParamValueExist(doc, _family);


                        //Family Types
                        List<FamilyTypeObj> _famTypeObj = new List<FamilyTypeObj>();


                        //Filter from schedule
                        bool _filter_from_schedule = false;


                        //Iterate through elemIds
                        foreach (ElementId elemId in _family.GetFamilySymbolIds() )
                        {
                            //Create a new object each iteration
                            FamilyTypeObj obj = new FamilyTypeObj();

                                //Get element values                               
                                Element elem = doc.GetElement(elemId) as Element;
                                ElementType elemtype = elem as ElementType;

                                //Add to obj
                                obj.Name += elemtype.Name;
                                obj.famType = elemtype;

                                //Add object to list
                                _famTypeObj.Add(obj);

                            //get schedule filter from types
                            Parameter param = elemtype.LookupParameter(Fam_SharedParam.SCH_FILTER_SP);
                            if (param != null)
                            {
                                if (param.AsInteger() == 1)
                                {
                                    _filter_from_schedule = true;
                                }
                            }
                        }//end family types
               



                        //Build Class instance for each family, populate with default values where required
                        fam_obj.Add(
                        new Fam_Model
                        {
                            id = intCount.ToString(),
                            unique_id = _unique_id,
                            fam_qa = _boolfam_qa,
                            rm_point_on = _boolRmPointOn,
                            family_instance_owned_by_rm = "$",
                            family_instance_is_inside_rm = "><",
                            filter_from_schedule = _filter_from_schedule,
                            img = _fam_image,
                            imgThumb = _fam_image_thumb,
                            fam = _family,
                            ownerCat = _OwnerCat,
                            category_list = _category,
                            functType_list = _functType,
                            subType_list = _subType,
                            manufacturer_list = _manufacturer,
                            descriptor_list = _descriptor,
                            groupType_obj = groupType_ObjHelper.GetObj(),
                            famType_obj = _famTypeObj,
                            QSIDType_obj = QSID_ObjHelper.GetObj(),
                            //TASK_FINAL.5 - The Rename <_ScheduleCodeTypes> to <_param_1_types> should be visible here
                            scheduleCodeType_list = _ScheduleCodeTypes,
                            descriptionType_list = _descriptionTypes
                        }
                        );

                    }
                }


                //return dictionary_FamAndType;
                return fam_obj;
            }
            catch (Exception ex)
            {
                TaskDialog.Show("Collector, for Family Model", ex.Message);
                return null;

            }
        }







  




    }//end class


}//end ns
