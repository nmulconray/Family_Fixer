﻿namespace Family_Fixer
{
    partial class Form_2DPicker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picBx_2D_Picker = new System.Windows.Forms.PictureBox();
            this.txtBx_Z = new System.Windows.Forms.TextBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.txtBx_X = new System.Windows.Forms.TextBox();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.txtBx_Y = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBx_2D_Picker)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.SuspendLayout();
            // 
            // picBx_2D_Picker
            // 
            this.picBx_2D_Picker.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picBx_2D_Picker.Image = global::Family_Fixer.Properties.Resources.FamilyGrid2D;
            this.picBx_2D_Picker.Location = new System.Drawing.Point(0, 0);
            this.picBx_2D_Picker.Name = "picBx_2D_Picker";
            this.picBx_2D_Picker.Size = new System.Drawing.Size(404, 399);
            this.picBx_2D_Picker.TabIndex = 0;
            this.picBx_2D_Picker.TabStop = false;
            this.picBx_2D_Picker.Click += new System.EventHandler(this.picBx_2D_Picker_Click);
            // 
            // txtBx_Z
            // 
            this.txtBx_Z.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBx_Z.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBx_Z.Location = new System.Drawing.Point(0, 0);
            this.txtBx_Z.Name = "txtBx_Z";
            this.txtBx_Z.Size = new System.Drawing.Size(142, 35);
            this.txtBx_Z.TabIndex = 1;
            this.txtBx_Z.Tag = "Z";
            this.txtBx_Z.Text = "Z";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.picBx_2D_Picker);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(404, 444);
            this.splitContainer1.SplitterDistance = 399;
            this.splitContainer1.TabIndex = 3;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.txtBx_X);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer2.Size = new System.Drawing.Size(404, 41);
            this.splitContainer2.SplitterDistance = 128;
            this.splitContainer2.TabIndex = 0;
            // 
            // txtBx_X
            // 
            this.txtBx_X.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBx_X.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBx_X.Location = new System.Drawing.Point(0, 0);
            this.txtBx_X.Name = "txtBx_X";
            this.txtBx_X.Size = new System.Drawing.Size(128, 35);
            this.txtBx_X.TabIndex = 2;
            this.txtBx_X.Tag = "X";
            this.txtBx_X.Text = "X";
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.txtBx_Y);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.txtBx_Z);
            this.splitContainer3.Size = new System.Drawing.Size(272, 41);
            this.splitContainer3.SplitterDistance = 126;
            this.splitContainer3.TabIndex = 0;
            // 
            // txtBx_Y
            // 
            this.txtBx_Y.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBx_Y.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBx_Y.Location = new System.Drawing.Point(0, 0);
            this.txtBx_Y.Name = "txtBx_Y";
            this.txtBx_Y.Size = new System.Drawing.Size(126, 35);
            this.txtBx_Y.TabIndex = 2;
            this.txtBx_Y.Tag = "Y";
            this.txtBx_Y.Text = "Y";
            // 
            // Form_2DPicker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(404, 444);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Form_2DPicker";
            this.Text = "2D Rm Pt Picker ";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form_2DPicker_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBx_2D_Picker)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picBx_2D_Picker;
        private System.Windows.Forms.TextBox txtBx_Z;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.TextBox txtBx_X;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.TextBox txtBx_Y;
    }
}