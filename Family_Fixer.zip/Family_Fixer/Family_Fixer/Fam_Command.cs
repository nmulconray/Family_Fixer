﻿using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using Document = Autodesk.Revit.DB.Document;


namespace Family_Fixer
{
    [Transaction(TransactionMode.Manual)]

    class Fam_Command : IExternalCommand
    {
        /// <summary>
        /// Family Reanimator Series
        /// Author: Nik Mulconray
        /// Copyright ©peddlethorp
        /// Date:17/03/2017
        /// </summary>



        public Result Execute(ExternalCommandData commandData, ref String message, ElementSet elements)
        {
            //Revit Handles
            UIApplication uiApp = commandData.Application;
            Application app = uiApp.Application;
            UIDocument uiDoc = uiApp.ActiveUIDocument;
            Document doc = uiDoc.Document;
            View3D view3d = null;







            try
            {
                if (!doc.IsFamilyDocument)
                {
                    //create a 3d view if not found
                    if (View_Operations.find3DView(doc, "_3D_Family_Preview") == null)
                    {
                        view3d = View_Operations.createView(doc);
                        //set this as the active view
                        uiApp.ActiveUIDocument.ActiveView = view3d;

                    }
                    else
                    {
                        view3d = View_Operations.find3DView(doc, "_3D_Family_Preview");
                        //set this as the active view
                        uiApp.ActiveUIDocument.ActiveView = view3d;
                    }

                    //Invoke a Modeless Dialog
                    Ribbon_FamFix.thisApp.ShowForm(commandData.Application);

  

                    return Result.Succeeded;
                }
                else
                {
                    TaskDialog.Show("This is a Fam Doc!", "Run this Add-in In a Project Document only");
                    return Result.Cancelled;
                }
            }



            //Catch boiler plate code
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                return Result.Cancelled;
            }


            catch (Exception ex)
            {
                message = ex.Message;
                return Result.Failed;
            }
        }//End Exec Method







    }//End class
}//End Ns
